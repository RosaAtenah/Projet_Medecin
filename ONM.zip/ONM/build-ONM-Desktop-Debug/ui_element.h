/********************************************************************************
** Form generated from reading UI file 'element.ui'
**
** Created by: Qt User Interface Compiler version 6.2.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ELEMENT_H
#define UI_ELEMENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Element
{
public:
    QGridLayout *gridLayout_17;
    QTabWidget *barInfo;
    QWidget *Identite;
    QGridLayout *gridLayout;
    QWidget *cotisation;
    QGridLayout *gridLayout_5;
    QWidget *dossier;
    QGridLayout *gridLayout_8;
    QWidget *enfant;
    QGridLayout *gridLayout_3;
    QWidget *adresse;
    QGridLayout *gridLayout_9;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *lineEdit;
    QLabel *label_2;
    QLineEdit *lineEdit_2;
    QPushButton *pushButton;
    QPushButton *pushButton_3;
    QPushButton *pushButton_2;
    QWidget *widget_2;
    QWidget *etudes;
    QGridLayout *gridLayout_10;
    QWidget *titre;
    QGridLayout *gridLayout_6;
    QWidget *specialites;
    QGridLayout *gridLayout_16;
    QWidget *remplacement;
    QGridLayout *gridLayout_15;
    QWidget *exercice;
    QGridLayout *gridLayout_11;
    QWidget *distinctionH;
    QGridLayout *gridLayout_7;
    QWidget *extra;
    QGridLayout *gridLayout_12;
    QWidget *judiciaire;
    QGridLayout *gridLayout_13;
    QWidget *activite;
    QGridLayout *gridLayout_2;
    QWidget *assurance;
    QGridLayout *gridLayout_4;
    QWidget *observation;
    QGridLayout *gridLayout_14;

    void setupUi(QWidget *Element)
    {
        if (Element->objectName().isEmpty())
            Element->setObjectName(QString::fromUtf8("Element"));
        Element->resize(566, 300);
        gridLayout_17 = new QGridLayout(Element);
        gridLayout_17->setObjectName(QString::fromUtf8("gridLayout_17"));
        barInfo = new QTabWidget(Element);
        barInfo->setObjectName(QString::fromUtf8("barInfo"));
        Identite = new QWidget();
        Identite->setObjectName(QString::fromUtf8("Identite"));
        gridLayout = new QGridLayout(Identite);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        barInfo->addTab(Identite, QString());
        cotisation = new QWidget();
        cotisation->setObjectName(QString::fromUtf8("cotisation"));
        gridLayout_5 = new QGridLayout(cotisation);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        barInfo->addTab(cotisation, QString());
        dossier = new QWidget();
        dossier->setObjectName(QString::fromUtf8("dossier"));
        gridLayout_8 = new QGridLayout(dossier);
        gridLayout_8->setObjectName(QString::fromUtf8("gridLayout_8"));
        barInfo->addTab(dossier, QString());
        enfant = new QWidget();
        enfant->setObjectName(QString::fromUtf8("enfant"));
        gridLayout_3 = new QGridLayout(enfant);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        barInfo->addTab(enfant, QString());
        adresse = new QWidget();
        adresse->setObjectName(QString::fromUtf8("adresse"));
        gridLayout_9 = new QGridLayout(adresse);
        gridLayout_9->setObjectName(QString::fromUtf8("gridLayout_9"));
        widget = new QWidget(adresse);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setMinimumSize(QSize(0, 50));
        widget->setMaximumSize(QSize(16777215, 50));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        lineEdit = new QLineEdit(widget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setMinimumSize(QSize(0, 30));
        lineEdit->setMaximumSize(QSize(500, 16777215));

        horizontalLayout->addWidget(lineEdit);

        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        lineEdit_2 = new QLineEdit(widget);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setMinimumSize(QSize(0, 30));
        lineEdit_2->setMaximumSize(QSize(500, 16777215));

        horizontalLayout->addWidget(lineEdit_2);

        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setMaximumSize(QSize(30, 30));

        horizontalLayout->addWidget(pushButton);

        pushButton_3 = new QPushButton(widget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setMaximumSize(QSize(30, 30));

        horizontalLayout->addWidget(pushButton_3);

        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setMaximumSize(QSize(30, 30));

        horizontalLayout->addWidget(pushButton_2);


        gridLayout_9->addWidget(widget, 0, 0, 1, 1);

        widget_2 = new QWidget(adresse);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));

        gridLayout_9->addWidget(widget_2, 1, 0, 1, 1);

        barInfo->addTab(adresse, QString());
        etudes = new QWidget();
        etudes->setObjectName(QString::fromUtf8("etudes"));
        gridLayout_10 = new QGridLayout(etudes);
        gridLayout_10->setObjectName(QString::fromUtf8("gridLayout_10"));
        barInfo->addTab(etudes, QString());
        titre = new QWidget();
        titre->setObjectName(QString::fromUtf8("titre"));
        gridLayout_6 = new QGridLayout(titre);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        barInfo->addTab(titre, QString());
        specialites = new QWidget();
        specialites->setObjectName(QString::fromUtf8("specialites"));
        gridLayout_16 = new QGridLayout(specialites);
        gridLayout_16->setObjectName(QString::fromUtf8("gridLayout_16"));
        barInfo->addTab(specialites, QString());
        remplacement = new QWidget();
        remplacement->setObjectName(QString::fromUtf8("remplacement"));
        gridLayout_15 = new QGridLayout(remplacement);
        gridLayout_15->setObjectName(QString::fromUtf8("gridLayout_15"));
        barInfo->addTab(remplacement, QString());
        exercice = new QWidget();
        exercice->setObjectName(QString::fromUtf8("exercice"));
        gridLayout_11 = new QGridLayout(exercice);
        gridLayout_11->setObjectName(QString::fromUtf8("gridLayout_11"));
        barInfo->addTab(exercice, QString());
        distinctionH = new QWidget();
        distinctionH->setObjectName(QString::fromUtf8("distinctionH"));
        gridLayout_7 = new QGridLayout(distinctionH);
        gridLayout_7->setObjectName(QString::fromUtf8("gridLayout_7"));
        barInfo->addTab(distinctionH, QString());
        extra = new QWidget();
        extra->setObjectName(QString::fromUtf8("extra"));
        gridLayout_12 = new QGridLayout(extra);
        gridLayout_12->setObjectName(QString::fromUtf8("gridLayout_12"));
        barInfo->addTab(extra, QString());
        judiciaire = new QWidget();
        judiciaire->setObjectName(QString::fromUtf8("judiciaire"));
        gridLayout_13 = new QGridLayout(judiciaire);
        gridLayout_13->setObjectName(QString::fromUtf8("gridLayout_13"));
        barInfo->addTab(judiciaire, QString());
        activite = new QWidget();
        activite->setObjectName(QString::fromUtf8("activite"));
        gridLayout_2 = new QGridLayout(activite);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        barInfo->addTab(activite, QString());
        assurance = new QWidget();
        assurance->setObjectName(QString::fromUtf8("assurance"));
        gridLayout_4 = new QGridLayout(assurance);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        barInfo->addTab(assurance, QString());
        observation = new QWidget();
        observation->setObjectName(QString::fromUtf8("observation"));
        gridLayout_14 = new QGridLayout(observation);
        gridLayout_14->setObjectName(QString::fromUtf8("gridLayout_14"));
        barInfo->addTab(observation, QString());

        gridLayout_17->addWidget(barInfo, 0, 0, 1, 1);


        retranslateUi(Element);

        barInfo->setCurrentIndex(4);


        QMetaObject::connectSlotsByName(Element);
    } // setupUi

    void retranslateUi(QWidget *Element)
    {
        Element->setWindowTitle(QCoreApplication::translate("Element", "Form", nullptr));
        barInfo->setTabText(barInfo->indexOf(Identite), QCoreApplication::translate("Element", "Tab 1", nullptr));
        barInfo->setTabText(barInfo->indexOf(cotisation), QCoreApplication::translate("Element", "Tab 2", nullptr));
        barInfo->setTabText(barInfo->indexOf(dossier), QCoreApplication::translate("Element", "Page", nullptr));
        barInfo->setTabText(barInfo->indexOf(enfant), QCoreApplication::translate("Element", "Page", nullptr));
        label->setText(QCoreApplication::translate("Element", "Nom : ", nullptr));
        label_2->setText(QCoreApplication::translate("Element", "Pr\303\251noms : ", nullptr));
        pushButton->setText(QString());
        pushButton_3->setText(QString());
        pushButton_2->setText(QString());
        barInfo->setTabText(barInfo->indexOf(adresse), QCoreApplication::translate("Element", "Page", nullptr));
        barInfo->setTabText(barInfo->indexOf(etudes), QCoreApplication::translate("Element", "Page", nullptr));
        barInfo->setTabText(barInfo->indexOf(titre), QCoreApplication::translate("Element", "Page", nullptr));
        barInfo->setTabText(barInfo->indexOf(specialites), QCoreApplication::translate("Element", "Page", nullptr));
        barInfo->setTabText(barInfo->indexOf(remplacement), QCoreApplication::translate("Element", "Page", nullptr));
        barInfo->setTabText(barInfo->indexOf(exercice), QCoreApplication::translate("Element", "Page", nullptr));
        barInfo->setTabText(barInfo->indexOf(distinctionH), QCoreApplication::translate("Element", "Page", nullptr));
        barInfo->setTabText(barInfo->indexOf(extra), QCoreApplication::translate("Element", "Page", nullptr));
        barInfo->setTabText(barInfo->indexOf(judiciaire), QCoreApplication::translate("Element", "Page", nullptr));
        barInfo->setTabText(barInfo->indexOf(activite), QCoreApplication::translate("Element", "Page", nullptr));
        barInfo->setTabText(barInfo->indexOf(assurance), QCoreApplication::translate("Element", "Page", nullptr));
        barInfo->setTabText(barInfo->indexOf(observation), QCoreApplication::translate("Element", "Page", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Element: public Ui_Element {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ELEMENT_H
