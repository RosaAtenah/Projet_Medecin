#include "header/mainwindow.h"
#include "ui_mainwindow.h"

#include "header/element.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->tabWidget->setTabsClosable(true);
    connect(ui->tabWidget, SIGNAL(tabCloseRequested(int)), this, SLOT(closeTab(int)));

    Element * element = new Element(this);
    ui->tabWidget->addTab(element, "default");
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_actionNouveau_fichier_triggered()
{
    Element * elmt = new Element(this);
    elmt->show();
    ui->tabWidget->addTab(elmt, "Medecin");
}

void MainWindow::closeTab(int index)
{
    ui->tabWidget->removeTab(index);
}
