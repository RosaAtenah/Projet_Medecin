#include "header/element.h"
#include "ui_element.h"

Element::Element(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Element)
{
    ui->setupUi(this);
    Element::setTitle();
}

Element::~Element()
{
    delete ui;
}

void Element::setTitle(){
    QStringList listTitle;
    listTitle << "INDENTE" << "COTISATION" << "DOSSIER" << "ENFANT";
    listTitle << "ADRESSE" << "ETUDES" << "TITRE" << "SPECIALITES" << "REMPLACEMENT" << "EXERICES";
    listTitle << "DISTINCTION H." << "EXTRA" << "JUDICIAIRE" << "ACTIVITES" << "ASSURANCES" << "OSBSERVATION";

    for (int i = 0; i < listTitle.size(); i++)
        ui->barInfo->setTabText(i, listTitle[i]);
}
