#ifndef ELEMENT_H
#define ELEMENT_H

#include <QWidget>

namespace Ui {
class Element;
}

class Element : public QWidget
{
    Q_OBJECT

public:
    explicit Element(QWidget *parent = nullptr);
    ~Element();
    void setTitle();
private:
    Ui::Element *ui;
};

#endif // ELEMENT_H
