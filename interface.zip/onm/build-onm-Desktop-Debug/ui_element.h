/********************************************************************************
** Form generated from reading UI file 'element.ui'
**
** Created by: Qt User Interface Compiler version 6.2.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ELEMENT_H
#define UI_ELEMENT_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QFontComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Element
{
public:
    QGridLayout *gridLayout_31;
    QTabWidget *barInfo;
    QWidget *Identite;
    QGridLayout *gridLayout;
    QScrollArea *scrollArea_2;
    QWidget *scrollAreaWidgetContents_3;
    QVBoxLayout *verticalLayout_7;
    QWidget *widget_13;
    QHBoxLayout *horizontalLayout_9;
    QGroupBox *groupBox;
    QGroupBox *groupBox_2;
    QWidget *widget_14;
    QHBoxLayout *horizontalLayout_11;
    QScrollArea *scrollArea_3;
    QWidget *scrollAreaWidgetContents_7;
    QGridLayout *gridLayout_25;
    QGroupBox *groupBox_8;
    QCheckBox *checkBox_6;
    QLabel *label_20;
    QDateEdit *dateEdit_3;
    QGroupBox *groupBox_4;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QComboBox *comboBox_2;
    QLineEdit *lineEdit_8;
    QLineEdit *lineEdit_11;
    QLineEdit *lineEdit_12;
    QGroupBox *groupBox_7;
    QCheckBox *checkBox_7;
    QCheckBox *checkBox_8;
    QGroupBox *groupBox_5;
    QLabel *label_12;
    QCheckBox *checkBox;
    QCheckBox *checkBox_2;
    QLabel *label_13;
    QCheckBox *checkBox_3;
    QCheckBox *checkBox_4;
    QCheckBox *checkBox_5;
    QLabel *label_14;
    QDateEdit *dateEdit_2;
    QGroupBox *groupBox_6;
    QLabel *label_15;
    QLabel *label_16;
    QLabel *label_17;
    QDateEdit *dateEdit_4;
    QLineEdit *lineEdit_13;
    QComboBox *comboBox_3;
    QGroupBox *groupBox_9;
    QLabel *label_21;
    QLineEdit *lineEdit_14;
    QLabel *label_22;
    QLabel *label_23;
    QLabel *label_24;
    QLabel *label_25;
    QLabel *label_26;
    QLabel *label_27;
    QLabel *label_28;
    QDateEdit *dateEdit_5;
    QDateEdit *dateEdit_6;
    QLineEdit *lineEdit_15;
    QLineEdit *lineEdit_16;
    QLineEdit *lineEdit_17;
    QGroupBox *groupBox_3;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_18;
    QLabel *label_19;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_5;
    QLineEdit *lineEdit_6;
    QLineEdit *lineEdit_7;
    QGroupBox *groupBox_10;
    QCheckBox *checkBox_9;
    QCheckBox *checkBox_10;
    QCheckBox *checkBox_11;
    QCheckBox *checkBox_12;
    QCheckBox *checkBox_13;
    QGroupBox *groupBox_11;
    QVBoxLayout *verticalLayout_8;
    QPushButton *pushButton_10;
    QTextBrowser *textBrowser;
    QWidget *widget_15;
    QHBoxLayout *horizontalLayout_12;
    QToolButton *toolButton;
    QToolButton *toolButton_2;
    QToolButton *toolButton_3;
    QToolButton *toolButton_4;
    QToolButton *toolButton_5;
    QWidget *cotisation;
    QGridLayout *gridLayout_5;
    QLabel *prenomCotisation;
    QGroupBox *groupBox_19;
    QGridLayout *gridLayout_27;
    QScrollArea *scrollArea_5;
    QWidget *scrollAreaWidgetContents_9;
    QGridLayout *gridLayout_28;
    QLabel *label_90;
    QGroupBox *groupBox_20;
    QGridLayout *gridLayout_16;
    QLineEdit *lineEdit_59;
    QLabel *label_89;
    QCheckBox *checkBox_24;
    QLabel *label_84;
    QCheckBox *checkBox_25;
    QLineEdit *lineEdit_61;
    QLabel *label_88;
    QCheckBox *checkBox_23;
    QLineEdit *lineEdit_62;
    QLabel *label_86;
    QLabel *label_85;
    QLineEdit *lineEdit_58;
    QLabel *label_87;
    QLineEdit *lineEdit_60;
    QLineEdit *lineEdit_57;
    QLineEdit *lineEdit_63;
    QWidget *widget_19;
    QGridLayout *gridLayout_17;
    QLineEdit *lineEdit_79;
    QLineEdit *lineEdit_85;
    QLineEdit *lineEdit_64;
    QLineEdit *lineEdit_80;
    QLineEdit *lineEdit_84;
    QLabel *label_95;
    QLabel *label_93;
    QLabel *label_94;
    QLineEdit *lineEdit_65;
    QLabel *label_116;
    QLineEdit *lineEdit_86;
    QCheckBox *checkBox_33;
    QCheckBox *checkBox_35;
    QLabel *label_115;
    QLabel *label_117;
    QLabel *label_91;
    QLabel *label_92;
    QCheckBox *checkBox_34;
    QLineEdit *lineEdit_82;
    QLineEdit *lineEdit_81;
    QLineEdit *lineEdit_83;
    QLabel *label_118;
    QLabel *label_119;
    QWidget *widget_23;
    QVBoxLayout *verticalLayout_12;
    QPushButton *pushButton_24;
    QPushButton *pushButton_27;
    QPushButton *pushButton_26;
    QPushButton *pushButton_25;
    QLineEdit *EditNomCotisation;
    QLineEdit *EditPrenomCotisation;
    QLabel *nomCotisation;
    QWidget *widget_17;
    QHBoxLayout *horizontalLayout_31;
    QPushButton *pushButton_20;
    QPushButton *pushButton_18;
    QPushButton *pushButton_19;
    QGroupBox *groupBox_18;
    QGridLayout *gridLayout_12;
    QScrollArea *scrollArea_4;
    QWidget *scrollAreaWidgetContents_8;
    QGridLayout *gridLayout_26;
    QLabel *label_83;
    QLabel *label_78;
    QLineEdit *lineEdit_51;
    QWidget *widget_18;
    QVBoxLayout *verticalLayout_31;
    QPushButton *nouvelleCotisation;
    QPushButton *dernierCotisation;
    QPushButton *precedentCotisation;
    QPushButton *suivantCotisation;
    QLabel *label_82;
    QLineEdit *lineEdit_56;
    QLineEdit *lineEdit_55;
    QLineEdit *lineEdit_54;
    QLabel *label_81;
    QLabel *label_80;
    QLineEdit *lineEdit_52;
    QLineEdit *lineEdit_53;
    QLabel *label_79;
    QWidget *dossier;
    QGridLayout *gridLayout_8;
    QWidget *enfant;
    QGridLayout *gridLayout_3;
    QWidget *widget_41;
    QVBoxLayout *verticalLayout_24;
    QWidget *widget_42;
    QGridLayout *gridLayout_43;
    QHBoxLayout *horizontalLayout_74;
    QLabel *label_124;
    QLineEdit *lineEdit_124;
    QHBoxLayout *horizontalLayout_75;
    QLabel *label_125;
    QLineEdit *lineEdit_125;
    QSpacerItem *horizontalSpacer_11;
    QLabel *label_126;
    QScrollArea *scrollArea_15;
    QWidget *scrollAreaWidgetContents_19;
    QGridLayout *gridLayout_44;
    QLineEdit *lineEdit_126;
    QLineEdit *lineEdit_127;
    QLabel *ordre;
    QLineEdit *lineEdit_128;
    QLineEdit *lineEdit_129;
    QLineEdit *lineEdit_130;
    QLineEdit *lineEdit_131;
    QLineEdit *lineEdit_132;
    QLineEdit *lineEdit_133;
    QLineEdit *lineEdit_134;
    QLineEdit *lineEdit_135;
    QLabel *activite_2;
    QLineEdit *lineEdit_136;
    QLineEdit *lineEdit_137;
    QLineEdit *lineEdit_138;
    QLineEdit *lineEdit_139;
    QLineEdit *lineEdit_140;
    QLineEdit *lineEdit_141;
    QLineEdit *lineEdit_142;
    QLineEdit *lineEdit_143;
    QLineEdit *lineEdit_144;
    QLineEdit *lineEdit_145;
    QLineEdit *lineEdit_146;
    QLineEdit *lineEdit_147;
    QLabel *Date;
    QLineEdit *lineEdit_148;
    QLineEdit *lineEdit_149;
    QLineEdit *lineEdit_150;
    QLineEdit *lineEdit_151;
    QLineEdit *lineEdit_152;
    QLabel *Nom;
    QLineEdit *lineEdit_153;
    QLineEdit *lineEdit_154;
    QLineEdit *lineEdit_155;
    QLabel *Prenom;
    QLineEdit *lineEdit_156;
    QLineEdit *lineEdit_157;
    QLineEdit *lineEdit_158;
    QLineEdit *lineEdit_159;
    QLineEdit *lineEdit_160;
    QWidget *widget_43;
    QWidget *etudes;
    QGridLayout *gridLayout_40;
    QFrame *frame_9;
    QHBoxLayout *horizontalLayout_15;
    QFrame *frame_10;
    QHBoxLayout *horizontalLayout_16;
    QLabel *label_41;
    QLineEdit *lineEdit_20;
    QFrame *frame_11;
    QHBoxLayout *horizontalLayout_17;
    QLabel *label_42;
    QLineEdit *lineEdit_21;
    QFrame *frame_7;
    QHBoxLayout *horizontalLayout_13;
    QGroupBox *groupBox_12;
    QFormLayout *formLayout_2;
    QLabel *label_31;
    QLabel *label_32;
    QLabel *label_33;
    QLabel *label_34;
    QTextEdit *textEdit;
    QLineEdit *lineEdit_18;
    QComboBox *comboBox_4;
    QDateEdit *dateEdit_7;
    QGroupBox *groupBox_13;
    QFormLayout *formLayout_3;
    QLabel *label_35;
    QLabel *label_36;
    QLabel *label_37;
    QLabel *label_38;
    QComboBox *comboBox_5;
    QComboBox *comboBox_6;
    QPushButton *pushButton_11;
    QDateEdit *dateEdit_8;
    QDateEdit *dateEdit_9;
    QFrame *frame_8;
    QHBoxLayout *horizontalLayout_14;
    QGroupBox *groupBox_14;
    QFormLayout *formLayout_4;
    QComboBox *comboBox_7;
    QLineEdit *lineEdit_19;
    QLabel *label_39;
    QLabel *label_40;
    QFrame *frame_12;
    QGridLayout *gridLayout_10;
    QPushButton *pushButton_12;
    QPushButton *pushButton_13;
    QPushButton *pushButton_14;
    QWidget *adresse;
    QGridLayout *gridLayout_9;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QVBoxLayout *verticalLayout_5;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QLabel *nom;
    QLineEdit *editNoms;
    QLabel *prenom;
    QLineEdit *editPrenoms;
    QPushButton *pushButton;
    QPushButton *pushButton_3;
    QPushButton *pushButton_2;
    QWidget *widget_2;
    QVBoxLayout *verticalLayout;
    QScrollArea *AddressPeso;
    QWidget *scrollAreaWidgetContents_4;
    QVBoxLayout *verticalLayout_2;
    QWidget *widget_3;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *adressePrecedent;
    QPushButton *adresseSuivant;
    QPushButton *dernierAdresse;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton_6;
    QLabel *adressePersonnelle;
    QWidget *widget_4;
    QGridLayout *gridLayout_18;
    QLabel *faxPersonnelle;
    QLineEdit *EditFokotanyPerso;
    QLabel *PortablePersonnelle;
    QFrame *frame;
    QHBoxLayout *horizontalLayout_3;
    QComboBox *comboBoxPerso;
    QLineEdit *EditFivondronanaPerso;
    QLabel *adressePersonnelle_2;
    QLabel *emailPersonnelle;
    QLineEdit *EditfaxPerso;
    QLineEdit *EditFiraisanaPerso;
    QLabel *fivondronanaPersonnelle;
    QLineEdit *EditAddressPerso;
    QLabel *TelmaPersonnelle;
    QLabel *firaisanaPersonnelle;
    QLineEdit *EditMailPerso;
    QLineEdit *EditTelmaPerso;
    QLabel *fokotanyPersonnelle;
    QLineEdit *EditPortablePerso;
    QScrollArea *ExercicePrincipal;
    QWidget *scrollAreaWidgetContents_5;
    QVBoxLayout *verticalLayout_3;
    QWidget *widget_5;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *adressePrecedent_2;
    QPushButton *adresseSuivant_2;
    QPushButton *dernierAdresse_2;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *pushButton_7;
    QLabel *LieuExoPrincipal;
    QWidget *widget_6;
    QGridLayout *gridLayout_19;
    QLineEdit *EditFiraisanaExo;
    QLabel *TelmaExo;
    QLabel *fivondronanaExo;
    QLabel *fokotanyExo;
    QLabel *emailExo;
    QFrame *frame_2;
    QHBoxLayout *horizontalLayout_6;
    QComboBox *comboBoxExo;
    QLineEdit *EditFivondronanaExo;
    QLineEdit *EditMailExo;
    QLineEdit *EditFokotanyFokotany;
    QLineEdit *EditPortableExo;
    QLineEdit *EditfaxExo;
    QLabel *PortableExo;
    QLabel *adresseExo;
    QLabel *firaisanaExo;
    QLineEdit *EditAddressExo;
    QLabel *faxExo;
    QLineEdit *EditTelmaExo;
    QScrollArea *adresseCourier;
    QWidget *scrollAreaWidgetContents_6;
    QVBoxLayout *verticalLayout_4;
    QLabel *addressCourier;
    QWidget *widget_7;
    QGridLayout *gridLayout_20;
    QLabel *AdresseCourier;
    QLineEdit *editFokotanysCour;
    QLineEdit *editFiraisanaCour;
    QLineEdit *editAddressCour;
    QLabel *FokotanyCourier;
    QFrame *frame_3;
    QHBoxLayout *horizontalLayout_7;
    QComboBox *comboBoxCourier;
    QLineEdit *editFivondronanaCour;
    QLabel *FiraisanaCourier;
    QLabel *FivondronanaCourier;
    QScrollArea *AutreExercice;
    QWidget *scrollAreaWidgetContents_2;
    QVBoxLayout *verticalLayout_6;
    QWidget *widget_9;
    QHBoxLayout *horizontalLayout_8;
    QPushButton *adressePrecedent_3;
    QPushButton *adresseSuivant_3;
    QPushButton *dernierAdresse_3;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *pushButton_8;
    QLabel *adressePersonnelle_3;
    QWidget *widget_8;
    QGridLayout *gridLayout_21;
    QLineEdit *EditAddressPerso_2;
    QLineEdit *EditTelmaPerso_2;
    QLineEdit *EditPortablePerso_2;
    QLabel *emailPersonnelle_2;
    QLabel *firaisanaPersonnelle_2;
    QFrame *frame_4;
    QHBoxLayout *horizontalLayout_5;
    QComboBox *comboBoxPerso_2;
    QLineEdit *EditFivondronanaPerso_2;
    QLineEdit *EditMailPerso_2;
    QLabel *TelmaPersonnelle_2;
    QLabel *faxPersonnelle_2;
    QLineEdit *EditfaxPerso_2;
    QLabel *adressePersonnelle_4;
    QLineEdit *EditFiraisanaPerso_2;
    QLabel *fokotanyPersonnelle_2;
    QLabel *fivondronanaPersonnelle_2;
    QLabel *PortablePersonnelle_2;
    QLineEdit *EditFokotanyPerso_2;
    QWidget *titre;
    QGridLayout *gridLayout_41;
    QFrame *frame_17;
    QHBoxLayout *horizontalLayout_20;
    QLabel *label_53;
    QLineEdit *lineEdit_30;
    QLabel *label_54;
    QLineEdit *lineEdit_31;
    QFrame *frame_13;
    QHBoxLayout *horizontalLayout_18;
    QFrame *frame_14;
    QHBoxLayout *horizontalLayout_19;
    QGroupBox *groupBox_15;
    QGridLayout *gridLayout_6;
    QLineEdit *lineEdit_22;
    QLabel *label_43;
    QLabel *label_44;
    QCheckBox *checkBox_14;
    QLineEdit *lineEdit_23;
    QLineEdit *lineEdit_24;
    QLabel *label_45;
    QLabel *label_46;
    QLineEdit *lineEdit_25;
    QLineEdit *lineEdit_26;
    QCheckBox *checkBox_15;
    QCheckBox *checkBox_16;
    QLabel *label_47;
    QCheckBox *checkBox_17;
    QCheckBox *checkBox_18;
    QCheckBox *checkBox_19;
    QLabel *label_48;
    QLineEdit *lineEdit_27;
    QLabel *label_49;
    QCheckBox *checkBox_20;
    QLineEdit *lineEdit_28;
    QCheckBox *checkBox_21;
    QLabel *label_50;
    QLineEdit *lineEdit_29;
    QFrame *frame_15;
    QVBoxLayout *verticalLayout_10;
    QGroupBox *groupBox_16;
    QFormLayout *formLayout_5;
    QLabel *label_51;
    QLabel *label_52;
    QComboBox *comboBox_8;
    QDateEdit *dateEdit_10;
    QFrame *frame_16;
    QGridLayout *gridLayout_15;
    QPushButton *pushButton_15;
    QPushButton *pushButton_16;
    QPushButton *pushButton_17;
    QWidget *specialites;
    QGridLayout *gridLayout_37;
    QWidget *widget_22;
    QHBoxLayout *horizontalLayout_70;
    QWidget *widget_35;
    QVBoxLayout *verticalLayout_88;
    QWidget *widget_36;
    QHBoxLayout *horizontalLayout_71;
    QHBoxLayout *horizontalLayout_72;
    QSpacerItem *horizontalSpacer_9;
    QLabel *nomLabel_3;
    QLineEdit *nomEdit_3;
    QHBoxLayout *horizontalLayout_73;
    QLabel *prenomLabel_3;
    QLineEdit *prenomEdit_3;
    QSpacerItem *horizontalSpacer_10;
    QWidget *widget_37;
    QVBoxLayout *verticalLayout_89;
    QWidget *widget_38;
    QVBoxLayout *verticalLayout_90;
    QWidget *widget_39;
    QVBoxLayout *verticalLayout_91;
    QLabel *label_121;
    QScrollArea *scrollArea_12;
    QWidget *scrollAreaWidgetContents_16;
    QGridLayout *gridLayout_34;
    QVBoxLayout *verticalLayout_92;
    QLabel *specDate_3;
    QLineEdit *lineEdit_109;
    QLineEdit *lineEdit_110;
    QVBoxLayout *verticalLayout_93;
    QLabel *specPer_3;
    QLineEdit *lineEdit_111;
    QLineEdit *lineEdit_112;
    QVBoxLayout *verticalLayout_94;
    QVBoxLayout *verticalLayout_95;
    QLabel *specTitre_3;
    QFontComboBox *fontComboBox_19;
    QFontComboBox *fontComboBox_20;
    QVBoxLayout *verticalLayout_96;
    QLabel *specSpec_3;
    QFontComboBox *fontComboBox_21;
    QFontComboBox *fontComboBox_22;
    QVBoxLayout *verticalLayout_97;
    QLabel *specLieu_3;
    QLineEdit *lineEdit_113;
    QLineEdit *lineEdit_114;
    QLabel *label_122;
    QScrollArea *scrollArea_13;
    QWidget *scrollAreaWidgetContents_17;
    QGridLayout *gridLayout_35;
    QVBoxLayout *verticalLayout_98;
    QLabel *AutreSpec_3;
    QFontComboBox *fontComboBox_23;
    QVBoxLayout *verticalLayout_99;
    QLabel *AutreLieu_3;
    QLineEdit *lineEdit_115;
    QVBoxLayout *verticalLayout_100;
    QLabel *AutreTitre_3;
    QFontComboBox *fontComboBox_24;
    QVBoxLayout *verticalLayout_101;
    QLabel *AutreDate_3;
    QLineEdit *lineEdit_116;
    QVBoxLayout *verticalLayout_102;
    QLabel *AutrePer_3;
    QLineEdit *lineEdit_117;
    QWidget *widget_40;
    QVBoxLayout *verticalLayout_103;
    QLabel *label_123;
    QScrollArea *scrollArea_14;
    QWidget *scrollAreaWidgetContents_18;
    QGridLayout *gridLayout_36;
    QVBoxLayout *verticalLayout_104;
    QLabel *CompOb_3;
    QLineEdit *lineEdit_118;
    QVBoxLayout *verticalLayout_105;
    QLabel *CompDoss_3;
    QFontComboBox *fontComboBox_25;
    QVBoxLayout *verticalLayout_106;
    QLabel *CompDate_3;
    QLineEdit *lineEdit_119;
    QVBoxLayout *verticalLayout_107;
    QLabel *CompDom_3;
    QFontComboBox *fontComboBox_26;
    QVBoxLayout *verticalLayout_108;
    QLabel *CompDateAc_3;
    QLineEdit *lineEdit_120;
    QVBoxLayout *verticalLayout_109;
    QLabel *CompPv_3;
    QLineEdit *lineEdit_121;
    QVBoxLayout *verticalLayout_110;
    QLabel *CompAvis_3;
    QFontComboBox *fontComboBox_27;
    QVBoxLayout *verticalLayout_111;
    QLabel *CompTitr_3;
    QLineEdit *lineEdit_122;
    QVBoxLayout *verticalLayout_112;
    QLabel *CompPer_3;
    QLineEdit *lineEdit_123;
    QWidget *remplacement;
    QGridLayout *gridLayout_42;
    QWidget *widget_16;
    QVBoxLayout *verticalLayout_30;
    QLineEdit *lineEdit_9;
    QLabel *label_29;
    QLineEdit *lineEdit_10;
    QLabel *label_30;
    QTableWidget *tableWidget;
    QWidget *exercice;
    QGridLayout *gridLayout_39;
    QFrame *frame_18;
    QGridLayout *gridLayout_38;
    QFrame *frame_19;
    QHBoxLayout *horizontalLayout_21;
    QFrame *frame_20;
    QVBoxLayout *verticalLayout_13;
    QFrame *frame_21;
    QHBoxLayout *horizontalLayout_22;
    QLabel *label_55;
    QLineEdit *lineEdit_32;
    QFrame *frame_22;
    QHBoxLayout *horizontalLayout_23;
    QLabel *label_56;
    QLineEdit *lineEdit_33;
    QFrame *frame_23;
    QVBoxLayout *verticalLayout_14;
    QCheckBox *checkBox_22;
    QFrame *frame_24;
    QHBoxLayout *horizontalLayout_24;
    QLabel *label_57;
    QLineEdit *lineEdit_34;
    QFrame *frame_25;
    QHBoxLayout *horizontalLayout_25;
    QLabel *label_58;
    QLineEdit *lineEdit_35;
    QLabel *label_59;
    QLineEdit *lineEdit_36;
    QFrame *frame_26;
    QVBoxLayout *verticalLayout_15;
    QLabel *label_60;
    QFrame *frame_27;
    QHBoxLayout *horizontalLayout_26;
    QFrame *frame_28;
    QVBoxLayout *verticalLayout_16;
    QLabel *label_61;
    QLineEdit *lineEdit_37;
    QFrame *frame_29;
    QVBoxLayout *verticalLayout_17;
    QLabel *label_62;
    QLineEdit *lineEdit_38;
    QFrame *frame_30;
    QVBoxLayout *verticalLayout_18;
    QLabel *label_63;
    QLineEdit *lineEdit_39;
    QFrame *frame_31;
    QVBoxLayout *verticalLayout_19;
    QLabel *label_64;
    QFrame *frame_32;
    QHBoxLayout *horizontalLayout_27;
    QFrame *frame_33;
    QVBoxLayout *verticalLayout_20;
    QLabel *label_65;
    QLineEdit *lineEdit_40;
    QFrame *frame_34;
    QVBoxLayout *verticalLayout_21;
    QLabel *label_66;
    QLineEdit *lineEdit_41;
    QFrame *frame_35;
    QVBoxLayout *verticalLayout_22;
    QLabel *label_67;
    QLineEdit *lineEdit_42;
    QFrame *frame_36;
    QVBoxLayout *verticalLayout_23;
    QLabel *label_68;
    QHBoxLayout *horizontalLayout_28;
    QLabel *label_69;
    QLineEdit *lineEdit_43;
    QSpacerItem *horizontalSpacer_4;
    QWidget *distinctionH;
    QGridLayout *gridLayout_7;
    QLabel *label_77;
    QLabel *label_76;
    QLineEdit *lineEdit_49;
    QGroupBox *groupBox_17;
    QVBoxLayout *verticalLayout_11;
    QFrame *frame_48;
    QGridLayout *gridLayout_45;
    QLabel *label_127;
    QLabel *label_128;
    QComboBox *comboBox_9;
    QLineEdit *lineEdit_161;
    QFrame *frame_47;
    QGridLayout *gridLayout_46;
    QPlainTextEdit *plainTextEdit;
    QLineEdit *lineEdit_50;
    QSpacerItem *verticalSpacer_2;
    QWidget *widget_44;
    QVBoxLayout *verticalLayout_9;
    QPushButton *pushButton_21;
    QPushButton *pushButton_23;
    QPushButton *pushButton_22;
    QWidget *extra;
    QGridLayout *gridLayout_11;
    QFrame *frame_37;
    QVBoxLayout *verticalLayout_25;
    QFrame *frame_38;
    QVBoxLayout *verticalLayout_26;
    QFrame *frame_39;
    QHBoxLayout *horizontalLayout_29;
    QLabel *label_70;
    QLineEdit *lineEdit_44;
    QFrame *frame_40;
    QHBoxLayout *horizontalLayout_30;
    QLabel *label_71;
    QLineEdit *lineEdit_45;
    QFrame *frame_41;
    QVBoxLayout *verticalLayout_27;
    QLabel *label_72;
    QFrame *frame_42;
    QVBoxLayout *verticalLayout_28;
    QFrame *frame_43;
    QHBoxLayout *layout_3;
    QLabel *label_73;
    QLineEdit *lineEdit_46;
    QFrame *frame_44;
    QHBoxLayout *layout;
    QLabel *label_74;
    QLineEdit *lineEdit_47;
    QFrame *frame_45;
    QHBoxLayout *layout_2;
    QLabel *label_75;
    QLineEdit *lineEdit_48;
    QWidget *judiciaire;
    QGridLayout *gridLayout_13;
    QWidget *widget_20;
    QVBoxLayout *verticalLayout_36;
    QHBoxLayout *horizontalLayout_52;
    QHBoxLayout *horizontalLayout_53;
    QLabel *label_106;
    QLineEdit *lineEdit_74;
    QHBoxLayout *horizontalLayout_54;
    QLabel *label_107;
    QLineEdit *lineEdit_75;
    QLabel *label_108;
    QWidget *leftMenu;
    QHBoxLayout *horizontalLayout_61;
    QSplitter *splitter_10;
    QLabel *label_112;
    QLineEdit *lineEdit_76;
    QSplitter *splitter_11;
    QLabel *label_113;
    QLineEdit *lineEdit_77;
    QSplitter *splitter_12;
    QLabel *label_114;
    QLineEdit *lineEdit_78;
    QLabel *label_111;
    QWidget *leftMenu_2;
    QHBoxLayout *horizontalLayout_51;
    QSplitter *splitter_7;
    QLabel *label_103;
    QLineEdit *lineEdit_71;
    QSplitter *splitter_8;
    QLabel *label_104;
    QLineEdit *lineEdit_72;
    QSplitter *splitter_9;
    QLabel *label_105;
    QLineEdit *lineEdit_73;
    QWidget *widget_21;
    QVBoxLayout *verticalLayout_37;
    QHBoxLayout *horizontalLayout_55;
    QHBoxLayout *horizontalLayout_56;
    QCheckBox *checkBox_30;
    QHBoxLayout *horizontalLayout_57;
    QLabel *label_109;
    QTextEdit *textEdit_4;
    QCheckBox *checkBox_31;
    QHBoxLayout *horizontalLayout_58;
    QHBoxLayout *horizontalLayout_59;
    QCheckBox *checkBox_32;
    QHBoxLayout *horizontalLayout_60;
    QLabel *label_110;
    QTextEdit *textEdit_5;
    QWidget *activite;
    QGridLayout *gridLayout_2;
    QScrollArea *scrollArea_6;
    QWidget *scrollAreaWidgetContents_10;
    QVBoxLayout *verticalLayout_29;
    QWidget *widget_24;
    QHBoxLayout *horizontalLayout_32;
    QLabel *label_120;
    QLineEdit *lineEdit_87;
    QLineEdit *lineEdit_88;
    QLabel *label_129;
    QComboBox *comboBox_10;
    QWidget *widget_26;
    QHBoxLayout *horizontalLayout_33;
    QPushButton *pushButton_28;
    QPushButton *pushButton_29;
    QPushButton *pushButton_30;
    QScrollArea *scrollArea_7;
    QWidget *scrollAreaWidgetContents_11;
    QGridLayout *gridLayout_32;
    QScrollArea *scrollArea_8;
    QWidget *scrollAreaWidgetContents_12;
    QGridLayout *gridLayout_30;
    QGroupBox *groupBox_21;
    QVBoxLayout *verticalLayout_33;
    QLabel *label_130;
    QWidget *widget_28;
    QGridLayout *gridLayout_29;
    QLabel *label_133;
    QCheckBox *checkBox_37;
    QLineEdit *lineEdit_89;
    QLineEdit *lineEdit_96;
    QLineEdit *lineEdit_100;
    QLineEdit *lineEdit_103;
    QLineEdit *lineEdit_104;
    QLineEdit *lineEdit_92;
    QLineEdit *lineEdit_95;
    QLabel *label_132;
    QLineEdit *lineEdit_90;
    QLineEdit *lineEdit_105;
    QCheckBox *checkBox_36;
    QLabel *label_131;
    QLineEdit *lineEdit_99;
    QLineEdit *lineEdit_102;
    QLineEdit *lineEdit_93;
    QLineEdit *lineEdit_101;
    QLineEdit *lineEdit_98;
    QLineEdit *lineEdit_94;
    QLineEdit *lineEdit_106;
    QLineEdit *lineEdit_97;
    QLabel *label_134;
    QLineEdit *lineEdit_91;
    QLabel *label_135;
    QLabel *label_136;
    QWidget *widget_29;
    QGridLayout *gridLayout_33;
    QLabel *label_140;
    QDateEdit *dateEdit_11;
    QLabel *label_137;
    QCheckBox *checkBox_38;
    QLabel *label_138;
    QLineEdit *lineEdit_108;
    QLineEdit *lineEdit_107;
    QLabel *label_139;
    QLineEdit *lineEdit_162;
    QLabel *label_141;
    QWidget *widget_27;
    QHBoxLayout *horizontalLayout_34;
    QPushButton *pushButton_31;
    QPushButton *pushButton_32;
    QPushButton *pushButton_33;
    QPushButton *pushButton_34;
    QGroupBox *groupBox_22;
    QGridLayout *gridLayout_47;
    QLabel *label_143;
    QCheckBox *checkBox_41;
    QLabel *label_142;
    QCheckBox *checkBox_46;
    QLineEdit *lineEdit_164;
    QLabel *label_146;
    QLabel *label_144;
    QCheckBox *checkBox_42;
    QCheckBox *checkBox_43;
    QCheckBox *checkBox_47;
    QCheckBox *checkBox_44;
    QCheckBox *checkBox_40;
    QCheckBox *checkBox_39;
    QLabel *label_145;
    QCheckBox *checkBox_48;
    QLineEdit *lineEdit_163;
    QCheckBox *checkBox_45;
    QTextEdit *textEdit_2;
    QGroupBox *groupBox_23;
    QGridLayout *gridLayout_49;
    QLabel *label_154;
    QCheckBox *checkBox_54;
    QCheckBox *checkBox_59;
    QLineEdit *lineEdit_171;
    QLabel *label_153;
    QCheckBox *checkBox_55;
    QLineEdit *lineEdit_168;
    QCheckBox *checkBox_53;
    QLineEdit *lineEdit_170;
    QCheckBox *checkBox_57;
    QSpacerItem *horizontalSpacer_5;
    QCheckBox *checkBox_60;
    QCheckBox *checkBox_52;
    QLabel *label_157;
    QCheckBox *checkBox_58;
    QCheckBox *checkBox_56;
    QLabel *label_155;
    QLabel *label_152;
    QCheckBox *checkBox_61;
    QLabel *label_156;
    QLineEdit *lineEdit_169;
    QGroupBox *groupBox_25;
    QGridLayout *gridLayout_48;
    QLabel *label_148;
    QLineEdit *lineEdit_166;
    QLabel *label_149;
    QCheckBox *checkBox_51;
    QLineEdit *lineEdit_167;
    QLabel *label_151;
    QDateEdit *dateEdit_12;
    QLabel *label_150;
    QLabel *label_147;
    QLineEdit *lineEdit_165;
    QGroupBox *groupBox_24;
    QVBoxLayout *verticalLayout_32;
    QCheckBox *checkBox_50;
    QCheckBox *checkBox_49;
    QWidget *assurance;
    QGridLayout *gridLayout_4;
    QHBoxLayout *horizontalLayout_44;
    QHBoxLayout *horizontalLayout_45;
    QLabel *label_97;
    QLineEdit *lineEdit_66;
    QHBoxLayout *horizontalLayout_46;
    QLabel *label_98;
    QLineEdit *lineEdit_67;
    QFrame *frame_46;
    QHBoxLayout *horizontalLayout_43;
    QLabel *label_96;
    QCheckBox *checkBox_26;
    QCheckBox *checkBox_27;
    QWidget *leftMenu3;
    QHBoxLayout *horizontalLayout_47;
    QVBoxLayout *verticalLayout_34;
    QLabel *label_99;
    QCheckBox *checkBox_28;
    QCheckBox *checkBox_29;
    QVBoxLayout *verticalLayout_35;
    QHBoxLayout *horizontalLayout_48;
    QLabel *label_100;
    QLineEdit *lineEdit_68;
    QHBoxLayout *horizontalLayout_49;
    QLabel *label_101;
    QLineEdit *lineEdit_69;
    QHBoxLayout *horizontalLayout_50;
    QLabel *label_102;
    QLineEdit *lineEdit_70;
    QWidget *observation;
    QGridLayout *gridLayout_14;
    QWidget *widget_10;
    QFormLayout *formLayout;
    QLabel *label;
    QLineEdit *lineEdit;
    QLabel *label_2;
    QLineEdit *lineEdit_2;
    QWidget *widget_11;
    QGridLayout *gridLayout_22;
    QWidget *widget_12;
    QGridLayout *gridLayout_23;
    QLabel *label_3;
    QLabel *label_4;
    QComboBox *comboBox;
    QFrame *frame_6;
    QGridLayout *gridLayout_24;
    QFrame *line;
    QDateEdit *dateEdit;
    QFrame *frame_5;
    QHBoxLayout *horizontalLayout_10;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_9;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *Element)
    {
        if (Element->objectName().isEmpty())
            Element->setObjectName(QString::fromUtf8("Element"));
        Element->setWindowModality(Qt::WindowModal);
        Element->resize(791, 520);
        Element->setStyleSheet(QString::fromUtf8(""));
        gridLayout_31 = new QGridLayout(Element);
        gridLayout_31->setObjectName(QString::fromUtf8("gridLayout_31"));
        barInfo = new QTabWidget(Element);
        barInfo->setObjectName(QString::fromUtf8("barInfo"));
        Identite = new QWidget();
        Identite->setObjectName(QString::fromUtf8("Identite"));
        gridLayout = new QGridLayout(Identite);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        scrollArea_2 = new QScrollArea(Identite);
        scrollArea_2->setObjectName(QString::fromUtf8("scrollArea_2"));
        scrollArea_2->setWidgetResizable(true);
        scrollAreaWidgetContents_3 = new QWidget();
        scrollAreaWidgetContents_3->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_3"));
        scrollAreaWidgetContents_3->setGeometry(QRect(0, 0, 749, 451));
        verticalLayout_7 = new QVBoxLayout(scrollAreaWidgetContents_3);
        verticalLayout_7->setSpacing(1);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        widget_13 = new QWidget(scrollAreaWidgetContents_3);
        widget_13->setObjectName(QString::fromUtf8("widget_13"));
        widget_13->setMinimumSize(QSize(200, 180));
        horizontalLayout_9 = new QHBoxLayout(widget_13);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        groupBox = new QGroupBox(widget_13);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setMinimumSize(QSize(200, 156));
        groupBox->setMaximumSize(QSize(200, 200));

        horizontalLayout_9->addWidget(groupBox);

        groupBox_2 = new QGroupBox(widget_13);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setMinimumSize(QSize(200, 156));
        groupBox_2->setMaximumSize(QSize(200, 200));

        horizontalLayout_9->addWidget(groupBox_2);


        verticalLayout_7->addWidget(widget_13);

        widget_14 = new QWidget(scrollAreaWidgetContents_3);
        widget_14->setObjectName(QString::fromUtf8("widget_14"));
        widget_14->setMinimumSize(QSize(2, 0));
        horizontalLayout_11 = new QHBoxLayout(widget_14);
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        scrollArea_3 = new QScrollArea(widget_14);
        scrollArea_3->setObjectName(QString::fromUtf8("scrollArea_3"));
        scrollArea_3->setWidgetResizable(true);
        scrollAreaWidgetContents_7 = new QWidget();
        scrollAreaWidgetContents_7->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_7"));
        scrollAreaWidgetContents_7->setGeometry(QRect(0, 0, 840, 680));
        gridLayout_25 = new QGridLayout(scrollAreaWidgetContents_7);
        gridLayout_25->setObjectName(QString::fromUtf8("gridLayout_25"));
        groupBox_8 = new QGroupBox(scrollAreaWidgetContents_7);
        groupBox_8->setObjectName(QString::fromUtf8("groupBox_8"));
        groupBox_8->setMinimumSize(QSize(215, 100));
        checkBox_6 = new QCheckBox(groupBox_8);
        checkBox_6->setObjectName(QString::fromUtf8("checkBox_6"));
        checkBox_6->setGeometry(QRect(50, 40, 111, 23));
        label_20 = new QLabel(groupBox_8);
        label_20->setObjectName(QString::fromUtf8("label_20"));
        label_20->setGeometry(QRect(10, 80, 51, 17));
        dateEdit_3 = new QDateEdit(groupBox_8);
        dateEdit_3->setObjectName(QString::fromUtf8("dateEdit_3"));
        dateEdit_3->setGeometry(QRect(70, 70, 121, 31));

        gridLayout_25->addWidget(groupBox_8, 1, 1, 1, 1);

        groupBox_4 = new QGroupBox(scrollAreaWidgetContents_7);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        groupBox_4->setMinimumSize(QSize(215, 245));
        label_8 = new QLabel(groupBox_4);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(10, 40, 141, 17));
        label_9 = new QLabel(groupBox_4);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(10, 100, 67, 17));
        label_10 = new QLabel(groupBox_4);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(10, 170, 67, 17));
        label_11 = new QLabel(groupBox_4);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(10, 210, 67, 17));
        comboBox_2 = new QComboBox(groupBox_4);
        comboBox_2->setObjectName(QString::fromUtf8("comboBox_2"));
        comboBox_2->setGeometry(QRect(20, 70, 171, 25));
        lineEdit_8 = new QLineEdit(groupBox_4);
        lineEdit_8->setObjectName(QString::fromUtf8("lineEdit_8"));
        lineEdit_8->setGeometry(QRect(10, 130, 191, 25));
        lineEdit_11 = new QLineEdit(groupBox_4);
        lineEdit_11->setObjectName(QString::fromUtf8("lineEdit_11"));
        lineEdit_11->setGeometry(QRect(90, 170, 113, 25));
        lineEdit_12 = new QLineEdit(groupBox_4);
        lineEdit_12->setObjectName(QString::fromUtf8("lineEdit_12"));
        lineEdit_12->setGeometry(QRect(90, 210, 113, 25));

        gridLayout_25->addWidget(groupBox_4, 0, 1, 1, 1);

        groupBox_7 = new QGroupBox(scrollAreaWidgetContents_7);
        groupBox_7->setObjectName(QString::fromUtf8("groupBox_7"));
        groupBox_7->setMinimumSize(QSize(215, 120));
        checkBox_7 = new QCheckBox(groupBox_7);
        checkBox_7->setObjectName(QString::fromUtf8("checkBox_7"));
        checkBox_7->setGeometry(QRect(20, 40, 92, 23));
        checkBox_8 = new QCheckBox(groupBox_7);
        checkBox_8->setObjectName(QString::fromUtf8("checkBox_8"));
        checkBox_8->setGeometry(QRect(20, 70, 92, 23));

        gridLayout_25->addWidget(groupBox_7, 1, 2, 1, 1);

        groupBox_5 = new QGroupBox(scrollAreaWidgetContents_7);
        groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
        groupBox_5->setMinimumSize(QSize(215, 280));
        label_12 = new QLabel(groupBox_5);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(10, 40, 91, 17));
        checkBox = new QCheckBox(groupBox_5);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setGeometry(QRect(10, 70, 92, 23));
        checkBox_2 = new QCheckBox(groupBox_5);
        checkBox_2->setObjectName(QString::fromUtf8("checkBox_2"));
        checkBox_2->setGeometry(QRect(120, 70, 92, 23));
        label_13 = new QLabel(groupBox_5);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(10, 100, 151, 17));
        checkBox_3 = new QCheckBox(groupBox_5);
        checkBox_3->setObjectName(QString::fromUtf8("checkBox_3"));
        checkBox_3->setGeometry(QRect(60, 120, 92, 23));
        checkBox_4 = new QCheckBox(groupBox_5);
        checkBox_4->setObjectName(QString::fromUtf8("checkBox_4"));
        checkBox_4->setGeometry(QRect(60, 150, 111, 23));
        checkBox_5 = new QCheckBox(groupBox_5);
        checkBox_5->setObjectName(QString::fromUtf8("checkBox_5"));
        checkBox_5->setGeometry(QRect(60, 180, 92, 23));
        label_14 = new QLabel(groupBox_5);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(10, 210, 141, 17));
        dateEdit_2 = new QDateEdit(groupBox_5);
        dateEdit_2->setObjectName(QString::fromUtf8("dateEdit_2"));
        dateEdit_2->setGeometry(QRect(40, 240, 131, 26));

        gridLayout_25->addWidget(groupBox_5, 0, 2, 1, 1);

        groupBox_6 = new QGroupBox(scrollAreaWidgetContents_7);
        groupBox_6->setObjectName(QString::fromUtf8("groupBox_6"));
        groupBox_6->setMinimumSize(QSize(200, 100));
        label_15 = new QLabel(groupBox_6);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(10, 40, 67, 17));
        label_16 = new QLabel(groupBox_6);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setGeometry(QRect(190, 40, 81, 20));
        label_17 = new QLabel(groupBox_6);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setGeometry(QRect(10, 80, 67, 17));
        dateEdit_4 = new QDateEdit(groupBox_6);
        dateEdit_4->setObjectName(QString::fromUtf8("dateEdit_4"));
        dateEdit_4->setGeometry(QRect(60, 35, 121, 31));
        lineEdit_13 = new QLineEdit(groupBox_6);
        lineEdit_13->setObjectName(QString::fromUtf8("lineEdit_13"));
        lineEdit_13->setGeometry(QRect(270, 34, 101, 31));
        comboBox_3 = new QComboBox(groupBox_6);
        comboBox_3->setObjectName(QString::fromUtf8("comboBox_3"));
        comboBox_3->setGeometry(QRect(60, 80, 311, 25));

        gridLayout_25->addWidget(groupBox_6, 1, 0, 1, 1);

        groupBox_9 = new QGroupBox(scrollAreaWidgetContents_7);
        groupBox_9->setObjectName(QString::fromUtf8("groupBox_9"));
        groupBox_9->setMinimumSize(QSize(380, 250));
        label_21 = new QLabel(groupBox_9);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        label_21->setGeometry(QRect(10, 30, 131, 17));
        lineEdit_14 = new QLineEdit(groupBox_9);
        lineEdit_14->setObjectName(QString::fromUtf8("lineEdit_14"));
        lineEdit_14->setGeometry(QRect(50, 60, 291, 25));
        label_22 = new QLabel(groupBox_9);
        label_22->setObjectName(QString::fromUtf8("label_22"));
        label_22->setGeometry(QRect(10, 100, 101, 17));
        label_23 = new QLabel(groupBox_9);
        label_23->setObjectName(QString::fromUtf8("label_23"));
        label_23->setGeometry(QRect(10, 130, 67, 17));
        label_24 = new QLabel(groupBox_9);
        label_24->setObjectName(QString::fromUtf8("label_24"));
        label_24->setGeometry(QRect(170, 130, 67, 17));
        label_25 = new QLabel(groupBox_9);
        label_25->setObjectName(QString::fromUtf8("label_25"));
        label_25->setGeometry(QRect(10, 160, 91, 17));
        label_26 = new QLabel(groupBox_9);
        label_26->setObjectName(QString::fromUtf8("label_26"));
        label_26->setGeometry(QRect(10, 190, 67, 17));
        label_27 = new QLabel(groupBox_9);
        label_27->setObjectName(QString::fromUtf8("label_27"));
        label_27->setGeometry(QRect(170, 190, 67, 17));
        label_28 = new QLabel(groupBox_9);
        label_28->setObjectName(QString::fromUtf8("label_28"));
        label_28->setGeometry(QRect(10, 220, 91, 17));
        dateEdit_5 = new QDateEdit(groupBox_9);
        dateEdit_5->setObjectName(QString::fromUtf8("dateEdit_5"));
        dateEdit_5->setGeometry(QRect(60, 120, 101, 31));
        dateEdit_6 = new QDateEdit(groupBox_9);
        dateEdit_6->setObjectName(QString::fromUtf8("dateEdit_6"));
        dateEdit_6->setGeometry(QRect(60, 180, 101, 31));
        lineEdit_15 = new QLineEdit(groupBox_9);
        lineEdit_15->setObjectName(QString::fromUtf8("lineEdit_15"));
        lineEdit_15->setGeometry(QRect(220, 124, 151, 31));
        lineEdit_16 = new QLineEdit(groupBox_9);
        lineEdit_16->setObjectName(QString::fromUtf8("lineEdit_16"));
        lineEdit_16->setGeometry(QRect(220, 180, 151, 31));
        lineEdit_17 = new QLineEdit(groupBox_9);
        lineEdit_17->setObjectName(QString::fromUtf8("lineEdit_17"));
        lineEdit_17->setGeometry(QRect(100, 220, 271, 25));

        gridLayout_25->addWidget(groupBox_9, 2, 0, 1, 1);

        groupBox_3 = new QGroupBox(scrollAreaWidgetContents_7);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setMinimumSize(QSize(380, 245));
        label_5 = new QLabel(groupBox_3);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(10, 50, 67, 17));
        label_6 = new QLabel(groupBox_3);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(10, 80, 121, 17));
        label_7 = new QLabel(groupBox_3);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(10, 120, 67, 17));
        label_18 = new QLabel(groupBox_3);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setGeometry(QRect(10, 170, 67, 17));
        label_19 = new QLabel(groupBox_3);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setGeometry(QRect(10, 200, 131, 17));
        lineEdit_3 = new QLineEdit(groupBox_3);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(150, 40, 221, 25));
        lineEdit_4 = new QLineEdit(groupBox_3);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(150, 80, 221, 25));
        lineEdit_5 = new QLineEdit(groupBox_3);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(150, 120, 221, 25));
        lineEdit_6 = new QLineEdit(groupBox_3);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(150, 160, 221, 25));
        lineEdit_7 = new QLineEdit(groupBox_3);
        lineEdit_7->setObjectName(QString::fromUtf8("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(150, 200, 221, 25));

        gridLayout_25->addWidget(groupBox_3, 0, 0, 1, 1);

        groupBox_10 = new QGroupBox(scrollAreaWidgetContents_7);
        groupBox_10->setObjectName(QString::fromUtf8("groupBox_10"));
        groupBox_10->setMinimumSize(QSize(210, 250));
        checkBox_9 = new QCheckBox(groupBox_10);
        checkBox_9->setObjectName(QString::fromUtf8("checkBox_9"));
        checkBox_9->setGeometry(QRect(20, 40, 101, 23));
        checkBox_10 = new QCheckBox(groupBox_10);
        checkBox_10->setObjectName(QString::fromUtf8("checkBox_10"));
        checkBox_10->setGeometry(QRect(20, 70, 92, 23));
        checkBox_11 = new QCheckBox(groupBox_10);
        checkBox_11->setObjectName(QString::fromUtf8("checkBox_11"));
        checkBox_11->setGeometry(QRect(20, 100, 111, 23));
        checkBox_12 = new QCheckBox(groupBox_10);
        checkBox_12->setObjectName(QString::fromUtf8("checkBox_12"));
        checkBox_12->setGeometry(QRect(20, 130, 92, 23));
        checkBox_13 = new QCheckBox(groupBox_10);
        checkBox_13->setObjectName(QString::fromUtf8("checkBox_13"));
        checkBox_13->setGeometry(QRect(20, 160, 92, 23));

        gridLayout_25->addWidget(groupBox_10, 2, 1, 1, 1);

        groupBox_11 = new QGroupBox(scrollAreaWidgetContents_7);
        groupBox_11->setObjectName(QString::fromUtf8("groupBox_11"));
        groupBox_11->setMinimumSize(QSize(215, 250));
        verticalLayout_8 = new QVBoxLayout(groupBox_11);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        pushButton_10 = new QPushButton(groupBox_11);
        pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));

        verticalLayout_8->addWidget(pushButton_10);

        textBrowser = new QTextBrowser(groupBox_11);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));

        verticalLayout_8->addWidget(textBrowser);


        gridLayout_25->addWidget(groupBox_11, 2, 2, 1, 1);

        scrollArea_3->setWidget(scrollAreaWidgetContents_7);

        horizontalLayout_11->addWidget(scrollArea_3);


        verticalLayout_7->addWidget(widget_14);

        widget_15 = new QWidget(scrollAreaWidgetContents_3);
        widget_15->setObjectName(QString::fromUtf8("widget_15"));
        widget_15->setMinimumSize(QSize(0, 24));
        horizontalLayout_12 = new QHBoxLayout(widget_15);
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        horizontalLayout_12->setContentsMargins(0, 0, -1, 0);
        toolButton = new QToolButton(widget_15);
        toolButton->setObjectName(QString::fromUtf8("toolButton"));

        horizontalLayout_12->addWidget(toolButton);

        toolButton_2 = new QToolButton(widget_15);
        toolButton_2->setObjectName(QString::fromUtf8("toolButton_2"));

        horizontalLayout_12->addWidget(toolButton_2);

        toolButton_3 = new QToolButton(widget_15);
        toolButton_3->setObjectName(QString::fromUtf8("toolButton_3"));

        horizontalLayout_12->addWidget(toolButton_3);

        toolButton_4 = new QToolButton(widget_15);
        toolButton_4->setObjectName(QString::fromUtf8("toolButton_4"));

        horizontalLayout_12->addWidget(toolButton_4);

        toolButton_5 = new QToolButton(widget_15);
        toolButton_5->setObjectName(QString::fromUtf8("toolButton_5"));

        horizontalLayout_12->addWidget(toolButton_5);


        verticalLayout_7->addWidget(widget_15);

        scrollArea_2->setWidget(scrollAreaWidgetContents_3);

        gridLayout->addWidget(scrollArea_2, 0, 0, 1, 1);

        barInfo->addTab(Identite, QString());
        cotisation = new QWidget();
        cotisation->setObjectName(QString::fromUtf8("cotisation"));
        gridLayout_5 = new QGridLayout(cotisation);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        prenomCotisation = new QLabel(cotisation);
        prenomCotisation->setObjectName(QString::fromUtf8("prenomCotisation"));
        prenomCotisation->setMinimumSize(QSize(0, 30));
        prenomCotisation->setMaximumSize(QSize(100, 30));

        gridLayout_5->addWidget(prenomCotisation, 1, 0, 1, 1);

        groupBox_19 = new QGroupBox(cotisation);
        groupBox_19->setObjectName(QString::fromUtf8("groupBox_19"));
        gridLayout_27 = new QGridLayout(groupBox_19);
        gridLayout_27->setObjectName(QString::fromUtf8("gridLayout_27"));
        gridLayout_27->setHorizontalSpacing(0);
        gridLayout_27->setContentsMargins(0, 0, 0, 0);
        scrollArea_5 = new QScrollArea(groupBox_19);
        scrollArea_5->setObjectName(QString::fromUtf8("scrollArea_5"));
        scrollArea_5->setWidgetResizable(true);
        scrollAreaWidgetContents_9 = new QWidget();
        scrollAreaWidgetContents_9->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_9"));
        scrollAreaWidgetContents_9->setGeometry(QRect(0, 0, 729, 520));
        gridLayout_28 = new QGridLayout(scrollAreaWidgetContents_9);
        gridLayout_28->setObjectName(QString::fromUtf8("gridLayout_28"));
        label_90 = new QLabel(scrollAreaWidgetContents_9);
        label_90->setObjectName(QString::fromUtf8("label_90"));
        label_90->setMinimumSize(QSize(0, 30));
        label_90->setMaximumSize(QSize(100, 16777215));

        gridLayout_28->addWidget(label_90, 0, 0, 1, 1);

        groupBox_20 = new QGroupBox(scrollAreaWidgetContents_9);
        groupBox_20->setObjectName(QString::fromUtf8("groupBox_20"));
        groupBox_20->setMinimumSize(QSize(0, 200));
        gridLayout_16 = new QGridLayout(groupBox_20);
        gridLayout_16->setObjectName(QString::fromUtf8("gridLayout_16"));
        lineEdit_59 = new QLineEdit(groupBox_20);
        lineEdit_59->setObjectName(QString::fromUtf8("lineEdit_59"));
        lineEdit_59->setMinimumSize(QSize(0, 30));
        lineEdit_59->setMaximumSize(QSize(500, 16777215));

        gridLayout_16->addWidget(lineEdit_59, 3, 5, 1, 1);

        label_89 = new QLabel(groupBox_20);
        label_89->setObjectName(QString::fromUtf8("label_89"));
        label_89->setMinimumSize(QSize(0, 30));

        gridLayout_16->addWidget(label_89, 3, 6, 1, 1);

        checkBox_24 = new QCheckBox(groupBox_20);
        checkBox_24->setObjectName(QString::fromUtf8("checkBox_24"));
        checkBox_24->setMinimumSize(QSize(0, 30));

        gridLayout_16->addWidget(checkBox_24, 3, 3, 1, 1);

        label_84 = new QLabel(groupBox_20);
        label_84->setObjectName(QString::fromUtf8("label_84"));

        gridLayout_16->addWidget(label_84, 1, 4, 1, 1);

        checkBox_25 = new QCheckBox(groupBox_20);
        checkBox_25->setObjectName(QString::fromUtf8("checkBox_25"));
        checkBox_25->setMinimumSize(QSize(0, 30));

        gridLayout_16->addWidget(checkBox_25, 2, 3, 1, 1);

        lineEdit_61 = new QLineEdit(groupBox_20);
        lineEdit_61->setObjectName(QString::fromUtf8("lineEdit_61"));
        lineEdit_61->setMinimumSize(QSize(0, 30));
        lineEdit_61->setMaximumSize(QSize(100, 16777215));

        gridLayout_16->addWidget(lineEdit_61, 2, 7, 1, 1);

        label_88 = new QLabel(groupBox_20);
        label_88->setObjectName(QString::fromUtf8("label_88"));
        label_88->setMinimumSize(QSize(0, 30));

        gridLayout_16->addWidget(label_88, 2, 6, 1, 1);

        checkBox_23 = new QCheckBox(groupBox_20);
        checkBox_23->setObjectName(QString::fromUtf8("checkBox_23"));
        checkBox_23->setMinimumSize(QSize(0, 30));

        gridLayout_16->addWidget(checkBox_23, 1, 3, 1, 1);

        lineEdit_62 = new QLineEdit(groupBox_20);
        lineEdit_62->setObjectName(QString::fromUtf8("lineEdit_62"));
        lineEdit_62->setMinimumSize(QSize(0, 30));
        lineEdit_62->setMaximumSize(QSize(100, 16777215));

        gridLayout_16->addWidget(lineEdit_62, 3, 7, 1, 1);

        label_86 = new QLabel(groupBox_20);
        label_86->setObjectName(QString::fromUtf8("label_86"));

        gridLayout_16->addWidget(label_86, 3, 4, 1, 1);

        label_85 = new QLabel(groupBox_20);
        label_85->setObjectName(QString::fromUtf8("label_85"));

        gridLayout_16->addWidget(label_85, 2, 4, 1, 1);

        lineEdit_58 = new QLineEdit(groupBox_20);
        lineEdit_58->setObjectName(QString::fromUtf8("lineEdit_58"));
        lineEdit_58->setMinimumSize(QSize(0, 30));
        lineEdit_58->setMaximumSize(QSize(500, 16777215));

        gridLayout_16->addWidget(lineEdit_58, 2, 5, 1, 1);

        label_87 = new QLabel(groupBox_20);
        label_87->setObjectName(QString::fromUtf8("label_87"));
        label_87->setMinimumSize(QSize(0, 30));

        gridLayout_16->addWidget(label_87, 1, 6, 1, 1);

        lineEdit_60 = new QLineEdit(groupBox_20);
        lineEdit_60->setObjectName(QString::fromUtf8("lineEdit_60"));
        lineEdit_60->setMinimumSize(QSize(0, 30));
        lineEdit_60->setMaximumSize(QSize(100, 16777215));

        gridLayout_16->addWidget(lineEdit_60, 1, 7, 1, 1);

        lineEdit_57 = new QLineEdit(groupBox_20);
        lineEdit_57->setObjectName(QString::fromUtf8("lineEdit_57"));
        lineEdit_57->setMinimumSize(QSize(0, 30));
        lineEdit_57->setMaximumSize(QSize(500, 16777215));

        gridLayout_16->addWidget(lineEdit_57, 1, 5, 1, 1);


        gridLayout_28->addWidget(groupBox_20, 3, 0, 1, 5);

        lineEdit_63 = new QLineEdit(scrollAreaWidgetContents_9);
        lineEdit_63->setObjectName(QString::fromUtf8("lineEdit_63"));
        lineEdit_63->setMinimumSize(QSize(0, 30));
        lineEdit_63->setMaximumSize(QSize(100, 30));

        gridLayout_28->addWidget(lineEdit_63, 0, 1, 1, 1);

        widget_19 = new QWidget(scrollAreaWidgetContents_9);
        widget_19->setObjectName(QString::fromUtf8("widget_19"));
        widget_19->setMinimumSize(QSize(500, 200));
        gridLayout_17 = new QGridLayout(widget_19);
        gridLayout_17->setObjectName(QString::fromUtf8("gridLayout_17"));
        lineEdit_79 = new QLineEdit(widget_19);
        lineEdit_79->setObjectName(QString::fromUtf8("lineEdit_79"));
        lineEdit_79->setMinimumSize(QSize(0, 30));

        gridLayout_17->addWidget(lineEdit_79, 2, 2, 1, 1);

        lineEdit_85 = new QLineEdit(widget_19);
        lineEdit_85->setObjectName(QString::fromUtf8("lineEdit_85"));
        lineEdit_85->setMinimumSize(QSize(0, 30));

        gridLayout_17->addWidget(lineEdit_85, 4, 2, 1, 1);

        lineEdit_64 = new QLineEdit(widget_19);
        lineEdit_64->setObjectName(QString::fromUtf8("lineEdit_64"));
        lineEdit_64->setMinimumSize(QSize(0, 30));

        gridLayout_17->addWidget(lineEdit_64, 0, 2, 1, 1);

        lineEdit_80 = new QLineEdit(widget_19);
        lineEdit_80->setObjectName(QString::fromUtf8("lineEdit_80"));
        lineEdit_80->setMinimumSize(QSize(0, 30));

        gridLayout_17->addWidget(lineEdit_80, 2, 4, 1, 1);

        lineEdit_84 = new QLineEdit(widget_19);
        lineEdit_84->setObjectName(QString::fromUtf8("lineEdit_84"));
        lineEdit_84->setMinimumSize(QSize(0, 30));

        gridLayout_17->addWidget(lineEdit_84, 5, 4, 1, 1);

        label_95 = new QLabel(widget_19);
        label_95->setObjectName(QString::fromUtf8("label_95"));

        gridLayout_17->addWidget(label_95, 4, 1, 1, 1);

        label_93 = new QLabel(widget_19);
        label_93->setObjectName(QString::fromUtf8("label_93"));

        gridLayout_17->addWidget(label_93, 2, 1, 1, 1);

        label_94 = new QLabel(widget_19);
        label_94->setObjectName(QString::fromUtf8("label_94"));

        gridLayout_17->addWidget(label_94, 3, 1, 1, 1);

        lineEdit_65 = new QLineEdit(widget_19);
        lineEdit_65->setObjectName(QString::fromUtf8("lineEdit_65"));
        lineEdit_65->setMinimumSize(QSize(0, 30));

        gridLayout_17->addWidget(lineEdit_65, 1, 2, 1, 1);

        label_116 = new QLabel(widget_19);
        label_116->setObjectName(QString::fromUtf8("label_116"));

        gridLayout_17->addWidget(label_116, 2, 3, 1, 1);

        lineEdit_86 = new QLineEdit(widget_19);
        lineEdit_86->setObjectName(QString::fromUtf8("lineEdit_86"));
        lineEdit_86->setMinimumSize(QSize(0, 30));

        gridLayout_17->addWidget(lineEdit_86, 4, 4, 1, 1);

        checkBox_33 = new QCheckBox(widget_19);
        checkBox_33->setObjectName(QString::fromUtf8("checkBox_33"));

        gridLayout_17->addWidget(checkBox_33, 2, 0, 1, 1);

        checkBox_35 = new QCheckBox(widget_19);
        checkBox_35->setObjectName(QString::fromUtf8("checkBox_35"));

        gridLayout_17->addWidget(checkBox_35, 1, 0, 1, 1);

        label_115 = new QLabel(widget_19);
        label_115->setObjectName(QString::fromUtf8("label_115"));

        gridLayout_17->addWidget(label_115, 5, 1, 1, 1);

        label_117 = new QLabel(widget_19);
        label_117->setObjectName(QString::fromUtf8("label_117"));

        gridLayout_17->addWidget(label_117, 3, 3, 1, 1);

        label_91 = new QLabel(widget_19);
        label_91->setObjectName(QString::fromUtf8("label_91"));

        gridLayout_17->addWidget(label_91, 0, 1, 1, 1);

        label_92 = new QLabel(widget_19);
        label_92->setObjectName(QString::fromUtf8("label_92"));

        gridLayout_17->addWidget(label_92, 1, 1, 1, 1);

        checkBox_34 = new QCheckBox(widget_19);
        checkBox_34->setObjectName(QString::fromUtf8("checkBox_34"));

        gridLayout_17->addWidget(checkBox_34, 0, 0, 1, 1);

        lineEdit_82 = new QLineEdit(widget_19);
        lineEdit_82->setObjectName(QString::fromUtf8("lineEdit_82"));
        lineEdit_82->setMinimumSize(QSize(0, 30));

        gridLayout_17->addWidget(lineEdit_82, 3, 4, 1, 1);

        lineEdit_81 = new QLineEdit(widget_19);
        lineEdit_81->setObjectName(QString::fromUtf8("lineEdit_81"));
        lineEdit_81->setMinimumSize(QSize(0, 30));

        gridLayout_17->addWidget(lineEdit_81, 3, 2, 1, 1);

        lineEdit_83 = new QLineEdit(widget_19);
        lineEdit_83->setObjectName(QString::fromUtf8("lineEdit_83"));
        lineEdit_83->setMinimumSize(QSize(0, 30));

        gridLayout_17->addWidget(lineEdit_83, 5, 2, 1, 1);

        label_118 = new QLabel(widget_19);
        label_118->setObjectName(QString::fromUtf8("label_118"));

        gridLayout_17->addWidget(label_118, 4, 3, 1, 1);

        label_119 = new QLabel(widget_19);
        label_119->setObjectName(QString::fromUtf8("label_119"));

        gridLayout_17->addWidget(label_119, 5, 3, 1, 1);


        gridLayout_28->addWidget(widget_19, 1, 0, 2, 3);

        widget_23 = new QWidget(scrollAreaWidgetContents_9);
        widget_23->setObjectName(QString::fromUtf8("widget_23"));
        widget_23->setMaximumSize(QSize(16777215, 16777215));
        verticalLayout_12 = new QVBoxLayout(widget_23);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        pushButton_24 = new QPushButton(widget_23);
        pushButton_24->setObjectName(QString::fromUtf8("pushButton_24"));
        pushButton_24->setMinimumSize(QSize(0, 40));

        verticalLayout_12->addWidget(pushButton_24);

        pushButton_27 = new QPushButton(widget_23);
        pushButton_27->setObjectName(QString::fromUtf8("pushButton_27"));
        pushButton_27->setMinimumSize(QSize(0, 40));

        verticalLayout_12->addWidget(pushButton_27);

        pushButton_26 = new QPushButton(widget_23);
        pushButton_26->setObjectName(QString::fromUtf8("pushButton_26"));
        pushButton_26->setMinimumSize(QSize(0, 40));

        verticalLayout_12->addWidget(pushButton_26);

        pushButton_25 = new QPushButton(widget_23);
        pushButton_25->setObjectName(QString::fromUtf8("pushButton_25"));
        pushButton_25->setMinimumSize(QSize(0, 40));

        verticalLayout_12->addWidget(pushButton_25);


        gridLayout_28->addWidget(widget_23, 0, 3, 2, 2);

        scrollArea_5->setWidget(scrollAreaWidgetContents_9);

        gridLayout_27->addWidget(scrollArea_5, 0, 0, 1, 1);


        gridLayout_5->addWidget(groupBox_19, 3, 0, 1, 3);

        EditNomCotisation = new QLineEdit(cotisation);
        EditNomCotisation->setObjectName(QString::fromUtf8("EditNomCotisation"));
        EditNomCotisation->setMinimumSize(QSize(0, 30));
        EditNomCotisation->setMaximumSize(QSize(200, 30));

        gridLayout_5->addWidget(EditNomCotisation, 0, 1, 1, 1);

        EditPrenomCotisation = new QLineEdit(cotisation);
        EditPrenomCotisation->setObjectName(QString::fromUtf8("EditPrenomCotisation"));
        EditPrenomCotisation->setMinimumSize(QSize(0, 30));
        EditPrenomCotisation->setMaximumSize(QSize(200, 30));

        gridLayout_5->addWidget(EditPrenomCotisation, 1, 1, 1, 1);

        nomCotisation = new QLabel(cotisation);
        nomCotisation->setObjectName(QString::fromUtf8("nomCotisation"));
        nomCotisation->setMinimumSize(QSize(100, 30));
        nomCotisation->setMaximumSize(QSize(100, 30));

        gridLayout_5->addWidget(nomCotisation, 0, 0, 1, 1);

        widget_17 = new QWidget(cotisation);
        widget_17->setObjectName(QString::fromUtf8("widget_17"));
        widget_17->setMinimumSize(QSize(0, 150));
        widget_17->setMaximumSize(QSize(16777215, 150));
        widget_17->setSizeIncrement(QSize(0, 100));
        horizontalLayout_31 = new QHBoxLayout(widget_17);
        horizontalLayout_31->setSpacing(0);
        horizontalLayout_31->setObjectName(QString::fromUtf8("horizontalLayout_31"));
        horizontalLayout_31->setContentsMargins(0, 0, 0, 0);
        pushButton_20 = new QPushButton(widget_17);
        pushButton_20->setObjectName(QString::fromUtf8("pushButton_20"));
        pushButton_20->setMaximumSize(QSize(40, 40));

        horizontalLayout_31->addWidget(pushButton_20);

        pushButton_18 = new QPushButton(widget_17);
        pushButton_18->setObjectName(QString::fromUtf8("pushButton_18"));
        pushButton_18->setMaximumSize(QSize(40, 40));

        horizontalLayout_31->addWidget(pushButton_18);

        pushButton_19 = new QPushButton(widget_17);
        pushButton_19->setObjectName(QString::fromUtf8("pushButton_19"));
        pushButton_19->setMinimumSize(QSize(40, 40));
        pushButton_19->setMaximumSize(QSize(40, 40));

        horizontalLayout_31->addWidget(pushButton_19);


        gridLayout_5->addWidget(widget_17, 2, 0, 1, 2);

        groupBox_18 = new QGroupBox(cotisation);
        groupBox_18->setObjectName(QString::fromUtf8("groupBox_18"));
        gridLayout_12 = new QGridLayout(groupBox_18);
        gridLayout_12->setSpacing(0);
        gridLayout_12->setObjectName(QString::fromUtf8("gridLayout_12"));
        gridLayout_12->setContentsMargins(0, 0, 0, 0);
        scrollArea_4 = new QScrollArea(groupBox_18);
        scrollArea_4->setObjectName(QString::fromUtf8("scrollArea_4"));
        scrollArea_4->setWidgetResizable(true);
        scrollAreaWidgetContents_8 = new QWidget();
        scrollAreaWidgetContents_8->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_8"));
        scrollAreaWidgetContents_8->setGeometry(QRect(0, 0, 417, 228));
        gridLayout_26 = new QGridLayout(scrollAreaWidgetContents_8);
        gridLayout_26->setObjectName(QString::fromUtf8("gridLayout_26"));
        label_83 = new QLabel(scrollAreaWidgetContents_8);
        label_83->setObjectName(QString::fromUtf8("label_83"));
        label_83->setMinimumSize(QSize(0, 30));
        label_83->setMaximumSize(QSize(130, 30));

        gridLayout_26->addWidget(label_83, 4, 0, 1, 1);

        label_78 = new QLabel(scrollAreaWidgetContents_8);
        label_78->setObjectName(QString::fromUtf8("label_78"));
        label_78->setMinimumSize(QSize(0, 30));
        label_78->setMaximumSize(QSize(130, 30));

        gridLayout_26->addWidget(label_78, 0, 0, 1, 1);

        lineEdit_51 = new QLineEdit(scrollAreaWidgetContents_8);
        lineEdit_51->setObjectName(QString::fromUtf8("lineEdit_51"));
        lineEdit_51->setMinimumSize(QSize(0, 30));
        lineEdit_51->setMaximumSize(QSize(200, 30));

        gridLayout_26->addWidget(lineEdit_51, 0, 1, 1, 1);

        widget_18 = new QWidget(scrollAreaWidgetContents_8);
        widget_18->setObjectName(QString::fromUtf8("widget_18"));
        widget_18->setMinimumSize(QSize(100, 0));
        widget_18->setMaximumSize(QSize(500, 16777215));
        verticalLayout_31 = new QVBoxLayout(widget_18);
        verticalLayout_31->setSpacing(0);
        verticalLayout_31->setObjectName(QString::fromUtf8("verticalLayout_31"));
        verticalLayout_31->setContentsMargins(0, 0, 0, 0);
        nouvelleCotisation = new QPushButton(widget_18);
        nouvelleCotisation->setObjectName(QString::fromUtf8("nouvelleCotisation"));
        nouvelleCotisation->setMinimumSize(QSize(0, 35));
        nouvelleCotisation->setMaximumSize(QSize(16777215, 35));

        verticalLayout_31->addWidget(nouvelleCotisation);

        dernierCotisation = new QPushButton(widget_18);
        dernierCotisation->setObjectName(QString::fromUtf8("dernierCotisation"));
        dernierCotisation->setMinimumSize(QSize(0, 35));
        dernierCotisation->setMaximumSize(QSize(16777215, 35));

        verticalLayout_31->addWidget(dernierCotisation);

        precedentCotisation = new QPushButton(widget_18);
        precedentCotisation->setObjectName(QString::fromUtf8("precedentCotisation"));
        precedentCotisation->setMinimumSize(QSize(0, 35));
        precedentCotisation->setMaximumSize(QSize(16777215, 35));

        verticalLayout_31->addWidget(precedentCotisation);

        suivantCotisation = new QPushButton(widget_18);
        suivantCotisation->setObjectName(QString::fromUtf8("suivantCotisation"));
        suivantCotisation->setMinimumSize(QSize(0, 35));
        suivantCotisation->setMaximumSize(QSize(16777215, 35));

        verticalLayout_31->addWidget(suivantCotisation);


        gridLayout_26->addWidget(widget_18, 0, 2, 5, 1);

        label_82 = new QLabel(scrollAreaWidgetContents_8);
        label_82->setObjectName(QString::fromUtf8("label_82"));
        label_82->setMinimumSize(QSize(0, 30));
        label_82->setMaximumSize(QSize(130, 30));

        gridLayout_26->addWidget(label_82, 3, 0, 1, 1);

        lineEdit_56 = new QLineEdit(scrollAreaWidgetContents_8);
        lineEdit_56->setObjectName(QString::fromUtf8("lineEdit_56"));
        lineEdit_56->setMaximumSize(QSize(200, 30));

        gridLayout_26->addWidget(lineEdit_56, 4, 1, 1, 1);

        lineEdit_55 = new QLineEdit(scrollAreaWidgetContents_8);
        lineEdit_55->setObjectName(QString::fromUtf8("lineEdit_55"));
        lineEdit_55->setMaximumSize(QSize(200, 30));

        gridLayout_26->addWidget(lineEdit_55, 3, 1, 1, 1);

        lineEdit_54 = new QLineEdit(scrollAreaWidgetContents_8);
        lineEdit_54->setObjectName(QString::fromUtf8("lineEdit_54"));
        lineEdit_54->setMinimumSize(QSize(0, 30));
        lineEdit_54->setMaximumSize(QSize(200, 30));

        gridLayout_26->addWidget(lineEdit_54, 2, 1, 1, 1);

        label_81 = new QLabel(scrollAreaWidgetContents_8);
        label_81->setObjectName(QString::fromUtf8("label_81"));
        label_81->setMinimumSize(QSize(0, 30));
        label_81->setMaximumSize(QSize(130, 30));

        gridLayout_26->addWidget(label_81, 1, 0, 1, 1);

        label_80 = new QLabel(scrollAreaWidgetContents_8);
        label_80->setObjectName(QString::fromUtf8("label_80"));
        label_80->setMaximumSize(QSize(130, 30));

        gridLayout_26->addWidget(label_80, 2, 0, 1, 1);

        lineEdit_52 = new QLineEdit(scrollAreaWidgetContents_8);
        lineEdit_52->setObjectName(QString::fromUtf8("lineEdit_52"));
        lineEdit_52->setMinimumSize(QSize(0, 30));
        lineEdit_52->setMaximumSize(QSize(200, 30));

        gridLayout_26->addWidget(lineEdit_52, 1, 1, 1, 1);

        lineEdit_53 = new QLineEdit(scrollAreaWidgetContents_8);
        lineEdit_53->setObjectName(QString::fromUtf8("lineEdit_53"));
        lineEdit_53->setMinimumSize(QSize(0, 30));
        lineEdit_53->setMaximumSize(QSize(200, 30));

        gridLayout_26->addWidget(lineEdit_53, 5, 1, 1, 1);

        label_79 = new QLabel(scrollAreaWidgetContents_8);
        label_79->setObjectName(QString::fromUtf8("label_79"));
        label_79->setMinimumSize(QSize(130, 30));
        label_79->setMaximumSize(QSize(130, 30));
        label_79->setSizeIncrement(QSize(0, 30));

        gridLayout_26->addWidget(label_79, 5, 0, 1, 1);

        scrollArea_4->setWidget(scrollAreaWidgetContents_8);

        gridLayout_12->addWidget(scrollArea_4, 0, 0, 1, 1);


        gridLayout_5->addWidget(groupBox_18, 0, 2, 3, 1);

        barInfo->addTab(cotisation, QString());
        dossier = new QWidget();
        dossier->setObjectName(QString::fromUtf8("dossier"));
        gridLayout_8 = new QGridLayout(dossier);
        gridLayout_8->setObjectName(QString::fromUtf8("gridLayout_8"));
        barInfo->addTab(dossier, QString());
        enfant = new QWidget();
        enfant->setObjectName(QString::fromUtf8("enfant"));
        gridLayout_3 = new QGridLayout(enfant);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        widget_41 = new QWidget(enfant);
        widget_41->setObjectName(QString::fromUtf8("widget_41"));
        widget_41->setStyleSheet(QString::fromUtf8("#ordre{\n"
"	border:2px solid blue;\n"
"}\n"
"#Nom{\n"
"	border:2px solid blue;\n"
"}\n"
"#Prenom{\n"
"	border:2px solid blue;\n"
"}\n"
"#Date{\n"
"	border:2px solid blue;\n"
"}\n"
"#activite{\n"
"	border:2px solid blue;\n"
"}"));
        verticalLayout_24 = new QVBoxLayout(widget_41);
        verticalLayout_24->setObjectName(QString::fromUtf8("verticalLayout_24"));
        widget_42 = new QWidget(widget_41);
        widget_42->setObjectName(QString::fromUtf8("widget_42"));
        gridLayout_43 = new QGridLayout(widget_42);
        gridLayout_43->setObjectName(QString::fromUtf8("gridLayout_43"));
        horizontalLayout_74 = new QHBoxLayout();
        horizontalLayout_74->setObjectName(QString::fromUtf8("horizontalLayout_74"));
        label_124 = new QLabel(widget_42);
        label_124->setObjectName(QString::fromUtf8("label_124"));

        horizontalLayout_74->addWidget(label_124);

        lineEdit_124 = new QLineEdit(widget_42);
        lineEdit_124->setObjectName(QString::fromUtf8("lineEdit_124"));

        horizontalLayout_74->addWidget(lineEdit_124);


        gridLayout_43->addLayout(horizontalLayout_74, 0, 0, 1, 1);

        horizontalLayout_75 = new QHBoxLayout();
        horizontalLayout_75->setObjectName(QString::fromUtf8("horizontalLayout_75"));
        label_125 = new QLabel(widget_42);
        label_125->setObjectName(QString::fromUtf8("label_125"));

        horizontalLayout_75->addWidget(label_125);

        lineEdit_125 = new QLineEdit(widget_42);
        lineEdit_125->setObjectName(QString::fromUtf8("lineEdit_125"));

        horizontalLayout_75->addWidget(lineEdit_125);


        gridLayout_43->addLayout(horizontalLayout_75, 1, 0, 1, 1);

        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_43->addItem(horizontalSpacer_11, 0, 1, 1, 1);


        verticalLayout_24->addWidget(widget_42);

        label_126 = new QLabel(widget_41);
        label_126->setObjectName(QString::fromUtf8("label_126"));

        verticalLayout_24->addWidget(label_126);

        scrollArea_15 = new QScrollArea(widget_41);
        scrollArea_15->setObjectName(QString::fromUtf8("scrollArea_15"));
        scrollArea_15->setWidgetResizable(true);
        scrollAreaWidgetContents_19 = new QWidget();
        scrollAreaWidgetContents_19->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_19"));
        scrollAreaWidgetContents_19->setGeometry(QRect(0, 0, 731, 310));
        gridLayout_44 = new QGridLayout(scrollAreaWidgetContents_19);
        gridLayout_44->setObjectName(QString::fromUtf8("gridLayout_44"));
        lineEdit_126 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_126->setObjectName(QString::fromUtf8("lineEdit_126"));

        gridLayout_44->addWidget(lineEdit_126, 4, 2, 1, 1);

        lineEdit_127 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_127->setObjectName(QString::fromUtf8("lineEdit_127"));

        gridLayout_44->addWidget(lineEdit_127, 6, 1, 1, 1);

        ordre = new QLabel(scrollAreaWidgetContents_19);
        ordre->setObjectName(QString::fromUtf8("ordre"));

        gridLayout_44->addWidget(ordre, 0, 0, 1, 1);

        lineEdit_128 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_128->setObjectName(QString::fromUtf8("lineEdit_128"));

        gridLayout_44->addWidget(lineEdit_128, 2, 3, 1, 1);

        lineEdit_129 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_129->setObjectName(QString::fromUtf8("lineEdit_129"));

        gridLayout_44->addWidget(lineEdit_129, 2, 0, 1, 1);

        lineEdit_130 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_130->setObjectName(QString::fromUtf8("lineEdit_130"));

        gridLayout_44->addWidget(lineEdit_130, 8, 1, 1, 1);

        lineEdit_131 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_131->setObjectName(QString::fromUtf8("lineEdit_131"));

        gridLayout_44->addWidget(lineEdit_131, 8, 4, 1, 1);

        lineEdit_132 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_132->setObjectName(QString::fromUtf8("lineEdit_132"));

        gridLayout_44->addWidget(lineEdit_132, 4, 3, 1, 1);

        lineEdit_133 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_133->setObjectName(QString::fromUtf8("lineEdit_133"));

        gridLayout_44->addWidget(lineEdit_133, 7, 4, 1, 1);

        lineEdit_134 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_134->setObjectName(QString::fromUtf8("lineEdit_134"));

        gridLayout_44->addWidget(lineEdit_134, 4, 4, 1, 1);

        lineEdit_135 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_135->setObjectName(QString::fromUtf8("lineEdit_135"));

        gridLayout_44->addWidget(lineEdit_135, 8, 3, 1, 1);

        activite_2 = new QLabel(scrollAreaWidgetContents_19);
        activite_2->setObjectName(QString::fromUtf8("activite_2"));

        gridLayout_44->addWidget(activite_2, 0, 4, 1, 1);

        lineEdit_136 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_136->setObjectName(QString::fromUtf8("lineEdit_136"));

        gridLayout_44->addWidget(lineEdit_136, 7, 2, 1, 1);

        lineEdit_137 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_137->setObjectName(QString::fromUtf8("lineEdit_137"));

        gridLayout_44->addWidget(lineEdit_137, 1, 4, 1, 1);

        lineEdit_138 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_138->setObjectName(QString::fromUtf8("lineEdit_138"));

        gridLayout_44->addWidget(lineEdit_138, 1, 1, 1, 1);

        lineEdit_139 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_139->setObjectName(QString::fromUtf8("lineEdit_139"));

        gridLayout_44->addWidget(lineEdit_139, 6, 2, 1, 1);

        lineEdit_140 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_140->setObjectName(QString::fromUtf8("lineEdit_140"));

        gridLayout_44->addWidget(lineEdit_140, 7, 1, 1, 1);

        lineEdit_141 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_141->setObjectName(QString::fromUtf8("lineEdit_141"));

        gridLayout_44->addWidget(lineEdit_141, 4, 1, 1, 1);

        lineEdit_142 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_142->setObjectName(QString::fromUtf8("lineEdit_142"));

        gridLayout_44->addWidget(lineEdit_142, 1, 2, 1, 1);

        lineEdit_143 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_143->setObjectName(QString::fromUtf8("lineEdit_143"));

        gridLayout_44->addWidget(lineEdit_143, 7, 3, 1, 1);

        lineEdit_144 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_144->setObjectName(QString::fromUtf8("lineEdit_144"));

        gridLayout_44->addWidget(lineEdit_144, 4, 0, 1, 1);

        lineEdit_145 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_145->setObjectName(QString::fromUtf8("lineEdit_145"));

        gridLayout_44->addWidget(lineEdit_145, 2, 2, 1, 1);

        lineEdit_146 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_146->setObjectName(QString::fromUtf8("lineEdit_146"));

        gridLayout_44->addWidget(lineEdit_146, 1, 3, 1, 1);

        lineEdit_147 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_147->setObjectName(QString::fromUtf8("lineEdit_147"));

        gridLayout_44->addWidget(lineEdit_147, 8, 0, 1, 1);

        Date = new QLabel(scrollAreaWidgetContents_19);
        Date->setObjectName(QString::fromUtf8("Date"));

        gridLayout_44->addWidget(Date, 0, 3, 1, 1);

        lineEdit_148 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_148->setObjectName(QString::fromUtf8("lineEdit_148"));

        gridLayout_44->addWidget(lineEdit_148, 1, 0, 1, 1);

        lineEdit_149 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_149->setObjectName(QString::fromUtf8("lineEdit_149"));

        gridLayout_44->addWidget(lineEdit_149, 3, 1, 1, 1);

        lineEdit_150 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_150->setObjectName(QString::fromUtf8("lineEdit_150"));

        gridLayout_44->addWidget(lineEdit_150, 8, 2, 1, 1);

        lineEdit_151 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_151->setObjectName(QString::fromUtf8("lineEdit_151"));

        gridLayout_44->addWidget(lineEdit_151, 6, 3, 1, 1);

        lineEdit_152 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_152->setObjectName(QString::fromUtf8("lineEdit_152"));

        gridLayout_44->addWidget(lineEdit_152, 3, 3, 1, 1);

        Nom = new QLabel(scrollAreaWidgetContents_19);
        Nom->setObjectName(QString::fromUtf8("Nom"));

        gridLayout_44->addWidget(Nom, 0, 1, 1, 1);

        lineEdit_153 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_153->setObjectName(QString::fromUtf8("lineEdit_153"));

        gridLayout_44->addWidget(lineEdit_153, 7, 0, 1, 1);

        lineEdit_154 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_154->setObjectName(QString::fromUtf8("lineEdit_154"));

        gridLayout_44->addWidget(lineEdit_154, 2, 1, 1, 1);

        lineEdit_155 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_155->setObjectName(QString::fromUtf8("lineEdit_155"));

        gridLayout_44->addWidget(lineEdit_155, 2, 4, 1, 1);

        Prenom = new QLabel(scrollAreaWidgetContents_19);
        Prenom->setObjectName(QString::fromUtf8("Prenom"));

        gridLayout_44->addWidget(Prenom, 0, 2, 1, 1);

        lineEdit_156 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_156->setObjectName(QString::fromUtf8("lineEdit_156"));

        gridLayout_44->addWidget(lineEdit_156, 3, 0, 1, 1);

        lineEdit_157 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_157->setObjectName(QString::fromUtf8("lineEdit_157"));

        gridLayout_44->addWidget(lineEdit_157, 6, 0, 1, 1);

        lineEdit_158 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_158->setObjectName(QString::fromUtf8("lineEdit_158"));

        gridLayout_44->addWidget(lineEdit_158, 6, 4, 1, 1);

        lineEdit_159 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_159->setObjectName(QString::fromUtf8("lineEdit_159"));

        gridLayout_44->addWidget(lineEdit_159, 3, 4, 1, 1);

        lineEdit_160 = new QLineEdit(scrollAreaWidgetContents_19);
        lineEdit_160->setObjectName(QString::fromUtf8("lineEdit_160"));

        gridLayout_44->addWidget(lineEdit_160, 3, 2, 1, 1);

        scrollArea_15->setWidget(scrollAreaWidgetContents_19);

        verticalLayout_24->addWidget(scrollArea_15);

        widget_43 = new QWidget(widget_41);
        widget_43->setObjectName(QString::fromUtf8("widget_43"));

        verticalLayout_24->addWidget(widget_43);


        gridLayout_3->addWidget(widget_41, 0, 0, 1, 1);

        barInfo->addTab(enfant, QString());
        etudes = new QWidget();
        etudes->setObjectName(QString::fromUtf8("etudes"));
        gridLayout_40 = new QGridLayout(etudes);
        gridLayout_40->setObjectName(QString::fromUtf8("gridLayout_40"));
        frame_9 = new QFrame(etudes);
        frame_9->setObjectName(QString::fromUtf8("frame_9"));
        frame_9->setMaximumSize(QSize(16777215, 100));
        frame_9->setFrameShape(QFrame::StyledPanel);
        frame_9->setFrameShadow(QFrame::Raised);
        horizontalLayout_15 = new QHBoxLayout(frame_9);
        horizontalLayout_15->setObjectName(QString::fromUtf8("horizontalLayout_15"));
        frame_10 = new QFrame(frame_9);
        frame_10->setObjectName(QString::fromUtf8("frame_10"));
        frame_10->setFrameShape(QFrame::StyledPanel);
        frame_10->setFrameShadow(QFrame::Raised);
        horizontalLayout_16 = new QHBoxLayout(frame_10);
        horizontalLayout_16->setObjectName(QString::fromUtf8("horizontalLayout_16"));
        label_41 = new QLabel(frame_10);
        label_41->setObjectName(QString::fromUtf8("label_41"));

        horizontalLayout_16->addWidget(label_41);

        lineEdit_20 = new QLineEdit(frame_10);
        lineEdit_20->setObjectName(QString::fromUtf8("lineEdit_20"));

        horizontalLayout_16->addWidget(lineEdit_20);


        horizontalLayout_15->addWidget(frame_10);

        frame_11 = new QFrame(frame_9);
        frame_11->setObjectName(QString::fromUtf8("frame_11"));
        frame_11->setFrameShape(QFrame::StyledPanel);
        frame_11->setFrameShadow(QFrame::Raised);
        horizontalLayout_17 = new QHBoxLayout(frame_11);
        horizontalLayout_17->setObjectName(QString::fromUtf8("horizontalLayout_17"));
        label_42 = new QLabel(frame_11);
        label_42->setObjectName(QString::fromUtf8("label_42"));

        horizontalLayout_17->addWidget(label_42);

        lineEdit_21 = new QLineEdit(frame_11);
        lineEdit_21->setObjectName(QString::fromUtf8("lineEdit_21"));

        horizontalLayout_17->addWidget(lineEdit_21);


        horizontalLayout_15->addWidget(frame_11);


        gridLayout_40->addWidget(frame_9, 0, 0, 1, 1);

        frame_7 = new QFrame(etudes);
        frame_7->setObjectName(QString::fromUtf8("frame_7"));
        frame_7->setMaximumSize(QSize(16777215, 1000));
        frame_7->setFrameShape(QFrame::StyledPanel);
        frame_7->setFrameShadow(QFrame::Raised);
        horizontalLayout_13 = new QHBoxLayout(frame_7);
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        groupBox_12 = new QGroupBox(frame_7);
        groupBox_12->setObjectName(QString::fromUtf8("groupBox_12"));
        formLayout_2 = new QFormLayout(groupBox_12);
        formLayout_2->setObjectName(QString::fromUtf8("formLayout_2"));
        label_31 = new QLabel(groupBox_12);
        label_31->setObjectName(QString::fromUtf8("label_31"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, label_31);

        label_32 = new QLabel(groupBox_12);
        label_32->setObjectName(QString::fromUtf8("label_32"));

        formLayout_2->setWidget(1, QFormLayout::LabelRole, label_32);

        label_33 = new QLabel(groupBox_12);
        label_33->setObjectName(QString::fromUtf8("label_33"));

        formLayout_2->setWidget(2, QFormLayout::LabelRole, label_33);

        label_34 = new QLabel(groupBox_12);
        label_34->setObjectName(QString::fromUtf8("label_34"));

        formLayout_2->setWidget(3, QFormLayout::LabelRole, label_34);

        textEdit = new QTextEdit(groupBox_12);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));

        formLayout_2->setWidget(2, QFormLayout::FieldRole, textEdit);

        lineEdit_18 = new QLineEdit(groupBox_12);
        lineEdit_18->setObjectName(QString::fromUtf8("lineEdit_18"));

        formLayout_2->setWidget(3, QFormLayout::FieldRole, lineEdit_18);

        comboBox_4 = new QComboBox(groupBox_12);
        comboBox_4->setObjectName(QString::fromUtf8("comboBox_4"));

        formLayout_2->setWidget(1, QFormLayout::FieldRole, comboBox_4);

        dateEdit_7 = new QDateEdit(groupBox_12);
        dateEdit_7->setObjectName(QString::fromUtf8("dateEdit_7"));

        formLayout_2->setWidget(0, QFormLayout::FieldRole, dateEdit_7);


        horizontalLayout_13->addWidget(groupBox_12);

        groupBox_13 = new QGroupBox(frame_7);
        groupBox_13->setObjectName(QString::fromUtf8("groupBox_13"));
        formLayout_3 = new QFormLayout(groupBox_13);
        formLayout_3->setObjectName(QString::fromUtf8("formLayout_3"));
        label_35 = new QLabel(groupBox_13);
        label_35->setObjectName(QString::fromUtf8("label_35"));

        formLayout_3->setWidget(0, QFormLayout::LabelRole, label_35);

        label_36 = new QLabel(groupBox_13);
        label_36->setObjectName(QString::fromUtf8("label_36"));

        formLayout_3->setWidget(1, QFormLayout::LabelRole, label_36);

        label_37 = new QLabel(groupBox_13);
        label_37->setObjectName(QString::fromUtf8("label_37"));

        formLayout_3->setWidget(2, QFormLayout::LabelRole, label_37);

        label_38 = new QLabel(groupBox_13);
        label_38->setObjectName(QString::fromUtf8("label_38"));

        formLayout_3->setWidget(3, QFormLayout::LabelRole, label_38);

        comboBox_5 = new QComboBox(groupBox_13);
        comboBox_5->setObjectName(QString::fromUtf8("comboBox_5"));

        formLayout_3->setWidget(2, QFormLayout::FieldRole, comboBox_5);

        comboBox_6 = new QComboBox(groupBox_13);
        comboBox_6->setObjectName(QString::fromUtf8("comboBox_6"));

        formLayout_3->setWidget(3, QFormLayout::FieldRole, comboBox_6);

        pushButton_11 = new QPushButton(groupBox_13);
        pushButton_11->setObjectName(QString::fromUtf8("pushButton_11"));
        pushButton_11->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"	background:green;\n"
"	transition:2s;\n"
"}\n"
"QPushButton::hover{\n"
"	background:yellow;\n"
"}"));

        formLayout_3->setWidget(4, QFormLayout::FieldRole, pushButton_11);

        dateEdit_8 = new QDateEdit(groupBox_13);
        dateEdit_8->setObjectName(QString::fromUtf8("dateEdit_8"));

        formLayout_3->setWidget(0, QFormLayout::FieldRole, dateEdit_8);

        dateEdit_9 = new QDateEdit(groupBox_13);
        dateEdit_9->setObjectName(QString::fromUtf8("dateEdit_9"));

        formLayout_3->setWidget(1, QFormLayout::FieldRole, dateEdit_9);


        horizontalLayout_13->addWidget(groupBox_13);


        gridLayout_40->addWidget(frame_7, 1, 0, 1, 1);

        frame_8 = new QFrame(etudes);
        frame_8->setObjectName(QString::fromUtf8("frame_8"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(frame_8->sizePolicy().hasHeightForWidth());
        frame_8->setSizePolicy(sizePolicy);
        frame_8->setMinimumSize(QSize(0, 100));
        frame_8->setMaximumSize(QSize(16777215, 1000));
        frame_8->setFrameShape(QFrame::StyledPanel);
        frame_8->setFrameShadow(QFrame::Raised);
        horizontalLayout_14 = new QHBoxLayout(frame_8);
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        groupBox_14 = new QGroupBox(frame_8);
        groupBox_14->setObjectName(QString::fromUtf8("groupBox_14"));
        groupBox_14->setMinimumSize(QSize(0, 0));
        groupBox_14->setMaximumSize(QSize(16777215, 16777215));
        formLayout_4 = new QFormLayout(groupBox_14);
        formLayout_4->setObjectName(QString::fromUtf8("formLayout_4"));
        comboBox_7 = new QComboBox(groupBox_14);
        comboBox_7->setObjectName(QString::fromUtf8("comboBox_7"));

        formLayout_4->setWidget(1, QFormLayout::LabelRole, comboBox_7);

        lineEdit_19 = new QLineEdit(groupBox_14);
        lineEdit_19->setObjectName(QString::fromUtf8("lineEdit_19"));

        formLayout_4->setWidget(1, QFormLayout::FieldRole, lineEdit_19);

        label_39 = new QLabel(groupBox_14);
        label_39->setObjectName(QString::fromUtf8("label_39"));

        formLayout_4->setWidget(0, QFormLayout::LabelRole, label_39);

        label_40 = new QLabel(groupBox_14);
        label_40->setObjectName(QString::fromUtf8("label_40"));

        formLayout_4->setWidget(0, QFormLayout::FieldRole, label_40);


        horizontalLayout_14->addWidget(groupBox_14);

        frame_12 = new QFrame(frame_8);
        frame_12->setObjectName(QString::fromUtf8("frame_12"));
        frame_12->setFrameShape(QFrame::StyledPanel);
        frame_12->setFrameShadow(QFrame::Raised);
        gridLayout_10 = new QGridLayout(frame_12);
        gridLayout_10->setObjectName(QString::fromUtf8("gridLayout_10"));
        pushButton_12 = new QPushButton(frame_12);
        pushButton_12->setObjectName(QString::fromUtf8("pushButton_12"));

        gridLayout_10->addWidget(pushButton_12, 0, 0, 1, 1);

        pushButton_13 = new QPushButton(frame_12);
        pushButton_13->setObjectName(QString::fromUtf8("pushButton_13"));

        gridLayout_10->addWidget(pushButton_13, 0, 1, 1, 1);

        pushButton_14 = new QPushButton(frame_12);
        pushButton_14->setObjectName(QString::fromUtf8("pushButton_14"));

        gridLayout_10->addWidget(pushButton_14, 1, 0, 1, 2);


        horizontalLayout_14->addWidget(frame_12);


        gridLayout_40->addWidget(frame_8, 2, 0, 1, 1);

        barInfo->addTab(etudes, QString());
        adresse = new QWidget();
        adresse->setObjectName(QString::fromUtf8("adresse"));
        gridLayout_9 = new QGridLayout(adresse);
        gridLayout_9->setSpacing(0);
        gridLayout_9->setObjectName(QString::fromUtf8("gridLayout_9"));
        gridLayout_9->setContentsMargins(0, 0, 0, 0);
        scrollArea = new QScrollArea(adresse);
        scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
        scrollArea->setStyleSheet(QString::fromUtf8("/*QScrollArea{\n"
"	border: none;\n"
"	background-color: transparent;\n"
"}*/\n"
"\n"
"QLabel{\n"
"	border: 2px solid blue;\n"
"	background-color:rgb(214, 241, 6);\n"
"	border-radius: 3px;\n"
"	padding-left: 10px;\n"
"	padding-right: 10px;\n"
"}\n"
"\n"
"QLineEdit{\n"
"	border: 1px solid black;\n"
"	border-radius: 3px;\n"
"	padding-left: 10px\n"
"}\n"
""));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 753, 978));
        verticalLayout_5 = new QVBoxLayout(scrollAreaWidgetContents);
        verticalLayout_5->setSpacing(0);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        widget = new QWidget(scrollAreaWidgetContents);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setMinimumSize(QSize(0, 50));
        widget->setMaximumSize(QSize(16777215, 50));
        widget->setStyleSheet(QString::fromUtf8(""));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        nom = new QLabel(widget);
        nom->setObjectName(QString::fromUtf8("nom"));
        nom->setStyleSheet(QString::fromUtf8("QLabel{\n"
"	border:none;\n"
"	background-color:rgb(214, 241, 6);\n"
"	border-radius: 3px;\n"
"}"));

        horizontalLayout->addWidget(nom);

        editNoms = new QLineEdit(widget);
        editNoms->setObjectName(QString::fromUtf8("editNoms"));
        editNoms->setMinimumSize(QSize(200, 30));
        editNoms->setMaximumSize(QSize(500, 16777215));

        horizontalLayout->addWidget(editNoms);

        prenom = new QLabel(widget);
        prenom->setObjectName(QString::fromUtf8("prenom"));
        prenom->setStyleSheet(QString::fromUtf8("QLabel{\n"
"	border:none;\n"
"	background-color:rgb(214, 241, 6);\n"
"	border-radius: 3px;\n"
"}"));

        horizontalLayout->addWidget(prenom);

        editPrenoms = new QLineEdit(widget);
        editPrenoms->setObjectName(QString::fromUtf8("editPrenoms"));
        editPrenoms->setMinimumSize(QSize(200, 30));
        editPrenoms->setMaximumSize(QSize(500, 16777215));

        horizontalLayout->addWidget(editPrenoms);

        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setMaximumSize(QSize(30, 30));
        QIcon icon(QIcon::fromTheme(QString::fromUtf8("go-previous")));
        pushButton->setIcon(icon);

        horizontalLayout->addWidget(pushButton);

        pushButton_3 = new QPushButton(widget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setMaximumSize(QSize(30, 30));
        QIcon icon1(QIcon::fromTheme(QString::fromUtf8("go-next")));
        pushButton_3->setIcon(icon1);

        horizontalLayout->addWidget(pushButton_3);

        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setMaximumSize(QSize(30, 30));

        horizontalLayout->addWidget(pushButton_2);


        verticalLayout_5->addWidget(widget);

        widget_2 = new QWidget(scrollAreaWidgetContents);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        verticalLayout = new QVBoxLayout(widget_2);
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetMinimumSize);
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        AddressPeso = new QScrollArea(widget_2);
        AddressPeso->setObjectName(QString::fromUtf8("AddressPeso"));
        AddressPeso->setMinimumSize(QSize(0, 250));
        AddressPeso->setMaximumSize(QSize(16777215, 250));
        AddressPeso->setWidgetResizable(true);
        scrollAreaWidgetContents_4 = new QWidget();
        scrollAreaWidgetContents_4->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_4"));
        scrollAreaWidgetContents_4->setGeometry(QRect(0, 0, 770, 234));
        verticalLayout_2 = new QVBoxLayout(scrollAreaWidgetContents_4);
        verticalLayout_2->setSpacing(0);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        widget_3 = new QWidget(scrollAreaWidgetContents_4);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        horizontalLayout_2 = new QHBoxLayout(widget_3);
        horizontalLayout_2->setSpacing(0);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        adressePrecedent = new QPushButton(widget_3);
        adressePrecedent->setObjectName(QString::fromUtf8("adressePrecedent"));
        adressePrecedent->setMinimumSize(QSize(0, 30));

        horizontalLayout_2->addWidget(adressePrecedent);

        adresseSuivant = new QPushButton(widget_3);
        adresseSuivant->setObjectName(QString::fromUtf8("adresseSuivant"));
        adresseSuivant->setMinimumSize(QSize(0, 30));

        horizontalLayout_2->addWidget(adresseSuivant);

        dernierAdresse = new QPushButton(widget_3);
        dernierAdresse->setObjectName(QString::fromUtf8("dernierAdresse"));
        dernierAdresse->setMinimumSize(QSize(0, 30));

        horizontalLayout_2->addWidget(dernierAdresse);

        horizontalSpacer = new QSpacerItem(30, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        pushButton_6 = new QPushButton(widget_3);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setMinimumSize(QSize(30, 30));
        pushButton_6->setMaximumSize(QSize(40, 30));

        horizontalLayout_2->addWidget(pushButton_6);


        verticalLayout_2->addWidget(widget_3);

        adressePersonnelle = new QLabel(scrollAreaWidgetContents_4);
        adressePersonnelle->setObjectName(QString::fromUtf8("adressePersonnelle"));
        adressePersonnelle->setMinimumSize(QSize(0, 30));
        adressePersonnelle->setMaximumSize(QSize(16777215, 30));
        adressePersonnelle->setStyleSheet(QString::fromUtf8("QLabel{\n"
"	background-color: rgb(2, 255, 255);\n"
"	border:none;\n"
"}"));

        verticalLayout_2->addWidget(adressePersonnelle, 0, Qt::AlignHCenter);

        widget_4 = new QWidget(scrollAreaWidgetContents_4);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        gridLayout_18 = new QGridLayout(widget_4);
        gridLayout_18->setObjectName(QString::fromUtf8("gridLayout_18"));
        gridLayout_18->setHorizontalSpacing(6);
        gridLayout_18->setContentsMargins(-1, -1, -1, 9);
        faxPersonnelle = new QLabel(widget_4);
        faxPersonnelle->setObjectName(QString::fromUtf8("faxPersonnelle"));
        faxPersonnelle->setMinimumSize(QSize(0, 30));

        gridLayout_18->addWidget(faxPersonnelle, 3, 2, 1, 1);

        EditFokotanyPerso = new QLineEdit(widget_4);
        EditFokotanyPerso->setObjectName(QString::fromUtf8("EditFokotanyPerso"));
        EditFokotanyPerso->setMinimumSize(QSize(200, 30));

        gridLayout_18->addWidget(EditFokotanyPerso, 2, 1, 1, 1);

        PortablePersonnelle = new QLabel(widget_4);
        PortablePersonnelle->setObjectName(QString::fromUtf8("PortablePersonnelle"));
        PortablePersonnelle->setMinimumSize(QSize(0, 30));

        gridLayout_18->addWidget(PortablePersonnelle, 2, 2, 1, 1);

        frame = new QFrame(widget_4);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setStyleSheet(QString::fromUtf8("QFrame{\n"
"	background-color: transparent;\n"
"	border: none;\n"
"}"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        horizontalLayout_3 = new QHBoxLayout(frame);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        comboBoxPerso = new QComboBox(frame);
        comboBoxPerso->addItem(QString());
        comboBoxPerso->addItem(QString());
        comboBoxPerso->addItem(QString());
        comboBoxPerso->setObjectName(QString::fromUtf8("comboBoxPerso"));
        comboBoxPerso->setMinimumSize(QSize(100, 30));

        horizontalLayout_3->addWidget(comboBoxPerso);

        EditFivondronanaPerso = new QLineEdit(frame);
        EditFivondronanaPerso->setObjectName(QString::fromUtf8("EditFivondronanaPerso"));
        EditFivondronanaPerso->setMinimumSize(QSize(200, 30));

        horizontalLayout_3->addWidget(EditFivondronanaPerso);


        gridLayout_18->addWidget(frame, 4, 1, 1, 1);

        adressePersonnelle_2 = new QLabel(widget_4);
        adressePersonnelle_2->setObjectName(QString::fromUtf8("adressePersonnelle_2"));
        adressePersonnelle_2->setMinimumSize(QSize(0, 30));

        gridLayout_18->addWidget(adressePersonnelle_2, 1, 0, 1, 1);

        emailPersonnelle = new QLabel(widget_4);
        emailPersonnelle->setObjectName(QString::fromUtf8("emailPersonnelle"));
        emailPersonnelle->setMinimumSize(QSize(0, 30));

        gridLayout_18->addWidget(emailPersonnelle, 4, 2, 1, 1);

        EditfaxPerso = new QLineEdit(widget_4);
        EditfaxPerso->setObjectName(QString::fromUtf8("EditfaxPerso"));
        EditfaxPerso->setMinimumSize(QSize(200, 30));

        gridLayout_18->addWidget(EditfaxPerso, 3, 3, 1, 1);

        EditFiraisanaPerso = new QLineEdit(widget_4);
        EditFiraisanaPerso->setObjectName(QString::fromUtf8("EditFiraisanaPerso"));
        EditFiraisanaPerso->setMinimumSize(QSize(0, 30));

        gridLayout_18->addWidget(EditFiraisanaPerso, 3, 1, 1, 1);

        fivondronanaPersonnelle = new QLabel(widget_4);
        fivondronanaPersonnelle->setObjectName(QString::fromUtf8("fivondronanaPersonnelle"));
        fivondronanaPersonnelle->setMinimumSize(QSize(0, 30));

        gridLayout_18->addWidget(fivondronanaPersonnelle, 4, 0, 1, 1);

        EditAddressPerso = new QLineEdit(widget_4);
        EditAddressPerso->setObjectName(QString::fromUtf8("EditAddressPerso"));
        EditAddressPerso->setMinimumSize(QSize(200, 30));

        gridLayout_18->addWidget(EditAddressPerso, 1, 1, 1, 1);

        TelmaPersonnelle = new QLabel(widget_4);
        TelmaPersonnelle->setObjectName(QString::fromUtf8("TelmaPersonnelle"));
        TelmaPersonnelle->setMinimumSize(QSize(0, 30));

        gridLayout_18->addWidget(TelmaPersonnelle, 1, 2, 1, 1);

        firaisanaPersonnelle = new QLabel(widget_4);
        firaisanaPersonnelle->setObjectName(QString::fromUtf8("firaisanaPersonnelle"));
        firaisanaPersonnelle->setMinimumSize(QSize(0, 30));

        gridLayout_18->addWidget(firaisanaPersonnelle, 3, 0, 1, 1);

        EditMailPerso = new QLineEdit(widget_4);
        EditMailPerso->setObjectName(QString::fromUtf8("EditMailPerso"));
        EditMailPerso->setMinimumSize(QSize(200, 30));

        gridLayout_18->addWidget(EditMailPerso, 4, 3, 1, 1);

        EditTelmaPerso = new QLineEdit(widget_4);
        EditTelmaPerso->setObjectName(QString::fromUtf8("EditTelmaPerso"));
        EditTelmaPerso->setMinimumSize(QSize(200, 30));

        gridLayout_18->addWidget(EditTelmaPerso, 1, 3, 1, 1);

        fokotanyPersonnelle = new QLabel(widget_4);
        fokotanyPersonnelle->setObjectName(QString::fromUtf8("fokotanyPersonnelle"));
        fokotanyPersonnelle->setMinimumSize(QSize(0, 30));

        gridLayout_18->addWidget(fokotanyPersonnelle, 2, 0, 1, 1);

        EditPortablePerso = new QLineEdit(widget_4);
        EditPortablePerso->setObjectName(QString::fromUtf8("EditPortablePerso"));
        EditPortablePerso->setMinimumSize(QSize(200, 30));

        gridLayout_18->addWidget(EditPortablePerso, 2, 3, 1, 1);


        verticalLayout_2->addWidget(widget_4);

        AddressPeso->setWidget(scrollAreaWidgetContents_4);

        verticalLayout->addWidget(AddressPeso);

        ExercicePrincipal = new QScrollArea(widget_2);
        ExercicePrincipal->setObjectName(QString::fromUtf8("ExercicePrincipal"));
        ExercicePrincipal->setMinimumSize(QSize(0, 250));
        ExercicePrincipal->setMaximumSize(QSize(16777215, 250));
        ExercicePrincipal->setWidgetResizable(true);
        scrollAreaWidgetContents_5 = new QWidget();
        scrollAreaWidgetContents_5->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_5"));
        scrollAreaWidgetContents_5->setGeometry(QRect(0, 0, 770, 240));
        scrollAreaWidgetContents_5->setMinimumSize(QSize(0, 0));
        verticalLayout_3 = new QVBoxLayout(scrollAreaWidgetContents_5);
        verticalLayout_3->setSpacing(2);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        widget_5 = new QWidget(scrollAreaWidgetContents_5);
        widget_5->setObjectName(QString::fromUtf8("widget_5"));
        widget_5->setMinimumSize(QSize(0, 50));
        widget_5->setMaximumSize(QSize(16777215, 50));
        horizontalLayout_4 = new QHBoxLayout(widget_5);
        horizontalLayout_4->setSpacing(0);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        adressePrecedent_2 = new QPushButton(widget_5);
        adressePrecedent_2->setObjectName(QString::fromUtf8("adressePrecedent_2"));
        adressePrecedent_2->setMinimumSize(QSize(0, 30));

        horizontalLayout_4->addWidget(adressePrecedent_2);

        adresseSuivant_2 = new QPushButton(widget_5);
        adresseSuivant_2->setObjectName(QString::fromUtf8("adresseSuivant_2"));
        adresseSuivant_2->setMinimumSize(QSize(0, 30));

        horizontalLayout_4->addWidget(adresseSuivant_2);

        dernierAdresse_2 = new QPushButton(widget_5);
        dernierAdresse_2->setObjectName(QString::fromUtf8("dernierAdresse_2"));
        dernierAdresse_2->setMinimumSize(QSize(0, 30));

        horizontalLayout_4->addWidget(dernierAdresse_2);

        horizontalSpacer_2 = new QSpacerItem(30, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_2);

        pushButton_7 = new QPushButton(widget_5);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setMinimumSize(QSize(30, 30));
        pushButton_7->setMaximumSize(QSize(40, 30));

        horizontalLayout_4->addWidget(pushButton_7);


        verticalLayout_3->addWidget(widget_5);

        LieuExoPrincipal = new QLabel(scrollAreaWidgetContents_5);
        LieuExoPrincipal->setObjectName(QString::fromUtf8("LieuExoPrincipal"));
        LieuExoPrincipal->setMinimumSize(QSize(0, 30));
        LieuExoPrincipal->setMaximumSize(QSize(16777215, 30));
        LieuExoPrincipal->setStyleSheet(QString::fromUtf8("QLabel{\n"
"	background-color: rgb(2, 255, 255);\n"
"	border:none;\n"
"}"));

        verticalLayout_3->addWidget(LieuExoPrincipal, 0, Qt::AlignHCenter);

        widget_6 = new QWidget(scrollAreaWidgetContents_5);
        widget_6->setObjectName(QString::fromUtf8("widget_6"));
        gridLayout_19 = new QGridLayout(widget_6);
        gridLayout_19->setObjectName(QString::fromUtf8("gridLayout_19"));
        gridLayout_19->setVerticalSpacing(6);
        gridLayout_19->setContentsMargins(9, 9, 9, 9);
        EditFiraisanaExo = new QLineEdit(widget_6);
        EditFiraisanaExo->setObjectName(QString::fromUtf8("EditFiraisanaExo"));
        EditFiraisanaExo->setMinimumSize(QSize(200, 30));

        gridLayout_19->addWidget(EditFiraisanaExo, 3, 1, 1, 1);

        TelmaExo = new QLabel(widget_6);
        TelmaExo->setObjectName(QString::fromUtf8("TelmaExo"));
        TelmaExo->setMinimumSize(QSize(0, 30));

        gridLayout_19->addWidget(TelmaExo, 1, 2, 1, 1);

        fivondronanaExo = new QLabel(widget_6);
        fivondronanaExo->setObjectName(QString::fromUtf8("fivondronanaExo"));
        fivondronanaExo->setMinimumSize(QSize(0, 30));

        gridLayout_19->addWidget(fivondronanaExo, 4, 0, 1, 1);

        fokotanyExo = new QLabel(widget_6);
        fokotanyExo->setObjectName(QString::fromUtf8("fokotanyExo"));
        fokotanyExo->setMinimumSize(QSize(0, 30));

        gridLayout_19->addWidget(fokotanyExo, 2, 0, 1, 1);

        emailExo = new QLabel(widget_6);
        emailExo->setObjectName(QString::fromUtf8("emailExo"));
        emailExo->setMinimumSize(QSize(0, 30));

        gridLayout_19->addWidget(emailExo, 4, 2, 1, 1);

        frame_2 = new QFrame(widget_6);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setStyleSheet(QString::fromUtf8("QFrame{\n"
"	background-color: transparent;\n"
"	border: none;\n"
"}"));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        horizontalLayout_6 = new QHBoxLayout(frame_2);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        comboBoxExo = new QComboBox(frame_2);
        comboBoxExo->addItem(QString());
        comboBoxExo->addItem(QString());
        comboBoxExo->addItem(QString());
        comboBoxExo->setObjectName(QString::fromUtf8("comboBoxExo"));
        comboBoxExo->setMinimumSize(QSize(100, 30));

        horizontalLayout_6->addWidget(comboBoxExo);

        EditFivondronanaExo = new QLineEdit(frame_2);
        EditFivondronanaExo->setObjectName(QString::fromUtf8("EditFivondronanaExo"));
        EditFivondronanaExo->setMinimumSize(QSize(200, 30));

        horizontalLayout_6->addWidget(EditFivondronanaExo);


        gridLayout_19->addWidget(frame_2, 4, 1, 1, 1);

        EditMailExo = new QLineEdit(widget_6);
        EditMailExo->setObjectName(QString::fromUtf8("EditMailExo"));
        EditMailExo->setMinimumSize(QSize(200, 30));

        gridLayout_19->addWidget(EditMailExo, 4, 3, 1, 1);

        EditFokotanyFokotany = new QLineEdit(widget_6);
        EditFokotanyFokotany->setObjectName(QString::fromUtf8("EditFokotanyFokotany"));
        EditFokotanyFokotany->setMinimumSize(QSize(200, 30));

        gridLayout_19->addWidget(EditFokotanyFokotany, 2, 1, 1, 1);

        EditPortableExo = new QLineEdit(widget_6);
        EditPortableExo->setObjectName(QString::fromUtf8("EditPortableExo"));
        EditPortableExo->setMinimumSize(QSize(200, 30));
        EditPortableExo->setMaximumSize(QSize(16777215, 30));

        gridLayout_19->addWidget(EditPortableExo, 2, 3, 1, 1);

        EditfaxExo = new QLineEdit(widget_6);
        EditfaxExo->setObjectName(QString::fromUtf8("EditfaxExo"));
        EditfaxExo->setMinimumSize(QSize(200, 30));

        gridLayout_19->addWidget(EditfaxExo, 3, 3, 1, 1);

        PortableExo = new QLabel(widget_6);
        PortableExo->setObjectName(QString::fromUtf8("PortableExo"));
        PortableExo->setMinimumSize(QSize(0, 30));

        gridLayout_19->addWidget(PortableExo, 2, 2, 1, 1);

        adresseExo = new QLabel(widget_6);
        adresseExo->setObjectName(QString::fromUtf8("adresseExo"));
        adresseExo->setMinimumSize(QSize(0, 30));

        gridLayout_19->addWidget(adresseExo, 1, 0, 1, 1);

        firaisanaExo = new QLabel(widget_6);
        firaisanaExo->setObjectName(QString::fromUtf8("firaisanaExo"));
        firaisanaExo->setMinimumSize(QSize(0, 30));

        gridLayout_19->addWidget(firaisanaExo, 3, 0, 1, 1);

        EditAddressExo = new QLineEdit(widget_6);
        EditAddressExo->setObjectName(QString::fromUtf8("EditAddressExo"));
        EditAddressExo->setMinimumSize(QSize(200, 30));

        gridLayout_19->addWidget(EditAddressExo, 1, 1, 1, 1);

        faxExo = new QLabel(widget_6);
        faxExo->setObjectName(QString::fromUtf8("faxExo"));
        faxExo->setMinimumSize(QSize(0, 30));

        gridLayout_19->addWidget(faxExo, 3, 2, 1, 1);

        EditTelmaExo = new QLineEdit(widget_6);
        EditTelmaExo->setObjectName(QString::fromUtf8("EditTelmaExo"));
        EditTelmaExo->setMinimumSize(QSize(200, 30));
        EditTelmaExo->setMaximumSize(QSize(16777215, 30));

        gridLayout_19->addWidget(EditTelmaExo, 1, 3, 1, 1);


        verticalLayout_3->addWidget(widget_6);

        ExercicePrincipal->setWidget(scrollAreaWidgetContents_5);

        verticalLayout->addWidget(ExercicePrincipal);

        adresseCourier = new QScrollArea(widget_2);
        adresseCourier->setObjectName(QString::fromUtf8("adresseCourier"));
        adresseCourier->setMinimumSize(QSize(0, 160));
        adresseCourier->setMaximumSize(QSize(16777215, 160));
        adresseCourier->setWidgetResizable(true);
        scrollAreaWidgetContents_6 = new QWidget();
        scrollAreaWidgetContents_6->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_6"));
        scrollAreaWidgetContents_6->setGeometry(QRect(0, 0, 781, 144));
        verticalLayout_4 = new QVBoxLayout(scrollAreaWidgetContents_6);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        addressCourier = new QLabel(scrollAreaWidgetContents_6);
        addressCourier->setObjectName(QString::fromUtf8("addressCourier"));
        addressCourier->setMinimumSize(QSize(0, 30));
        addressCourier->setMaximumSize(QSize(16777215, 30));
        addressCourier->setStyleSheet(QString::fromUtf8("QLabel{\n"
"	background-color: rgb(2, 255, 255);\n"
"	border:none;\n"
"}"));

        verticalLayout_4->addWidget(addressCourier, 0, Qt::AlignHCenter);

        widget_7 = new QWidget(scrollAreaWidgetContents_6);
        widget_7->setObjectName(QString::fromUtf8("widget_7"));
        gridLayout_20 = new QGridLayout(widget_7);
        gridLayout_20->setObjectName(QString::fromUtf8("gridLayout_20"));
        AdresseCourier = new QLabel(widget_7);
        AdresseCourier->setObjectName(QString::fromUtf8("AdresseCourier"));
        AdresseCourier->setMinimumSize(QSize(0, 30));
        AdresseCourier->setMaximumSize(QSize(16777215, 30));

        gridLayout_20->addWidget(AdresseCourier, 0, 0, 1, 1);

        editFokotanysCour = new QLineEdit(widget_7);
        editFokotanysCour->setObjectName(QString::fromUtf8("editFokotanysCour"));
        editFokotanysCour->setMinimumSize(QSize(200, 30));
        editFokotanysCour->setMaximumSize(QSize(16777215, 30));

        gridLayout_20->addWidget(editFokotanysCour, 1, 1, 1, 1);

        editFiraisanaCour = new QLineEdit(widget_7);
        editFiraisanaCour->setObjectName(QString::fromUtf8("editFiraisanaCour"));
        editFiraisanaCour->setMinimumSize(QSize(200, 0));
        editFiraisanaCour->setMaximumSize(QSize(16777215, 30));

        gridLayout_20->addWidget(editFiraisanaCour, 0, 3, 1, 1);

        editAddressCour = new QLineEdit(widget_7);
        editAddressCour->setObjectName(QString::fromUtf8("editAddressCour"));
        editAddressCour->setMinimumSize(QSize(200, 30));
        editAddressCour->setMaximumSize(QSize(16777215, 30));

        gridLayout_20->addWidget(editAddressCour, 0, 1, 1, 1);

        FokotanyCourier = new QLabel(widget_7);
        FokotanyCourier->setObjectName(QString::fromUtf8("FokotanyCourier"));
        FokotanyCourier->setMinimumSize(QSize(0, 30));
        FokotanyCourier->setMaximumSize(QSize(16777215, 30));

        gridLayout_20->addWidget(FokotanyCourier, 1, 0, 1, 1);

        frame_3 = new QFrame(widget_7);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setStyleSheet(QString::fromUtf8("QFrame{\n"
"	background-color: transparent;\n"
"	border: none;\n"
"}"));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        horizontalLayout_7 = new QHBoxLayout(frame_3);
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalLayout_7->setContentsMargins(0, 0, 0, 0);
        comboBoxCourier = new QComboBox(frame_3);
        comboBoxCourier->setObjectName(QString::fromUtf8("comboBoxCourier"));
        comboBoxCourier->setMinimumSize(QSize(100, 30));
        comboBoxCourier->setMaximumSize(QSize(16777215, 30));

        horizontalLayout_7->addWidget(comboBoxCourier);

        editFivondronanaCour = new QLineEdit(frame_3);
        editFivondronanaCour->setObjectName(QString::fromUtf8("editFivondronanaCour"));
        editFivondronanaCour->setMinimumSize(QSize(200, 30));
        editFivondronanaCour->setMaximumSize(QSize(16777215, 30));

        horizontalLayout_7->addWidget(editFivondronanaCour);


        gridLayout_20->addWidget(frame_3, 1, 3, 1, 1);

        FiraisanaCourier = new QLabel(widget_7);
        FiraisanaCourier->setObjectName(QString::fromUtf8("FiraisanaCourier"));

        gridLayout_20->addWidget(FiraisanaCourier, 0, 2, 1, 1);

        FivondronanaCourier = new QLabel(widget_7);
        FivondronanaCourier->setObjectName(QString::fromUtf8("FivondronanaCourier"));
        FivondronanaCourier->setMinimumSize(QSize(0, 30));
        FivondronanaCourier->setMaximumSize(QSize(16777215, 30));

        gridLayout_20->addWidget(FivondronanaCourier, 1, 2, 1, 1);


        verticalLayout_4->addWidget(widget_7);

        adresseCourier->setWidget(scrollAreaWidgetContents_6);

        verticalLayout->addWidget(adresseCourier);

        AutreExercice = new QScrollArea(widget_2);
        AutreExercice->setObjectName(QString::fromUtf8("AutreExercice"));
        AutreExercice->setMinimumSize(QSize(0, 250));
        AutreExercice->setMaximumSize(QSize(16777215, 250));
        AutreExercice->setWidgetResizable(true);
        scrollAreaWidgetContents_2 = new QWidget();
        scrollAreaWidgetContents_2->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_2"));
        scrollAreaWidgetContents_2->setGeometry(QRect(0, 0, 788, 264));
        verticalLayout_6 = new QVBoxLayout(scrollAreaWidgetContents_2);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        widget_9 = new QWidget(scrollAreaWidgetContents_2);
        widget_9->setObjectName(QString::fromUtf8("widget_9"));
        horizontalLayout_8 = new QHBoxLayout(widget_9);
        horizontalLayout_8->setSpacing(0);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        adressePrecedent_3 = new QPushButton(widget_9);
        adressePrecedent_3->setObjectName(QString::fromUtf8("adressePrecedent_3"));
        adressePrecedent_3->setMinimumSize(QSize(0, 30));

        horizontalLayout_8->addWidget(adressePrecedent_3);

        adresseSuivant_3 = new QPushButton(widget_9);
        adresseSuivant_3->setObjectName(QString::fromUtf8("adresseSuivant_3"));
        adresseSuivant_3->setMinimumSize(QSize(0, 30));

        horizontalLayout_8->addWidget(adresseSuivant_3);

        dernierAdresse_3 = new QPushButton(widget_9);
        dernierAdresse_3->setObjectName(QString::fromUtf8("dernierAdresse_3"));
        dernierAdresse_3->setMinimumSize(QSize(0, 30));

        horizontalLayout_8->addWidget(dernierAdresse_3);

        horizontalSpacer_3 = new QSpacerItem(30, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_3);

        pushButton_8 = new QPushButton(widget_9);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setMinimumSize(QSize(30, 30));
        pushButton_8->setMaximumSize(QSize(40, 30));

        horizontalLayout_8->addWidget(pushButton_8);


        verticalLayout_6->addWidget(widget_9);

        adressePersonnelle_3 = new QLabel(scrollAreaWidgetContents_2);
        adressePersonnelle_3->setObjectName(QString::fromUtf8("adressePersonnelle_3"));
        adressePersonnelle_3->setMinimumSize(QSize(0, 30));
        adressePersonnelle_3->setMaximumSize(QSize(16777215, 30));
        adressePersonnelle_3->setStyleSheet(QString::fromUtf8("QLabel{\n"
"	background-color: rgb(2, 255, 255);\n"
"	border:none;\n"
"}"));

        verticalLayout_6->addWidget(adressePersonnelle_3, 0, Qt::AlignHCenter);

        widget_8 = new QWidget(scrollAreaWidgetContents_2);
        widget_8->setObjectName(QString::fromUtf8("widget_8"));
        gridLayout_21 = new QGridLayout(widget_8);
        gridLayout_21->setObjectName(QString::fromUtf8("gridLayout_21"));
        gridLayout_21->setHorizontalSpacing(6);
        gridLayout_21->setContentsMargins(-1, -1, -1, 9);
        EditAddressPerso_2 = new QLineEdit(widget_8);
        EditAddressPerso_2->setObjectName(QString::fromUtf8("EditAddressPerso_2"));
        EditAddressPerso_2->setMinimumSize(QSize(200, 30));

        gridLayout_21->addWidget(EditAddressPerso_2, 1, 1, 1, 1);

        EditTelmaPerso_2 = new QLineEdit(widget_8);
        EditTelmaPerso_2->setObjectName(QString::fromUtf8("EditTelmaPerso_2"));
        EditTelmaPerso_2->setMinimumSize(QSize(200, 30));

        gridLayout_21->addWidget(EditTelmaPerso_2, 1, 3, 1, 1);

        EditPortablePerso_2 = new QLineEdit(widget_8);
        EditPortablePerso_2->setObjectName(QString::fromUtf8("EditPortablePerso_2"));
        EditPortablePerso_2->setMinimumSize(QSize(200, 30));

        gridLayout_21->addWidget(EditPortablePerso_2, 2, 3, 1, 1);

        emailPersonnelle_2 = new QLabel(widget_8);
        emailPersonnelle_2->setObjectName(QString::fromUtf8("emailPersonnelle_2"));
        emailPersonnelle_2->setMinimumSize(QSize(0, 30));

        gridLayout_21->addWidget(emailPersonnelle_2, 4, 2, 1, 1);

        firaisanaPersonnelle_2 = new QLabel(widget_8);
        firaisanaPersonnelle_2->setObjectName(QString::fromUtf8("firaisanaPersonnelle_2"));
        firaisanaPersonnelle_2->setMinimumSize(QSize(0, 30));

        gridLayout_21->addWidget(firaisanaPersonnelle_2, 3, 0, 1, 1);

        frame_4 = new QFrame(widget_8);
        frame_4->setObjectName(QString::fromUtf8("frame_4"));
        frame_4->setStyleSheet(QString::fromUtf8("QFrame{\n"
"	background-color: transparent;\n"
"	border: none;\n"
"}"));
        frame_4->setFrameShape(QFrame::StyledPanel);
        frame_4->setFrameShadow(QFrame::Raised);
        horizontalLayout_5 = new QHBoxLayout(frame_4);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        comboBoxPerso_2 = new QComboBox(frame_4);
        comboBoxPerso_2->addItem(QString());
        comboBoxPerso_2->addItem(QString());
        comboBoxPerso_2->addItem(QString());
        comboBoxPerso_2->setObjectName(QString::fromUtf8("comboBoxPerso_2"));
        comboBoxPerso_2->setMinimumSize(QSize(100, 30));

        horizontalLayout_5->addWidget(comboBoxPerso_2);

        EditFivondronanaPerso_2 = new QLineEdit(frame_4);
        EditFivondronanaPerso_2->setObjectName(QString::fromUtf8("EditFivondronanaPerso_2"));
        EditFivondronanaPerso_2->setMinimumSize(QSize(200, 30));

        horizontalLayout_5->addWidget(EditFivondronanaPerso_2);


        gridLayout_21->addWidget(frame_4, 4, 1, 1, 1);

        EditMailPerso_2 = new QLineEdit(widget_8);
        EditMailPerso_2->setObjectName(QString::fromUtf8("EditMailPerso_2"));
        EditMailPerso_2->setMinimumSize(QSize(200, 30));

        gridLayout_21->addWidget(EditMailPerso_2, 4, 3, 1, 1);

        TelmaPersonnelle_2 = new QLabel(widget_8);
        TelmaPersonnelle_2->setObjectName(QString::fromUtf8("TelmaPersonnelle_2"));
        TelmaPersonnelle_2->setMinimumSize(QSize(0, 30));

        gridLayout_21->addWidget(TelmaPersonnelle_2, 1, 2, 1, 1);

        faxPersonnelle_2 = new QLabel(widget_8);
        faxPersonnelle_2->setObjectName(QString::fromUtf8("faxPersonnelle_2"));
        faxPersonnelle_2->setMinimumSize(QSize(0, 30));

        gridLayout_21->addWidget(faxPersonnelle_2, 3, 2, 1, 1);

        EditfaxPerso_2 = new QLineEdit(widget_8);
        EditfaxPerso_2->setObjectName(QString::fromUtf8("EditfaxPerso_2"));
        EditfaxPerso_2->setMinimumSize(QSize(200, 30));

        gridLayout_21->addWidget(EditfaxPerso_2, 3, 3, 1, 1);

        adressePersonnelle_4 = new QLabel(widget_8);
        adressePersonnelle_4->setObjectName(QString::fromUtf8("adressePersonnelle_4"));
        adressePersonnelle_4->setMinimumSize(QSize(0, 30));

        gridLayout_21->addWidget(adressePersonnelle_4, 1, 0, 1, 1);

        EditFiraisanaPerso_2 = new QLineEdit(widget_8);
        EditFiraisanaPerso_2->setObjectName(QString::fromUtf8("EditFiraisanaPerso_2"));
        EditFiraisanaPerso_2->setMinimumSize(QSize(0, 30));

        gridLayout_21->addWidget(EditFiraisanaPerso_2, 3, 1, 1, 1);

        fokotanyPersonnelle_2 = new QLabel(widget_8);
        fokotanyPersonnelle_2->setObjectName(QString::fromUtf8("fokotanyPersonnelle_2"));
        fokotanyPersonnelle_2->setMinimumSize(QSize(0, 30));

        gridLayout_21->addWidget(fokotanyPersonnelle_2, 2, 0, 1, 1);

        fivondronanaPersonnelle_2 = new QLabel(widget_8);
        fivondronanaPersonnelle_2->setObjectName(QString::fromUtf8("fivondronanaPersonnelle_2"));
        fivondronanaPersonnelle_2->setMinimumSize(QSize(0, 30));

        gridLayout_21->addWidget(fivondronanaPersonnelle_2, 4, 0, 1, 1);

        PortablePersonnelle_2 = new QLabel(widget_8);
        PortablePersonnelle_2->setObjectName(QString::fromUtf8("PortablePersonnelle_2"));
        PortablePersonnelle_2->setMinimumSize(QSize(0, 30));

        gridLayout_21->addWidget(PortablePersonnelle_2, 2, 2, 1, 1);

        EditFokotanyPerso_2 = new QLineEdit(widget_8);
        EditFokotanyPerso_2->setObjectName(QString::fromUtf8("EditFokotanyPerso_2"));
        EditFokotanyPerso_2->setMinimumSize(QSize(200, 30));

        gridLayout_21->addWidget(EditFokotanyPerso_2, 2, 1, 1, 1);


        verticalLayout_6->addWidget(widget_8);

        AutreExercice->setWidget(scrollAreaWidgetContents_2);

        verticalLayout->addWidget(AutreExercice);


        verticalLayout_5->addWidget(widget_2);

        scrollArea->setWidget(scrollAreaWidgetContents);

        gridLayout_9->addWidget(scrollArea, 0, 0, 1, 1);

        barInfo->addTab(adresse, QString());
        titre = new QWidget();
        titre->setObjectName(QString::fromUtf8("titre"));
        gridLayout_41 = new QGridLayout(titre);
        gridLayout_41->setObjectName(QString::fromUtf8("gridLayout_41"));
        frame_17 = new QFrame(titre);
        frame_17->setObjectName(QString::fromUtf8("frame_17"));
        frame_17->setMaximumSize(QSize(16777215, 50));
        frame_17->setFrameShape(QFrame::StyledPanel);
        frame_17->setFrameShadow(QFrame::Raised);
        horizontalLayout_20 = new QHBoxLayout(frame_17);
        horizontalLayout_20->setObjectName(QString::fromUtf8("horizontalLayout_20"));
        label_53 = new QLabel(frame_17);
        label_53->setObjectName(QString::fromUtf8("label_53"));

        horizontalLayout_20->addWidget(label_53);

        lineEdit_30 = new QLineEdit(frame_17);
        lineEdit_30->setObjectName(QString::fromUtf8("lineEdit_30"));

        horizontalLayout_20->addWidget(lineEdit_30);

        label_54 = new QLabel(frame_17);
        label_54->setObjectName(QString::fromUtf8("label_54"));

        horizontalLayout_20->addWidget(label_54);

        lineEdit_31 = new QLineEdit(frame_17);
        lineEdit_31->setObjectName(QString::fromUtf8("lineEdit_31"));

        horizontalLayout_20->addWidget(lineEdit_31);


        gridLayout_41->addWidget(frame_17, 0, 0, 1, 1);

        frame_13 = new QFrame(titre);
        frame_13->setObjectName(QString::fromUtf8("frame_13"));
        frame_13->setFrameShape(QFrame::StyledPanel);
        frame_13->setFrameShadow(QFrame::Raised);
        horizontalLayout_18 = new QHBoxLayout(frame_13);
        horizontalLayout_18->setObjectName(QString::fromUtf8("horizontalLayout_18"));
        frame_14 = new QFrame(frame_13);
        frame_14->setObjectName(QString::fromUtf8("frame_14"));
        frame_14->setFrameShape(QFrame::StyledPanel);
        frame_14->setFrameShadow(QFrame::Raised);
        horizontalLayout_19 = new QHBoxLayout(frame_14);
        horizontalLayout_19->setObjectName(QString::fromUtf8("horizontalLayout_19"));
        groupBox_15 = new QGroupBox(frame_14);
        groupBox_15->setObjectName(QString::fromUtf8("groupBox_15"));
        gridLayout_6 = new QGridLayout(groupBox_15);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        lineEdit_22 = new QLineEdit(groupBox_15);
        lineEdit_22->setObjectName(QString::fromUtf8("lineEdit_22"));

        gridLayout_6->addWidget(lineEdit_22, 0, 4, 1, 1);

        label_43 = new QLabel(groupBox_15);
        label_43->setObjectName(QString::fromUtf8("label_43"));

        gridLayout_6->addWidget(label_43, 2, 2, 1, 2);

        label_44 = new QLabel(groupBox_15);
        label_44->setObjectName(QString::fromUtf8("label_44"));

        gridLayout_6->addWidget(label_44, 5, 1, 1, 3);

        checkBox_14 = new QCheckBox(groupBox_15);
        checkBox_14->setObjectName(QString::fromUtf8("checkBox_14"));

        gridLayout_6->addWidget(checkBox_14, 7, 0, 1, 1);

        lineEdit_23 = new QLineEdit(groupBox_15);
        lineEdit_23->setObjectName(QString::fromUtf8("lineEdit_23"));

        gridLayout_6->addWidget(lineEdit_23, 4, 4, 1, 1);

        lineEdit_24 = new QLineEdit(groupBox_15);
        lineEdit_24->setObjectName(QString::fromUtf8("lineEdit_24"));

        gridLayout_6->addWidget(lineEdit_24, 3, 4, 1, 1);

        label_45 = new QLabel(groupBox_15);
        label_45->setObjectName(QString::fromUtf8("label_45"));

        gridLayout_6->addWidget(label_45, 0, 2, 1, 2);

        label_46 = new QLabel(groupBox_15);
        label_46->setObjectName(QString::fromUtf8("label_46"));

        gridLayout_6->addWidget(label_46, 6, 3, 1, 1);

        lineEdit_25 = new QLineEdit(groupBox_15);
        lineEdit_25->setObjectName(QString::fromUtf8("lineEdit_25"));

        gridLayout_6->addWidget(lineEdit_25, 6, 4, 1, 1);

        lineEdit_26 = new QLineEdit(groupBox_15);
        lineEdit_26->setObjectName(QString::fromUtf8("lineEdit_26"));

        gridLayout_6->addWidget(lineEdit_26, 1, 4, 1, 1);

        checkBox_15 = new QCheckBox(groupBox_15);
        checkBox_15->setObjectName(QString::fromUtf8("checkBox_15"));

        gridLayout_6->addWidget(checkBox_15, 1, 0, 1, 2);

        checkBox_16 = new QCheckBox(groupBox_15);
        checkBox_16->setObjectName(QString::fromUtf8("checkBox_16"));

        gridLayout_6->addWidget(checkBox_16, 0, 0, 1, 2);

        label_47 = new QLabel(groupBox_15);
        label_47->setObjectName(QString::fromUtf8("label_47"));

        gridLayout_6->addWidget(label_47, 3, 3, 1, 1);

        checkBox_17 = new QCheckBox(groupBox_15);
        checkBox_17->setObjectName(QString::fromUtf8("checkBox_17"));

        gridLayout_6->addWidget(checkBox_17, 3, 0, 1, 3);

        checkBox_18 = new QCheckBox(groupBox_15);
        checkBox_18->setObjectName(QString::fromUtf8("checkBox_18"));

        gridLayout_6->addWidget(checkBox_18, 6, 0, 1, 3);

        checkBox_19 = new QCheckBox(groupBox_15);
        checkBox_19->setObjectName(QString::fromUtf8("checkBox_19"));

        gridLayout_6->addWidget(checkBox_19, 2, 0, 1, 2);

        label_48 = new QLabel(groupBox_15);
        label_48->setObjectName(QString::fromUtf8("label_48"));

        gridLayout_6->addWidget(label_48, 4, 2, 1, 2);

        lineEdit_27 = new QLineEdit(groupBox_15);
        lineEdit_27->setObjectName(QString::fromUtf8("lineEdit_27"));

        gridLayout_6->addWidget(lineEdit_27, 2, 4, 1, 1);

        label_49 = new QLabel(groupBox_15);
        label_49->setObjectName(QString::fromUtf8("label_49"));

        gridLayout_6->addWidget(label_49, 7, 1, 1, 3);

        checkBox_20 = new QCheckBox(groupBox_15);
        checkBox_20->setObjectName(QString::fromUtf8("checkBox_20"));

        gridLayout_6->addWidget(checkBox_20, 5, 0, 1, 1);

        lineEdit_28 = new QLineEdit(groupBox_15);
        lineEdit_28->setObjectName(QString::fromUtf8("lineEdit_28"));

        gridLayout_6->addWidget(lineEdit_28, 5, 4, 1, 1);

        checkBox_21 = new QCheckBox(groupBox_15);
        checkBox_21->setObjectName(QString::fromUtf8("checkBox_21"));

        gridLayout_6->addWidget(checkBox_21, 4, 0, 1, 2);

        label_50 = new QLabel(groupBox_15);
        label_50->setObjectName(QString::fromUtf8("label_50"));

        gridLayout_6->addWidget(label_50, 1, 2, 1, 2);

        lineEdit_29 = new QLineEdit(groupBox_15);
        lineEdit_29->setObjectName(QString::fromUtf8("lineEdit_29"));

        gridLayout_6->addWidget(lineEdit_29, 7, 4, 1, 1);


        horizontalLayout_19->addWidget(groupBox_15);


        horizontalLayout_18->addWidget(frame_14);

        frame_15 = new QFrame(frame_13);
        frame_15->setObjectName(QString::fromUtf8("frame_15"));
        frame_15->setMinimumSize(QSize(0, 0));
        frame_15->setMaximumSize(QSize(400, 16777215));
        frame_15->setFrameShape(QFrame::StyledPanel);
        frame_15->setFrameShadow(QFrame::Raised);
        verticalLayout_10 = new QVBoxLayout(frame_15);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        groupBox_16 = new QGroupBox(frame_15);
        groupBox_16->setObjectName(QString::fromUtf8("groupBox_16"));
        formLayout_5 = new QFormLayout(groupBox_16);
        formLayout_5->setObjectName(QString::fromUtf8("formLayout_5"));
        label_51 = new QLabel(groupBox_16);
        label_51->setObjectName(QString::fromUtf8("label_51"));

        formLayout_5->setWidget(0, QFormLayout::LabelRole, label_51);

        label_52 = new QLabel(groupBox_16);
        label_52->setObjectName(QString::fromUtf8("label_52"));

        formLayout_5->setWidget(0, QFormLayout::FieldRole, label_52);

        comboBox_8 = new QComboBox(groupBox_16);
        comboBox_8->setObjectName(QString::fromUtf8("comboBox_8"));

        formLayout_5->setWidget(1, QFormLayout::LabelRole, comboBox_8);

        dateEdit_10 = new QDateEdit(groupBox_16);
        dateEdit_10->setObjectName(QString::fromUtf8("dateEdit_10"));

        formLayout_5->setWidget(1, QFormLayout::FieldRole, dateEdit_10);


        verticalLayout_10->addWidget(groupBox_16);

        frame_16 = new QFrame(frame_15);
        frame_16->setObjectName(QString::fromUtf8("frame_16"));
        frame_16->setFrameShape(QFrame::StyledPanel);
        frame_16->setFrameShadow(QFrame::Raised);
        gridLayout_15 = new QGridLayout(frame_16);
        gridLayout_15->setObjectName(QString::fromUtf8("gridLayout_15"));
        pushButton_15 = new QPushButton(frame_16);
        pushButton_15->setObjectName(QString::fromUtf8("pushButton_15"));

        gridLayout_15->addWidget(pushButton_15, 0, 0, 1, 1);

        pushButton_16 = new QPushButton(frame_16);
        pushButton_16->setObjectName(QString::fromUtf8("pushButton_16"));

        gridLayout_15->addWidget(pushButton_16, 0, 1, 1, 1);

        pushButton_17 = new QPushButton(frame_16);
        pushButton_17->setObjectName(QString::fromUtf8("pushButton_17"));

        gridLayout_15->addWidget(pushButton_17, 1, 0, 1, 2);


        verticalLayout_10->addWidget(frame_16, 0, Qt::AlignBottom);


        horizontalLayout_18->addWidget(frame_15);


        gridLayout_41->addWidget(frame_13, 1, 0, 1, 1);

        barInfo->addTab(titre, QString());
        specialites = new QWidget();
        specialites->setObjectName(QString::fromUtf8("specialites"));
        gridLayout_37 = new QGridLayout(specialites);
        gridLayout_37->setObjectName(QString::fromUtf8("gridLayout_37"));
        widget_22 = new QWidget(specialites);
        widget_22->setObjectName(QString::fromUtf8("widget_22"));
        horizontalLayout_70 = new QHBoxLayout(widget_22);
        horizontalLayout_70->setObjectName(QString::fromUtf8("horizontalLayout_70"));
        widget_35 = new QWidget(widget_22);
        widget_35->setObjectName(QString::fromUtf8("widget_35"));
        verticalLayout_88 = new QVBoxLayout(widget_35);
        verticalLayout_88->setObjectName(QString::fromUtf8("verticalLayout_88"));
        widget_36 = new QWidget(widget_35);
        widget_36->setObjectName(QString::fromUtf8("widget_36"));
        horizontalLayout_71 = new QHBoxLayout(widget_36);
        horizontalLayout_71->setObjectName(QString::fromUtf8("horizontalLayout_71"));
        horizontalLayout_72 = new QHBoxLayout();
        horizontalLayout_72->setObjectName(QString::fromUtf8("horizontalLayout_72"));
        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_72->addItem(horizontalSpacer_9);

        nomLabel_3 = new QLabel(widget_36);
        nomLabel_3->setObjectName(QString::fromUtf8("nomLabel_3"));
        QFont font;
        font.setFamilies({QString::fromUtf8("Gubbi")});
        font.setPointSize(12);
        nomLabel_3->setFont(font);

        horizontalLayout_72->addWidget(nomLabel_3);

        nomEdit_3 = new QLineEdit(widget_36);
        nomEdit_3->setObjectName(QString::fromUtf8("nomEdit_3"));

        horizontalLayout_72->addWidget(nomEdit_3);


        horizontalLayout_71->addLayout(horizontalLayout_72);

        horizontalLayout_73 = new QHBoxLayout();
        horizontalLayout_73->setObjectName(QString::fromUtf8("horizontalLayout_73"));
        prenomLabel_3 = new QLabel(widget_36);
        prenomLabel_3->setObjectName(QString::fromUtf8("prenomLabel_3"));
        QFont font1;
        font1.setPointSize(12);
        prenomLabel_3->setFont(font1);

        horizontalLayout_73->addWidget(prenomLabel_3);

        prenomEdit_3 = new QLineEdit(widget_36);
        prenomEdit_3->setObjectName(QString::fromUtf8("prenomEdit_3"));

        horizontalLayout_73->addWidget(prenomEdit_3);


        horizontalLayout_71->addLayout(horizontalLayout_73);

        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_71->addItem(horizontalSpacer_10);


        verticalLayout_88->addWidget(widget_36);

        widget_37 = new QWidget(widget_35);
        widget_37->setObjectName(QString::fromUtf8("widget_37"));
        verticalLayout_89 = new QVBoxLayout(widget_37);
        verticalLayout_89->setObjectName(QString::fromUtf8("verticalLayout_89"));
        widget_38 = new QWidget(widget_37);
        widget_38->setObjectName(QString::fromUtf8("widget_38"));
        verticalLayout_90 = new QVBoxLayout(widget_38);
        verticalLayout_90->setObjectName(QString::fromUtf8("verticalLayout_90"));
        widget_39 = new QWidget(widget_38);
        widget_39->setObjectName(QString::fromUtf8("widget_39"));
        verticalLayout_91 = new QVBoxLayout(widget_39);
        verticalLayout_91->setObjectName(QString::fromUtf8("verticalLayout_91"));
        label_121 = new QLabel(widget_39);
        label_121->setObjectName(QString::fromUtf8("label_121"));
        QFont font2;
        font2.setBold(true);
        label_121->setFont(font2);

        verticalLayout_91->addWidget(label_121);


        verticalLayout_90->addWidget(widget_39);

        scrollArea_12 = new QScrollArea(widget_38);
        scrollArea_12->setObjectName(QString::fromUtf8("scrollArea_12"));
        scrollArea_12->setWidgetResizable(true);
        scrollAreaWidgetContents_16 = new QWidget();
        scrollAreaWidgetContents_16->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_16"));
        scrollAreaWidgetContents_16->setGeometry(QRect(0, 0, 711, 188));
        gridLayout_34 = new QGridLayout(scrollAreaWidgetContents_16);
        gridLayout_34->setObjectName(QString::fromUtf8("gridLayout_34"));
        verticalLayout_92 = new QVBoxLayout();
        verticalLayout_92->setObjectName(QString::fromUtf8("verticalLayout_92"));
        specDate_3 = new QLabel(scrollAreaWidgetContents_16);
        specDate_3->setObjectName(QString::fromUtf8("specDate_3"));

        verticalLayout_92->addWidget(specDate_3);

        lineEdit_109 = new QLineEdit(scrollAreaWidgetContents_16);
        lineEdit_109->setObjectName(QString::fromUtf8("lineEdit_109"));

        verticalLayout_92->addWidget(lineEdit_109);

        lineEdit_110 = new QLineEdit(scrollAreaWidgetContents_16);
        lineEdit_110->setObjectName(QString::fromUtf8("lineEdit_110"));

        verticalLayout_92->addWidget(lineEdit_110);


        gridLayout_34->addLayout(verticalLayout_92, 0, 2, 1, 1);

        verticalLayout_93 = new QVBoxLayout();
        verticalLayout_93->setObjectName(QString::fromUtf8("verticalLayout_93"));
        specPer_3 = new QLabel(scrollAreaWidgetContents_16);
        specPer_3->setObjectName(QString::fromUtf8("specPer_3"));

        verticalLayout_93->addWidget(specPer_3);

        lineEdit_111 = new QLineEdit(scrollAreaWidgetContents_16);
        lineEdit_111->setObjectName(QString::fromUtf8("lineEdit_111"));

        verticalLayout_93->addWidget(lineEdit_111);

        lineEdit_112 = new QLineEdit(scrollAreaWidgetContents_16);
        lineEdit_112->setObjectName(QString::fromUtf8("lineEdit_112"));

        verticalLayout_93->addWidget(lineEdit_112);


        gridLayout_34->addLayout(verticalLayout_93, 1, 0, 1, 1);

        verticalLayout_94 = new QVBoxLayout();
        verticalLayout_94->setObjectName(QString::fromUtf8("verticalLayout_94"));
        verticalLayout_95 = new QVBoxLayout();
        verticalLayout_95->setObjectName(QString::fromUtf8("verticalLayout_95"));
        specTitre_3 = new QLabel(scrollAreaWidgetContents_16);
        specTitre_3->setObjectName(QString::fromUtf8("specTitre_3"));

        verticalLayout_95->addWidget(specTitre_3);

        fontComboBox_19 = new QFontComboBox(scrollAreaWidgetContents_16);
        fontComboBox_19->setObjectName(QString::fromUtf8("fontComboBox_19"));

        verticalLayout_95->addWidget(fontComboBox_19);

        fontComboBox_20 = new QFontComboBox(scrollAreaWidgetContents_16);
        fontComboBox_20->setObjectName(QString::fromUtf8("fontComboBox_20"));

        verticalLayout_95->addWidget(fontComboBox_20);


        verticalLayout_94->addLayout(verticalLayout_95);


        gridLayout_34->addLayout(verticalLayout_94, 0, 0, 1, 1);

        verticalLayout_96 = new QVBoxLayout();
        verticalLayout_96->setObjectName(QString::fromUtf8("verticalLayout_96"));
        specSpec_3 = new QLabel(scrollAreaWidgetContents_16);
        specSpec_3->setObjectName(QString::fromUtf8("specSpec_3"));

        verticalLayout_96->addWidget(specSpec_3);

        fontComboBox_21 = new QFontComboBox(scrollAreaWidgetContents_16);
        fontComboBox_21->setObjectName(QString::fromUtf8("fontComboBox_21"));

        verticalLayout_96->addWidget(fontComboBox_21);

        fontComboBox_22 = new QFontComboBox(scrollAreaWidgetContents_16);
        fontComboBox_22->setObjectName(QString::fromUtf8("fontComboBox_22"));

        verticalLayout_96->addWidget(fontComboBox_22);


        gridLayout_34->addLayout(verticalLayout_96, 0, 1, 1, 1);

        verticalLayout_97 = new QVBoxLayout();
        verticalLayout_97->setObjectName(QString::fromUtf8("verticalLayout_97"));
        specLieu_3 = new QLabel(scrollAreaWidgetContents_16);
        specLieu_3->setObjectName(QString::fromUtf8("specLieu_3"));

        verticalLayout_97->addWidget(specLieu_3);

        lineEdit_113 = new QLineEdit(scrollAreaWidgetContents_16);
        lineEdit_113->setObjectName(QString::fromUtf8("lineEdit_113"));

        verticalLayout_97->addWidget(lineEdit_113);

        lineEdit_114 = new QLineEdit(scrollAreaWidgetContents_16);
        lineEdit_114->setObjectName(QString::fromUtf8("lineEdit_114"));

        verticalLayout_97->addWidget(lineEdit_114);


        gridLayout_34->addLayout(verticalLayout_97, 1, 1, 1, 1);

        scrollArea_12->setWidget(scrollAreaWidgetContents_16);

        verticalLayout_90->addWidget(scrollArea_12);

        label_122 = new QLabel(widget_38);
        label_122->setObjectName(QString::fromUtf8("label_122"));
        label_122->setFont(font2);

        verticalLayout_90->addWidget(label_122);

        scrollArea_13 = new QScrollArea(widget_38);
        scrollArea_13->setObjectName(QString::fromUtf8("scrollArea_13"));
        scrollArea_13->setWidgetResizable(true);
        scrollAreaWidgetContents_17 = new QWidget();
        scrollAreaWidgetContents_17->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_17"));
        scrollAreaWidgetContents_17->setGeometry(QRect(0, 0, 709, 124));
        gridLayout_35 = new QGridLayout(scrollAreaWidgetContents_17);
        gridLayout_35->setObjectName(QString::fromUtf8("gridLayout_35"));
        verticalLayout_98 = new QVBoxLayout();
        verticalLayout_98->setObjectName(QString::fromUtf8("verticalLayout_98"));
        AutreSpec_3 = new QLabel(scrollAreaWidgetContents_17);
        AutreSpec_3->setObjectName(QString::fromUtf8("AutreSpec_3"));

        verticalLayout_98->addWidget(AutreSpec_3);

        fontComboBox_23 = new QFontComboBox(scrollAreaWidgetContents_17);
        fontComboBox_23->setObjectName(QString::fromUtf8("fontComboBox_23"));

        verticalLayout_98->addWidget(fontComboBox_23);


        gridLayout_35->addLayout(verticalLayout_98, 0, 1, 1, 1);

        verticalLayout_99 = new QVBoxLayout();
        verticalLayout_99->setObjectName(QString::fromUtf8("verticalLayout_99"));
        AutreLieu_3 = new QLabel(scrollAreaWidgetContents_17);
        AutreLieu_3->setObjectName(QString::fromUtf8("AutreLieu_3"));

        verticalLayout_99->addWidget(AutreLieu_3);

        lineEdit_115 = new QLineEdit(scrollAreaWidgetContents_17);
        lineEdit_115->setObjectName(QString::fromUtf8("lineEdit_115"));

        verticalLayout_99->addWidget(lineEdit_115);


        gridLayout_35->addLayout(verticalLayout_99, 1, 1, 1, 1);

        verticalLayout_100 = new QVBoxLayout();
        verticalLayout_100->setObjectName(QString::fromUtf8("verticalLayout_100"));
        AutreTitre_3 = new QLabel(scrollAreaWidgetContents_17);
        AutreTitre_3->setObjectName(QString::fromUtf8("AutreTitre_3"));

        verticalLayout_100->addWidget(AutreTitre_3);

        fontComboBox_24 = new QFontComboBox(scrollAreaWidgetContents_17);
        fontComboBox_24->setObjectName(QString::fromUtf8("fontComboBox_24"));

        verticalLayout_100->addWidget(fontComboBox_24);


        gridLayout_35->addLayout(verticalLayout_100, 0, 0, 1, 1);

        verticalLayout_101 = new QVBoxLayout();
        verticalLayout_101->setObjectName(QString::fromUtf8("verticalLayout_101"));
        AutreDate_3 = new QLabel(scrollAreaWidgetContents_17);
        AutreDate_3->setObjectName(QString::fromUtf8("AutreDate_3"));

        verticalLayout_101->addWidget(AutreDate_3);

        lineEdit_116 = new QLineEdit(scrollAreaWidgetContents_17);
        lineEdit_116->setObjectName(QString::fromUtf8("lineEdit_116"));

        verticalLayout_101->addWidget(lineEdit_116);


        gridLayout_35->addLayout(verticalLayout_101, 0, 2, 1, 1);

        verticalLayout_102 = new QVBoxLayout();
        verticalLayout_102->setObjectName(QString::fromUtf8("verticalLayout_102"));
        AutrePer_3 = new QLabel(scrollAreaWidgetContents_17);
        AutrePer_3->setObjectName(QString::fromUtf8("AutrePer_3"));

        verticalLayout_102->addWidget(AutrePer_3);

        lineEdit_117 = new QLineEdit(scrollAreaWidgetContents_17);
        lineEdit_117->setObjectName(QString::fromUtf8("lineEdit_117"));

        verticalLayout_102->addWidget(lineEdit_117);


        gridLayout_35->addLayout(verticalLayout_102, 1, 0, 1, 1);

        scrollArea_13->setWidget(scrollAreaWidgetContents_17);

        verticalLayout_90->addWidget(scrollArea_13);

        widget_40 = new QWidget(widget_38);
        widget_40->setObjectName(QString::fromUtf8("widget_40"));
        verticalLayout_103 = new QVBoxLayout(widget_40);
        verticalLayout_103->setObjectName(QString::fromUtf8("verticalLayout_103"));
        label_123 = new QLabel(widget_40);
        label_123->setObjectName(QString::fromUtf8("label_123"));
        label_123->setFont(font2);

        verticalLayout_103->addWidget(label_123);


        verticalLayout_90->addWidget(widget_40);

        scrollArea_14 = new QScrollArea(widget_38);
        scrollArea_14->setObjectName(QString::fromUtf8("scrollArea_14"));
        scrollArea_14->setWidgetResizable(true);
        scrollAreaWidgetContents_18 = new QWidget();
        scrollAreaWidgetContents_18->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_18"));
        scrollAreaWidgetContents_18->setGeometry(QRect(0, 0, 1061, 124));
        gridLayout_36 = new QGridLayout(scrollAreaWidgetContents_18);
        gridLayout_36->setObjectName(QString::fromUtf8("gridLayout_36"));
        verticalLayout_104 = new QVBoxLayout();
        verticalLayout_104->setObjectName(QString::fromUtf8("verticalLayout_104"));
        CompOb_3 = new QLabel(scrollAreaWidgetContents_18);
        CompOb_3->setObjectName(QString::fromUtf8("CompOb_3"));

        verticalLayout_104->addWidget(CompOb_3);

        lineEdit_118 = new QLineEdit(scrollAreaWidgetContents_18);
        lineEdit_118->setObjectName(QString::fromUtf8("lineEdit_118"));

        verticalLayout_104->addWidget(lineEdit_118);


        gridLayout_36->addLayout(verticalLayout_104, 1, 4, 1, 1);

        verticalLayout_105 = new QVBoxLayout();
        verticalLayout_105->setObjectName(QString::fromUtf8("verticalLayout_105"));
        CompDoss_3 = new QLabel(scrollAreaWidgetContents_18);
        CompDoss_3->setObjectName(QString::fromUtf8("CompDoss_3"));

        verticalLayout_105->addWidget(CompDoss_3);

        fontComboBox_25 = new QFontComboBox(scrollAreaWidgetContents_18);
        fontComboBox_25->setObjectName(QString::fromUtf8("fontComboBox_25"));

        verticalLayout_105->addWidget(fontComboBox_25);


        gridLayout_36->addLayout(verticalLayout_105, 0, 2, 1, 1);

        verticalLayout_106 = new QVBoxLayout();
        verticalLayout_106->setObjectName(QString::fromUtf8("verticalLayout_106"));
        CompDate_3 = new QLabel(scrollAreaWidgetContents_18);
        CompDate_3->setObjectName(QString::fromUtf8("CompDate_3"));

        verticalLayout_106->addWidget(CompDate_3);

        lineEdit_119 = new QLineEdit(scrollAreaWidgetContents_18);
        lineEdit_119->setObjectName(QString::fromUtf8("lineEdit_119"));

        verticalLayout_106->addWidget(lineEdit_119);


        gridLayout_36->addLayout(verticalLayout_106, 0, 1, 1, 1);

        verticalLayout_107 = new QVBoxLayout();
        verticalLayout_107->setObjectName(QString::fromUtf8("verticalLayout_107"));
        CompDom_3 = new QLabel(scrollAreaWidgetContents_18);
        CompDom_3->setObjectName(QString::fromUtf8("CompDom_3"));

        verticalLayout_107->addWidget(CompDom_3);

        fontComboBox_26 = new QFontComboBox(scrollAreaWidgetContents_18);
        fontComboBox_26->setObjectName(QString::fromUtf8("fontComboBox_26"));

        verticalLayout_107->addWidget(fontComboBox_26);


        gridLayout_36->addLayout(verticalLayout_107, 0, 0, 1, 1);

        verticalLayout_108 = new QVBoxLayout();
        verticalLayout_108->setObjectName(QString::fromUtf8("verticalLayout_108"));
        CompDateAc_3 = new QLabel(scrollAreaWidgetContents_18);
        CompDateAc_3->setObjectName(QString::fromUtf8("CompDateAc_3"));

        verticalLayout_108->addWidget(CompDateAc_3);

        lineEdit_120 = new QLineEdit(scrollAreaWidgetContents_18);
        lineEdit_120->setObjectName(QString::fromUtf8("lineEdit_120"));

        verticalLayout_108->addWidget(lineEdit_120);


        gridLayout_36->addLayout(verticalLayout_108, 1, 0, 1, 1);

        verticalLayout_109 = new QVBoxLayout();
        verticalLayout_109->setObjectName(QString::fromUtf8("verticalLayout_109"));
        CompPv_3 = new QLabel(scrollAreaWidgetContents_18);
        CompPv_3->setObjectName(QString::fromUtf8("CompPv_3"));

        verticalLayout_109->addWidget(CompPv_3);

        lineEdit_121 = new QLineEdit(scrollAreaWidgetContents_18);
        lineEdit_121->setObjectName(QString::fromUtf8("lineEdit_121"));

        verticalLayout_109->addWidget(lineEdit_121);


        gridLayout_36->addLayout(verticalLayout_109, 1, 1, 1, 1);

        verticalLayout_110 = new QVBoxLayout();
        verticalLayout_110->setObjectName(QString::fromUtf8("verticalLayout_110"));
        CompAvis_3 = new QLabel(scrollAreaWidgetContents_18);
        CompAvis_3->setObjectName(QString::fromUtf8("CompAvis_3"));

        verticalLayout_110->addWidget(CompAvis_3);

        fontComboBox_27 = new QFontComboBox(scrollAreaWidgetContents_18);
        fontComboBox_27->setObjectName(QString::fromUtf8("fontComboBox_27"));

        verticalLayout_110->addWidget(fontComboBox_27);


        gridLayout_36->addLayout(verticalLayout_110, 0, 4, 1, 1);

        verticalLayout_111 = new QVBoxLayout();
        verticalLayout_111->setObjectName(QString::fromUtf8("verticalLayout_111"));
        CompTitr_3 = new QLabel(scrollAreaWidgetContents_18);
        CompTitr_3->setObjectName(QString::fromUtf8("CompTitr_3"));

        verticalLayout_111->addWidget(CompTitr_3);

        lineEdit_122 = new QLineEdit(scrollAreaWidgetContents_18);
        lineEdit_122->setObjectName(QString::fromUtf8("lineEdit_122"));

        verticalLayout_111->addWidget(lineEdit_122);


        gridLayout_36->addLayout(verticalLayout_111, 1, 2, 1, 1);

        verticalLayout_112 = new QVBoxLayout();
        verticalLayout_112->setObjectName(QString::fromUtf8("verticalLayout_112"));
        CompPer_3 = new QLabel(scrollAreaWidgetContents_18);
        CompPer_3->setObjectName(QString::fromUtf8("CompPer_3"));

        verticalLayout_112->addWidget(CompPer_3);

        lineEdit_123 = new QLineEdit(scrollAreaWidgetContents_18);
        lineEdit_123->setObjectName(QString::fromUtf8("lineEdit_123"));

        verticalLayout_112->addWidget(lineEdit_123);


        gridLayout_36->addLayout(verticalLayout_112, 0, 5, 1, 1);

        scrollArea_14->setWidget(scrollAreaWidgetContents_18);

        verticalLayout_90->addWidget(scrollArea_14);


        verticalLayout_89->addWidget(widget_38);


        verticalLayout_88->addWidget(widget_37);


        horizontalLayout_70->addWidget(widget_35);


        gridLayout_37->addWidget(widget_22, 0, 0, 1, 1);

        barInfo->addTab(specialites, QString());
        remplacement = new QWidget();
        remplacement->setObjectName(QString::fromUtf8("remplacement"));
        gridLayout_42 = new QGridLayout(remplacement);
        gridLayout_42->setObjectName(QString::fromUtf8("gridLayout_42"));
        widget_16 = new QWidget(remplacement);
        widget_16->setObjectName(QString::fromUtf8("widget_16"));
        verticalLayout_30 = new QVBoxLayout(widget_16);
        verticalLayout_30->setObjectName(QString::fromUtf8("verticalLayout_30"));
        lineEdit_9 = new QLineEdit(widget_16);
        lineEdit_9->setObjectName(QString::fromUtf8("lineEdit_9"));

        verticalLayout_30->addWidget(lineEdit_9);

        label_29 = new QLabel(widget_16);
        label_29->setObjectName(QString::fromUtf8("label_29"));

        verticalLayout_30->addWidget(label_29);

        lineEdit_10 = new QLineEdit(widget_16);
        lineEdit_10->setObjectName(QString::fromUtf8("lineEdit_10"));

        verticalLayout_30->addWidget(lineEdit_10);

        label_30 = new QLabel(widget_16);
        label_30->setObjectName(QString::fromUtf8("label_30"));

        verticalLayout_30->addWidget(label_30);

        tableWidget = new QTableWidget(widget_16);
        if (tableWidget->columnCount() < 3)
            tableWidget->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        if (tableWidget->rowCount() < 1)
            tableWidget->setRowCount(1);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(0, __qtablewidgetitem3);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setAutoScroll(true);
        tableWidget->horizontalHeader()->setDefaultSectionSize(266);
        tableWidget->verticalHeader()->setCascadingSectionResizes(false);

        verticalLayout_30->addWidget(tableWidget);


        gridLayout_42->addWidget(widget_16, 0, 0, 1, 1);

        barInfo->addTab(remplacement, QString());
        exercice = new QWidget();
        exercice->setObjectName(QString::fromUtf8("exercice"));
        gridLayout_39 = new QGridLayout(exercice);
        gridLayout_39->setObjectName(QString::fromUtf8("gridLayout_39"));
        frame_18 = new QFrame(exercice);
        frame_18->setObjectName(QString::fromUtf8("frame_18"));
        frame_18->setMinimumSize(QSize(0, 25));
        frame_18->setFrameShape(QFrame::StyledPanel);
        frame_18->setFrameShadow(QFrame::Raised);
        gridLayout_38 = new QGridLayout(frame_18);
        gridLayout_38->setObjectName(QString::fromUtf8("gridLayout_38"));
        frame_19 = new QFrame(frame_18);
        frame_19->setObjectName(QString::fromUtf8("frame_19"));
        frame_19->setMaximumSize(QSize(16777215, 16777215));
        frame_19->setStyleSheet(QString::fromUtf8(""));
        frame_19->setFrameShape(QFrame::StyledPanel);
        frame_19->setFrameShadow(QFrame::Raised);
        horizontalLayout_21 = new QHBoxLayout(frame_19);
        horizontalLayout_21->setSpacing(0);
        horizontalLayout_21->setObjectName(QString::fromUtf8("horizontalLayout_21"));
        horizontalLayout_21->setContentsMargins(0, 0, 0, 0);
        frame_20 = new QFrame(frame_19);
        frame_20->setObjectName(QString::fromUtf8("frame_20"));
        sizePolicy.setHeightForWidth(frame_20->sizePolicy().hasHeightForWidth());
        frame_20->setSizePolicy(sizePolicy);
        frame_20->setFrameShape(QFrame::StyledPanel);
        frame_20->setFrameShadow(QFrame::Raised);
        verticalLayout_13 = new QVBoxLayout(frame_20);
        verticalLayout_13->setSpacing(0);
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        verticalLayout_13->setContentsMargins(0, 0, -1, 0);
        frame_21 = new QFrame(frame_20);
        frame_21->setObjectName(QString::fromUtf8("frame_21"));
        frame_21->setStyleSheet(QString::fromUtf8("border:none;"));
        frame_21->setFrameShape(QFrame::StyledPanel);
        frame_21->setFrameShadow(QFrame::Raised);
        horizontalLayout_22 = new QHBoxLayout(frame_21);
        horizontalLayout_22->setSpacing(0);
        horizontalLayout_22->setObjectName(QString::fromUtf8("horizontalLayout_22"));
        horizontalLayout_22->setContentsMargins(8, 0, 0, 0);
        label_55 = new QLabel(frame_21);
        label_55->setObjectName(QString::fromUtf8("label_55"));
        label_55->setMinimumSize(QSize(100, 25));
        label_55->setMaximumSize(QSize(100, 16777215));

        horizontalLayout_22->addWidget(label_55);

        lineEdit_32 = new QLineEdit(frame_21);
        lineEdit_32->setObjectName(QString::fromUtf8("lineEdit_32"));
        lineEdit_32->setMinimumSize(QSize(200, 25));
        lineEdit_32->setMaximumSize(QSize(300, 16777215));
        lineEdit_32->setStyleSheet(QString::fromUtf8("	border-radius:3px;\n"
"	border:1.5px solid rgb(53, 132, 228);"));

        horizontalLayout_22->addWidget(lineEdit_32);


        verticalLayout_13->addWidget(frame_21, 0, Qt::AlignLeft);

        frame_22 = new QFrame(frame_20);
        frame_22->setObjectName(QString::fromUtf8("frame_22"));
        frame_22->setStyleSheet(QString::fromUtf8("border:none;"));
        frame_22->setFrameShape(QFrame::StyledPanel);
        frame_22->setFrameShadow(QFrame::Raised);
        horizontalLayout_23 = new QHBoxLayout(frame_22);
        horizontalLayout_23->setSpacing(0);
        horizontalLayout_23->setObjectName(QString::fromUtf8("horizontalLayout_23"));
        horizontalLayout_23->setContentsMargins(8, 0, 0, 0);
        label_56 = new QLabel(frame_22);
        label_56->setObjectName(QString::fromUtf8("label_56"));
        label_56->setMinimumSize(QSize(100, 25));
        label_56->setMaximumSize(QSize(100, 16777215));

        horizontalLayout_23->addWidget(label_56);

        lineEdit_33 = new QLineEdit(frame_22);
        lineEdit_33->setObjectName(QString::fromUtf8("lineEdit_33"));
        lineEdit_33->setMinimumSize(QSize(200, 25));
        lineEdit_33->setMaximumSize(QSize(300, 16777215));
        lineEdit_33->setStyleSheet(QString::fromUtf8("	border-radius:3px;\n"
"	border:1.5px solid rgb(53, 132, 228);"));

        horizontalLayout_23->addWidget(lineEdit_33);


        verticalLayout_13->addWidget(frame_22, 0, Qt::AlignLeft);


        horizontalLayout_21->addWidget(frame_20);

        frame_23 = new QFrame(frame_19);
        frame_23->setObjectName(QString::fromUtf8("frame_23"));
        sizePolicy.setHeightForWidth(frame_23->sizePolicy().hasHeightForWidth());
        frame_23->setSizePolicy(sizePolicy);
        frame_23->setFrameShape(QFrame::StyledPanel);
        frame_23->setFrameShadow(QFrame::Raised);
        verticalLayout_14 = new QVBoxLayout(frame_23);
        verticalLayout_14->setSpacing(0);
        verticalLayout_14->setObjectName(QString::fromUtf8("verticalLayout_14"));
        verticalLayout_14->setContentsMargins(8, 0, 0, 0);
        checkBox_22 = new QCheckBox(frame_23);
        checkBox_22->setObjectName(QString::fromUtf8("checkBox_22"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(checkBox_22->sizePolicy().hasHeightForWidth());
        checkBox_22->setSizePolicy(sizePolicy1);
        checkBox_22->setMinimumSize(QSize(350, 0));
        checkBox_22->setAutoRepeatDelay(304);
        checkBox_22->setTristate(false);

        verticalLayout_14->addWidget(checkBox_22);

        frame_24 = new QFrame(frame_23);
        frame_24->setObjectName(QString::fromUtf8("frame_24"));
        frame_24->setStyleSheet(QString::fromUtf8("border:none;"));
        frame_24->setFrameShape(QFrame::StyledPanel);
        frame_24->setFrameShadow(QFrame::Raised);
        horizontalLayout_24 = new QHBoxLayout(frame_24);
        horizontalLayout_24->setObjectName(QString::fromUtf8("horizontalLayout_24"));
        horizontalLayout_24->setContentsMargins(0, 0, 0, 0);
        label_57 = new QLabel(frame_24);
        label_57->setObjectName(QString::fromUtf8("label_57"));
        label_57->setMinimumSize(QSize(100, 25));
        label_57->setMaximumSize(QSize(16777215, 16777215));
        QFont font3;
        font3.setPointSize(11);
        label_57->setFont(font3);

        horizontalLayout_24->addWidget(label_57);

        lineEdit_34 = new QLineEdit(frame_24);
        lineEdit_34->setObjectName(QString::fromUtf8("lineEdit_34"));
        lineEdit_34->setMinimumSize(QSize(200, 25));
        lineEdit_34->setMaximumSize(QSize(200, 16777215));
        lineEdit_34->setStyleSheet(QString::fromUtf8("	border-radius:3px;\n"
"	border:1.5px solid rgb(53, 132, 228);"));

        horizontalLayout_24->addWidget(lineEdit_34);


        verticalLayout_14->addWidget(frame_24, 0, Qt::AlignLeft);

        frame_25 = new QFrame(frame_23);
        frame_25->setObjectName(QString::fromUtf8("frame_25"));
        frame_25->setStyleSheet(QString::fromUtf8("border:none;"));
        frame_25->setFrameShape(QFrame::StyledPanel);
        frame_25->setFrameShadow(QFrame::Raised);
        horizontalLayout_25 = new QHBoxLayout(frame_25);
        horizontalLayout_25->setSpacing(10);
        horizontalLayout_25->setObjectName(QString::fromUtf8("horizontalLayout_25"));
        horizontalLayout_25->setContentsMargins(0, 0, 0, 0);
        label_58 = new QLabel(frame_25);
        label_58->setObjectName(QString::fromUtf8("label_58"));
        label_58->setMinimumSize(QSize(100, 25));
        label_58->setMaximumSize(QSize(16777215, 16777215));

        horizontalLayout_25->addWidget(label_58);

        lineEdit_35 = new QLineEdit(frame_25);
        lineEdit_35->setObjectName(QString::fromUtf8("lineEdit_35"));
        lineEdit_35->setMinimumSize(QSize(100, 25));
        lineEdit_35->setMaximumSize(QSize(100, 16777215));
        lineEdit_35->setStyleSheet(QString::fromUtf8("	border-radius:3px;\n"
"	border:1.5px solid rgb(53, 132, 228);"));

        horizontalLayout_25->addWidget(lineEdit_35);

        label_59 = new QLabel(frame_25);
        label_59->setObjectName(QString::fromUtf8("label_59"));
        label_59->setMinimumSize(QSize(70, 25));

        horizontalLayout_25->addWidget(label_59);

        lineEdit_36 = new QLineEdit(frame_25);
        lineEdit_36->setObjectName(QString::fromUtf8("lineEdit_36"));
        lineEdit_36->setMinimumSize(QSize(100, 25));
        lineEdit_36->setMaximumSize(QSize(100, 16777215));
        lineEdit_36->setStyleSheet(QString::fromUtf8("	border-radius:3px;\n"
"	border:1.5px solid rgb(53, 132, 228);"));

        horizontalLayout_25->addWidget(lineEdit_36);


        verticalLayout_14->addWidget(frame_25, 0, Qt::AlignLeft);


        horizontalLayout_21->addWidget(frame_23);


        gridLayout_38->addWidget(frame_19, 0, 0, 1, 1);

        frame_26 = new QFrame(frame_18);
        frame_26->setObjectName(QString::fromUtf8("frame_26"));
        frame_26->setStyleSheet(QString::fromUtf8(""));
        frame_26->setFrameShape(QFrame::StyledPanel);
        frame_26->setFrameShadow(QFrame::Raised);
        verticalLayout_15 = new QVBoxLayout(frame_26);
        verticalLayout_15->setSpacing(6);
        verticalLayout_15->setObjectName(QString::fromUtf8("verticalLayout_15"));
        verticalLayout_15->setContentsMargins(0, -1, 0, 0);
        label_60 = new QLabel(frame_26);
        label_60->setObjectName(QString::fromUtf8("label_60"));
        label_60->setMaximumSize(QSize(16777215, 25));
        QFont font4;
        font4.setPointSize(14);
        font4.setBold(true);
        label_60->setFont(font4);

        verticalLayout_15->addWidget(label_60);

        frame_27 = new QFrame(frame_26);
        frame_27->setObjectName(QString::fromUtf8("frame_27"));
        sizePolicy.setHeightForWidth(frame_27->sizePolicy().hasHeightForWidth());
        frame_27->setSizePolicy(sizePolicy);
        frame_27->setFrameShape(QFrame::StyledPanel);
        frame_27->setFrameShadow(QFrame::Raised);
        horizontalLayout_26 = new QHBoxLayout(frame_27);
        horizontalLayout_26->setSpacing(0);
        horizontalLayout_26->setObjectName(QString::fromUtf8("horizontalLayout_26"));
        horizontalLayout_26->setContentsMargins(0, 0, 0, 0);
        frame_28 = new QFrame(frame_27);
        frame_28->setObjectName(QString::fromUtf8("frame_28"));
        frame_28->setFrameShape(QFrame::StyledPanel);
        frame_28->setFrameShadow(QFrame::Raised);
        verticalLayout_16 = new QVBoxLayout(frame_28);
        verticalLayout_16->setObjectName(QString::fromUtf8("verticalLayout_16"));
        label_61 = new QLabel(frame_28);
        label_61->setObjectName(QString::fromUtf8("label_61"));

        verticalLayout_16->addWidget(label_61);

        lineEdit_37 = new QLineEdit(frame_28);
        lineEdit_37->setObjectName(QString::fromUtf8("lineEdit_37"));

        verticalLayout_16->addWidget(lineEdit_37);


        horizontalLayout_26->addWidget(frame_28);

        frame_29 = new QFrame(frame_27);
        frame_29->setObjectName(QString::fromUtf8("frame_29"));
        frame_29->setFrameShape(QFrame::StyledPanel);
        frame_29->setFrameShadow(QFrame::Raised);
        verticalLayout_17 = new QVBoxLayout(frame_29);
        verticalLayout_17->setObjectName(QString::fromUtf8("verticalLayout_17"));
        label_62 = new QLabel(frame_29);
        label_62->setObjectName(QString::fromUtf8("label_62"));

        verticalLayout_17->addWidget(label_62);

        lineEdit_38 = new QLineEdit(frame_29);
        lineEdit_38->setObjectName(QString::fromUtf8("lineEdit_38"));

        verticalLayout_17->addWidget(lineEdit_38);


        horizontalLayout_26->addWidget(frame_29);

        frame_30 = new QFrame(frame_27);
        frame_30->setObjectName(QString::fromUtf8("frame_30"));
        frame_30->setFrameShape(QFrame::StyledPanel);
        frame_30->setFrameShadow(QFrame::Raised);
        verticalLayout_18 = new QVBoxLayout(frame_30);
        verticalLayout_18->setObjectName(QString::fromUtf8("verticalLayout_18"));
        label_63 = new QLabel(frame_30);
        label_63->setObjectName(QString::fromUtf8("label_63"));

        verticalLayout_18->addWidget(label_63);

        lineEdit_39 = new QLineEdit(frame_30);
        lineEdit_39->setObjectName(QString::fromUtf8("lineEdit_39"));

        verticalLayout_18->addWidget(lineEdit_39);


        horizontalLayout_26->addWidget(frame_30);


        verticalLayout_15->addWidget(frame_27);


        gridLayout_38->addWidget(frame_26, 1, 0, 1, 1);

        frame_31 = new QFrame(frame_18);
        frame_31->setObjectName(QString::fromUtf8("frame_31"));
        frame_31->setFrameShape(QFrame::StyledPanel);
        frame_31->setFrameShadow(QFrame::Raised);
        verticalLayout_19 = new QVBoxLayout(frame_31);
        verticalLayout_19->setObjectName(QString::fromUtf8("verticalLayout_19"));
        verticalLayout_19->setContentsMargins(0, 9, 0, 0);
        label_64 = new QLabel(frame_31);
        label_64->setObjectName(QString::fromUtf8("label_64"));
        label_64->setMaximumSize(QSize(16777215, 25));
        label_64->setFont(font4);

        verticalLayout_19->addWidget(label_64);

        frame_32 = new QFrame(frame_31);
        frame_32->setObjectName(QString::fromUtf8("frame_32"));
        frame_32->setFrameShape(QFrame::StyledPanel);
        frame_32->setFrameShadow(QFrame::Raised);
        horizontalLayout_27 = new QHBoxLayout(frame_32);
        horizontalLayout_27->setSpacing(0);
        horizontalLayout_27->setObjectName(QString::fromUtf8("horizontalLayout_27"));
        horizontalLayout_27->setContentsMargins(0, 0, 0, 0);
        frame_33 = new QFrame(frame_32);
        frame_33->setObjectName(QString::fromUtf8("frame_33"));
        frame_33->setFrameShape(QFrame::StyledPanel);
        frame_33->setFrameShadow(QFrame::Raised);
        verticalLayout_20 = new QVBoxLayout(frame_33);
        verticalLayout_20->setObjectName(QString::fromUtf8("verticalLayout_20"));
        label_65 = new QLabel(frame_33);
        label_65->setObjectName(QString::fromUtf8("label_65"));

        verticalLayout_20->addWidget(label_65);

        lineEdit_40 = new QLineEdit(frame_33);
        lineEdit_40->setObjectName(QString::fromUtf8("lineEdit_40"));

        verticalLayout_20->addWidget(lineEdit_40);


        horizontalLayout_27->addWidget(frame_33);

        frame_34 = new QFrame(frame_32);
        frame_34->setObjectName(QString::fromUtf8("frame_34"));
        frame_34->setFrameShape(QFrame::StyledPanel);
        frame_34->setFrameShadow(QFrame::Raised);
        verticalLayout_21 = new QVBoxLayout(frame_34);
        verticalLayout_21->setObjectName(QString::fromUtf8("verticalLayout_21"));
        label_66 = new QLabel(frame_34);
        label_66->setObjectName(QString::fromUtf8("label_66"));

        verticalLayout_21->addWidget(label_66);

        lineEdit_41 = new QLineEdit(frame_34);
        lineEdit_41->setObjectName(QString::fromUtf8("lineEdit_41"));

        verticalLayout_21->addWidget(lineEdit_41);


        horizontalLayout_27->addWidget(frame_34);

        frame_35 = new QFrame(frame_32);
        frame_35->setObjectName(QString::fromUtf8("frame_35"));
        frame_35->setFrameShape(QFrame::StyledPanel);
        frame_35->setFrameShadow(QFrame::Raised);
        verticalLayout_22 = new QVBoxLayout(frame_35);
        verticalLayout_22->setObjectName(QString::fromUtf8("verticalLayout_22"));
        label_67 = new QLabel(frame_35);
        label_67->setObjectName(QString::fromUtf8("label_67"));

        verticalLayout_22->addWidget(label_67);

        lineEdit_42 = new QLineEdit(frame_35);
        lineEdit_42->setObjectName(QString::fromUtf8("lineEdit_42"));

        verticalLayout_22->addWidget(lineEdit_42);


        horizontalLayout_27->addWidget(frame_35);


        verticalLayout_19->addWidget(frame_32);


        gridLayout_38->addWidget(frame_31, 2, 0, 1, 1);

        frame_36 = new QFrame(frame_18);
        frame_36->setObjectName(QString::fromUtf8("frame_36"));
        frame_36->setFrameShape(QFrame::StyledPanel);
        frame_36->setFrameShadow(QFrame::Raised);
        verticalLayout_23 = new QVBoxLayout(frame_36);
        verticalLayout_23->setSpacing(0);
        verticalLayout_23->setObjectName(QString::fromUtf8("verticalLayout_23"));
        verticalLayout_23->setContentsMargins(0, -1, 0, 25);
        label_68 = new QLabel(frame_36);
        label_68->setObjectName(QString::fromUtf8("label_68"));
        label_68->setMaximumSize(QSize(16777215, 30));
        label_68->setFont(font4);

        verticalLayout_23->addWidget(label_68);

        horizontalLayout_28 = new QHBoxLayout();
        horizontalLayout_28->setObjectName(QString::fromUtf8("horizontalLayout_28"));
        label_69 = new QLabel(frame_36);
        label_69->setObjectName(QString::fromUtf8("label_69"));

        horizontalLayout_28->addWidget(label_69);

        lineEdit_43 = new QLineEdit(frame_36);
        lineEdit_43->setObjectName(QString::fromUtf8("lineEdit_43"));
        lineEdit_43->setMaximumSize(QSize(300, 16777215));

        horizontalLayout_28->addWidget(lineEdit_43);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_28->addItem(horizontalSpacer_4);


        verticalLayout_23->addLayout(horizontalLayout_28);


        gridLayout_38->addWidget(frame_36, 3, 0, 1, 1);


        gridLayout_39->addWidget(frame_18, 0, 0, 1, 1);

        barInfo->addTab(exercice, QString());
        distinctionH = new QWidget();
        distinctionH->setObjectName(QString::fromUtf8("distinctionH"));
        gridLayout_7 = new QGridLayout(distinctionH);
        gridLayout_7->setObjectName(QString::fromUtf8("gridLayout_7"));
        label_77 = new QLabel(distinctionH);
        label_77->setObjectName(QString::fromUtf8("label_77"));
        label_77->setMinimumSize(QSize(100, 0));
        label_77->setMaximumSize(QSize(100, 16777215));

        gridLayout_7->addWidget(label_77, 0, 0, 1, 1);

        label_76 = new QLabel(distinctionH);
        label_76->setObjectName(QString::fromUtf8("label_76"));
        label_76->setMinimumSize(QSize(100, 0));
        label_76->setMaximumSize(QSize(100, 16777215));

        gridLayout_7->addWidget(label_76, 1, 0, 1, 1);

        lineEdit_49 = new QLineEdit(distinctionH);
        lineEdit_49->setObjectName(QString::fromUtf8("lineEdit_49"));
        lineEdit_49->setMinimumSize(QSize(0, 30));
        lineEdit_49->setMaximumSize(QSize(600, 16777215));

        gridLayout_7->addWidget(lineEdit_49, 0, 1, 1, 1);

        groupBox_17 = new QGroupBox(distinctionH);
        groupBox_17->setObjectName(QString::fromUtf8("groupBox_17"));
        verticalLayout_11 = new QVBoxLayout(groupBox_17);
        verticalLayout_11->setSpacing(5);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        verticalLayout_11->setContentsMargins(0, 0, 0, 0);
        frame_48 = new QFrame(groupBox_17);
        frame_48->setObjectName(QString::fromUtf8("frame_48"));
        frame_48->setMaximumSize(QSize(16777215, 80));
        frame_48->setFrameShape(QFrame::StyledPanel);
        frame_48->setFrameShadow(QFrame::Raised);
        gridLayout_45 = new QGridLayout(frame_48);
        gridLayout_45->setObjectName(QString::fromUtf8("gridLayout_45"));
        label_127 = new QLabel(frame_48);
        label_127->setObjectName(QString::fromUtf8("label_127"));
        label_127->setMaximumSize(QSize(300, 16777215));

        gridLayout_45->addWidget(label_127, 0, 0, 1, 1);

        label_128 = new QLabel(frame_48);
        label_128->setObjectName(QString::fromUtf8("label_128"));
        label_128->setMaximumSize(QSize(300, 16777215));

        gridLayout_45->addWidget(label_128, 0, 1, 1, 1);

        comboBox_9 = new QComboBox(frame_48);
        comboBox_9->setObjectName(QString::fromUtf8("comboBox_9"));
        comboBox_9->setMinimumSize(QSize(0, 30));
        comboBox_9->setMaximumSize(QSize(300, 16777215));

        gridLayout_45->addWidget(comboBox_9, 1, 0, 1, 1);

        lineEdit_161 = new QLineEdit(frame_48);
        lineEdit_161->setObjectName(QString::fromUtf8("lineEdit_161"));
        lineEdit_161->setMinimumSize(QSize(0, 30));
        lineEdit_161->setMaximumSize(QSize(300, 16777215));

        gridLayout_45->addWidget(lineEdit_161, 1, 1, 1, 1);


        verticalLayout_11->addWidget(frame_48);

        frame_47 = new QFrame(groupBox_17);
        frame_47->setObjectName(QString::fromUtf8("frame_47"));
        frame_47->setFrameShape(QFrame::StyledPanel);
        frame_47->setFrameShadow(QFrame::Raised);
        gridLayout_46 = new QGridLayout(frame_47);
        gridLayout_46->setSpacing(0);
        gridLayout_46->setObjectName(QString::fromUtf8("gridLayout_46"));
        gridLayout_46->setContentsMargins(0, 0, 0, 0);
        plainTextEdit = new QPlainTextEdit(frame_47);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));

        gridLayout_46->addWidget(plainTextEdit, 0, 0, 1, 1);


        verticalLayout_11->addWidget(frame_47);


        gridLayout_7->addWidget(groupBox_17, 3, 0, 1, 2);

        lineEdit_50 = new QLineEdit(distinctionH);
        lineEdit_50->setObjectName(QString::fromUtf8("lineEdit_50"));
        lineEdit_50->setMinimumSize(QSize(0, 30));
        lineEdit_50->setMaximumSize(QSize(600, 16777215));

        gridLayout_7->addWidget(lineEdit_50, 1, 1, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Maximum);

        gridLayout_7->addItem(verticalSpacer_2, 2, 1, 1, 1);

        widget_44 = new QWidget(distinctionH);
        widget_44->setObjectName(QString::fromUtf8("widget_44"));
        widget_44->setMinimumSize(QSize(100, 0));
        widget_44->setMaximumSize(QSize(200, 16777215));
        verticalLayout_9 = new QVBoxLayout(widget_44);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        pushButton_21 = new QPushButton(widget_44);
        pushButton_21->setObjectName(QString::fromUtf8("pushButton_21"));
        pushButton_21->setMinimumSize(QSize(0, 40));

        verticalLayout_9->addWidget(pushButton_21);

        pushButton_23 = new QPushButton(widget_44);
        pushButton_23->setObjectName(QString::fromUtf8("pushButton_23"));
        pushButton_23->setMinimumSize(QSize(0, 40));

        verticalLayout_9->addWidget(pushButton_23);

        pushButton_22 = new QPushButton(widget_44);
        pushButton_22->setObjectName(QString::fromUtf8("pushButton_22"));
        pushButton_22->setMinimumSize(QSize(0, 40));

        verticalLayout_9->addWidget(pushButton_22);


        gridLayout_7->addWidget(widget_44, 0, 2, 3, 1);

        barInfo->addTab(distinctionH, QString());
        extra = new QWidget();
        extra->setObjectName(QString::fromUtf8("extra"));
        gridLayout_11 = new QGridLayout(extra);
        gridLayout_11->setObjectName(QString::fromUtf8("gridLayout_11"));
        frame_37 = new QFrame(extra);
        frame_37->setObjectName(QString::fromUtf8("frame_37"));
        frame_37->setFrameShape(QFrame::StyledPanel);
        frame_37->setFrameShadow(QFrame::Raised);
        verticalLayout_25 = new QVBoxLayout(frame_37);
        verticalLayout_25->setSpacing(50);
        verticalLayout_25->setObjectName(QString::fromUtf8("verticalLayout_25"));
        verticalLayout_25->setContentsMargins(-1, 20, -1, 20);
        frame_38 = new QFrame(frame_37);
        frame_38->setObjectName(QString::fromUtf8("frame_38"));
        frame_38->setMinimumSize(QSize(0, 150));
        frame_38->setFrameShape(QFrame::StyledPanel);
        frame_38->setFrameShadow(QFrame::Raised);
        verticalLayout_26 = new QVBoxLayout(frame_38);
        verticalLayout_26->setSpacing(0);
        verticalLayout_26->setObjectName(QString::fromUtf8("verticalLayout_26"));
        verticalLayout_26->setContentsMargins(0, 0, 0, 0);
        frame_39 = new QFrame(frame_38);
        frame_39->setObjectName(QString::fromUtf8("frame_39"));
        frame_39->setFrameShape(QFrame::NoFrame);
        frame_39->setFrameShadow(QFrame::Raised);
        horizontalLayout_29 = new QHBoxLayout(frame_39);
        horizontalLayout_29->setSpacing(50);
        horizontalLayout_29->setObjectName(QString::fromUtf8("horizontalLayout_29"));
        horizontalLayout_29->setContentsMargins(30, 10, 20, 0);
        label_70 = new QLabel(frame_39);
        label_70->setObjectName(QString::fromUtf8("label_70"));
        label_70->setMinimumSize(QSize(30, 0));
        label_70->setScaledContents(false);

        horizontalLayout_29->addWidget(label_70);

        lineEdit_44 = new QLineEdit(frame_39);
        lineEdit_44->setObjectName(QString::fromUtf8("lineEdit_44"));
        lineEdit_44->setMinimumSize(QSize(230, 25));

        horizontalLayout_29->addWidget(lineEdit_44);


        verticalLayout_26->addWidget(frame_39, 0, Qt::AlignLeft);

        frame_40 = new QFrame(frame_38);
        frame_40->setObjectName(QString::fromUtf8("frame_40"));
        frame_40->setFrameShape(QFrame::NoFrame);
        frame_40->setFrameShadow(QFrame::Raised);
        horizontalLayout_30 = new QHBoxLayout(frame_40);
        horizontalLayout_30->setSpacing(15);
        horizontalLayout_30->setObjectName(QString::fromUtf8("horizontalLayout_30"));
        horizontalLayout_30->setContentsMargins(30, 0, 20, 10);
        label_71 = new QLabel(frame_40);
        label_71->setObjectName(QString::fromUtf8("label_71"));
        label_71->setScaledContents(false);

        horizontalLayout_30->addWidget(label_71);

        lineEdit_45 = new QLineEdit(frame_40);
        lineEdit_45->setObjectName(QString::fromUtf8("lineEdit_45"));
        lineEdit_45->setMinimumSize(QSize(230, 25));

        horizontalLayout_30->addWidget(lineEdit_45);


        verticalLayout_26->addWidget(frame_40, 0, Qt::AlignLeft);


        verticalLayout_25->addWidget(frame_38, 0, Qt::AlignTop);

        frame_41 = new QFrame(frame_37);
        frame_41->setObjectName(QString::fromUtf8("frame_41"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(frame_41->sizePolicy().hasHeightForWidth());
        frame_41->setSizePolicy(sizePolicy2);
        frame_41->setFrameShape(QFrame::StyledPanel);
        frame_41->setFrameShadow(QFrame::Raised);
        verticalLayout_27 = new QVBoxLayout(frame_41);
        verticalLayout_27->setSpacing(0);
        verticalLayout_27->setObjectName(QString::fromUtf8("verticalLayout_27"));
        verticalLayout_27->setContentsMargins(0, 0, 0, 0);
        label_72 = new QLabel(frame_41);
        label_72->setObjectName(QString::fromUtf8("label_72"));
        label_72->setMinimumSize(QSize(0, 70));
        QFont font5;
        font5.setPointSize(13);
        font5.setBold(true);
        label_72->setFont(font5);
        label_72->setMidLineWidth(0);
        label_72->setMargin(0);

        verticalLayout_27->addWidget(label_72);

        frame_42 = new QFrame(frame_41);
        frame_42->setObjectName(QString::fromUtf8("frame_42"));
        sizePolicy2.setHeightForWidth(frame_42->sizePolicy().hasHeightForWidth());
        frame_42->setSizePolicy(sizePolicy2);
        frame_42->setFrameShape(QFrame::StyledPanel);
        frame_42->setFrameShadow(QFrame::Raised);
        frame_42->setLineWidth(5);
        verticalLayout_28 = new QVBoxLayout(frame_42);
        verticalLayout_28->setSpacing(0);
        verticalLayout_28->setObjectName(QString::fromUtf8("verticalLayout_28"));
        verticalLayout_28->setContentsMargins(0, 0, 0, 0);
        frame_43 = new QFrame(frame_42);
        frame_43->setObjectName(QString::fromUtf8("frame_43"));
        layout_3 = new QHBoxLayout(frame_43);
        layout_3->setSpacing(35);
        layout_3->setObjectName(QString::fromUtf8("layout_3"));
        layout_3->setContentsMargins(20, 0, 0, 0);
        label_73 = new QLabel(frame_43);
        label_73->setObjectName(QString::fromUtf8("label_73"));
        label_73->setMargin(10);

        layout_3->addWidget(label_73, 0, Qt::AlignLeft);

        lineEdit_46 = new QLineEdit(frame_43);
        lineEdit_46->setObjectName(QString::fromUtf8("lineEdit_46"));
        lineEdit_46->setMinimumSize(QSize(230, 25));
        lineEdit_46->setFont(font1);
        lineEdit_46->setDragEnabled(true);
        lineEdit_46->setPlaceholderText(QString::fromUtf8(""));

        layout_3->addWidget(lineEdit_46);


        verticalLayout_28->addWidget(frame_43, 0, Qt::AlignLeft);

        frame_44 = new QFrame(frame_42);
        frame_44->setObjectName(QString::fromUtf8("frame_44"));
        layout = new QHBoxLayout(frame_44);
        layout->setSpacing(30);
        layout->setObjectName(QString::fromUtf8("layout"));
        layout->setContentsMargins(20, 0, 0, 0);
        label_74 = new QLabel(frame_44);
        label_74->setObjectName(QString::fromUtf8("label_74"));
        label_74->setMargin(10);

        layout->addWidget(label_74);

        lineEdit_47 = new QLineEdit(frame_44);
        lineEdit_47->setObjectName(QString::fromUtf8("lineEdit_47"));
        lineEdit_47->setMinimumSize(QSize(230, 25));
        lineEdit_47->setFont(font1);
        lineEdit_47->setDragEnabled(true);
        lineEdit_47->setPlaceholderText(QString::fromUtf8(""));

        layout->addWidget(lineEdit_47);


        verticalLayout_28->addWidget(frame_44, 0, Qt::AlignLeft);

        frame_45 = new QFrame(frame_42);
        frame_45->setObjectName(QString::fromUtf8("frame_45"));
        layout_2 = new QHBoxLayout(frame_45);
        layout_2->setSpacing(15);
        layout_2->setObjectName(QString::fromUtf8("layout_2"));
        layout_2->setContentsMargins(20, 0, 0, 0);
        label_75 = new QLabel(frame_45);
        label_75->setObjectName(QString::fromUtf8("label_75"));
        label_75->setMargin(10);

        layout_2->addWidget(label_75);

        lineEdit_48 = new QLineEdit(frame_45);
        lineEdit_48->setObjectName(QString::fromUtf8("lineEdit_48"));
        lineEdit_48->setMinimumSize(QSize(230, 25));
        lineEdit_48->setFont(font1);
        lineEdit_48->setDragEnabled(true);
        lineEdit_48->setPlaceholderText(QString::fromUtf8(""));

        layout_2->addWidget(lineEdit_48);


        verticalLayout_28->addWidget(frame_45, 0, Qt::AlignLeft);


        verticalLayout_27->addWidget(frame_42);


        verticalLayout_25->addWidget(frame_41);


        gridLayout_11->addWidget(frame_37, 0, 0, 1, 1);

        barInfo->addTab(extra, QString());
        judiciaire = new QWidget();
        judiciaire->setObjectName(QString::fromUtf8("judiciaire"));
        gridLayout_13 = new QGridLayout(judiciaire);
        gridLayout_13->setObjectName(QString::fromUtf8("gridLayout_13"));
        widget_20 = new QWidget(judiciaire);
        widget_20->setObjectName(QString::fromUtf8("widget_20"));
        widget_20->setMaximumSize(QSize(2000, 16777215));
        verticalLayout_36 = new QVBoxLayout(widget_20);
        verticalLayout_36->setObjectName(QString::fromUtf8("verticalLayout_36"));
        horizontalLayout_52 = new QHBoxLayout();
        horizontalLayout_52->setSpacing(6);
        horizontalLayout_52->setObjectName(QString::fromUtf8("horizontalLayout_52"));
        horizontalLayout_53 = new QHBoxLayout();
        horizontalLayout_53->setObjectName(QString::fromUtf8("horizontalLayout_53"));
        label_106 = new QLabel(widget_20);
        label_106->setObjectName(QString::fromUtf8("label_106"));
        label_106->setStyleSheet(QString::fromUtf8("QLabel{\n"
"    background-color: rgba(100, 149, 237, 0.7); /* Couleur de fond avec transparence */\n"
"    color: white; /* Couleur du texte */\n"
"    font-size: 16px; /* Taille de la police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border-radius: 5px; /* Bordure arrondie */\n"
"    padding: 5px 10px; /* Espacement int\303\251rieur */\n"
"}\n"
""));

        horizontalLayout_53->addWidget(label_106);

        lineEdit_74 = new QLineEdit(widget_20);
        lineEdit_74->setObjectName(QString::fromUtf8("lineEdit_74"));

        horizontalLayout_53->addWidget(lineEdit_74);


        horizontalLayout_52->addLayout(horizontalLayout_53);

        horizontalLayout_54 = new QHBoxLayout();
        horizontalLayout_54->setObjectName(QString::fromUtf8("horizontalLayout_54"));
        label_107 = new QLabel(widget_20);
        label_107->setObjectName(QString::fromUtf8("label_107"));
        label_107->setStyleSheet(QString::fromUtf8("QLabel{\n"
"    background-color: rgba(100, 149, 237, 0.7); /* Couleur de fond avec transparence */\n"
"    color: white; /* Couleur du texte */\n"
"    font-size: 16px; /* Taille de la police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border-radius: 5px; /* Bordure arrondie */\n"
"    padding: 5px 10px; /* Espacement int\303\251rieur */\n"
"}\n"
""));

        horizontalLayout_54->addWidget(label_107);

        lineEdit_75 = new QLineEdit(widget_20);
        lineEdit_75->setObjectName(QString::fromUtf8("lineEdit_75"));

        horizontalLayout_54->addWidget(lineEdit_75);


        horizontalLayout_52->addLayout(horizontalLayout_54);


        verticalLayout_36->addLayout(horizontalLayout_52);

        label_108 = new QLabel(widget_20);
        label_108->setObjectName(QString::fromUtf8("label_108"));
        label_108->setMaximumSize(QSize(16777215, 20));
        label_108->setStyleSheet(QString::fromUtf8("QLabel{\n"
"    font-size: 24px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: rgba(51, 51, 51, 1); /* Couleur du texte */\n"
"}\n"
""));

        verticalLayout_36->addWidget(label_108, 0, Qt::AlignLeft|Qt::AlignBottom);


        gridLayout_13->addWidget(widget_20, 0, 0, 1, 1);

        leftMenu = new QWidget(judiciaire);
        leftMenu->setObjectName(QString::fromUtf8("leftMenu"));
        leftMenu->setMaximumSize(QSize(16777215, 2000));
        QFont font6;
        font6.setItalic(false);
        leftMenu->setFont(font6);
        leftMenu->setStyleSheet(QString::fromUtf8("#leftMenu {\n"
"    background-color: rgba(245, 245, 245, 0.9); /* Gris clair l\303\251g\303\250rement transparent pour le fond */\n"
"    color: rgba(40, 40, 40, 1); /* Couleur du texte */\n"
"    border: 2px solid rgba(200, 200, 200, 1); /* Bordure */\n"
"    border-radius: 10px; /* Bordure arrondie */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
"}\n"
"\n"
"#leftMenu:hover {\n"
"    background-color: rgba(230, 230, 230, 1); /* Gris clair pour le fond au survol */\n"
"    color: rgba(40, 40, 40, 1); /* Couleur du texte */\n"
"    border-color: rgba(180, 180, 180, 1); /* Bordure l\303\251g\303\250rement plus fonc\303\251e au survol */\n"
"}\n"
"\n"
"QLineEdit {\n"
"    background-color: rgba(245, 245, 245, 0.9); /* Gris clair l\303\251g\303\250rement transparent pour le fond */\n"
"    color: rgba(40, 40, 40, 1); /* Couleur du texte */\n"
"    border: 1px solid rgba(200, 200, 200, 1); /* Bordure */\n"
"    border-radius: 5px; /* Bordure arrondie */\n"
"    padding: 5px; /* Espacement int\303\251"
                        "rieur */\n"
"}\n"
"\n"
"QLabel {\n"
"    color: rgba(40, 40, 40, 1); /* Couleur du texte */\n"
"}\n"
""));
        horizontalLayout_61 = new QHBoxLayout(leftMenu);
        horizontalLayout_61->setObjectName(QString::fromUtf8("horizontalLayout_61"));
        splitter_10 = new QSplitter(leftMenu);
        splitter_10->setObjectName(QString::fromUtf8("splitter_10"));
        splitter_10->setMaximumSize(QSize(100, 54));
        splitter_10->setOrientation(Qt::Vertical);
        label_112 = new QLabel(splitter_10);
        label_112->setObjectName(QString::fromUtf8("label_112"));
        label_112->setMaximumSize(QSize(100, 20));
        splitter_10->addWidget(label_112);
        lineEdit_76 = new QLineEdit(splitter_10);
        lineEdit_76->setObjectName(QString::fromUtf8("lineEdit_76"));
        lineEdit_76->setMaximumSize(QSize(16777215, 30));
        splitter_10->addWidget(lineEdit_76);

        horizontalLayout_61->addWidget(splitter_10, 0, Qt::AlignTop);

        splitter_11 = new QSplitter(leftMenu);
        splitter_11->setObjectName(QString::fromUtf8("splitter_11"));
        splitter_11->setOrientation(Qt::Vertical);
        label_113 = new QLabel(splitter_11);
        label_113->setObjectName(QString::fromUtf8("label_113"));
        label_113->setMaximumSize(QSize(16777215, 20));
        splitter_11->addWidget(label_113);
        lineEdit_77 = new QLineEdit(splitter_11);
        lineEdit_77->setObjectName(QString::fromUtf8("lineEdit_77"));
        lineEdit_77->setMaximumSize(QSize(16777215, 30));
        splitter_11->addWidget(lineEdit_77);

        horizontalLayout_61->addWidget(splitter_11, 0, Qt::AlignTop);

        splitter_12 = new QSplitter(leftMenu);
        splitter_12->setObjectName(QString::fromUtf8("splitter_12"));
        splitter_12->setOrientation(Qt::Vertical);
        label_114 = new QLabel(splitter_12);
        label_114->setObjectName(QString::fromUtf8("label_114"));
        label_114->setMaximumSize(QSize(16777215, 20));
        splitter_12->addWidget(label_114);
        lineEdit_78 = new QLineEdit(splitter_12);
        lineEdit_78->setObjectName(QString::fromUtf8("lineEdit_78"));
        lineEdit_78->setMaximumSize(QSize(16777215, 30));
        splitter_12->addWidget(lineEdit_78);

        horizontalLayout_61->addWidget(splitter_12, 0, Qt::AlignTop);


        gridLayout_13->addWidget(leftMenu, 1, 0, 1, 1);

        label_111 = new QLabel(judiciaire);
        label_111->setObjectName(QString::fromUtf8("label_111"));
        label_111->setMaximumSize(QSize(500, 300));
        label_111->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 24px;\n"
"    font-weight: bold;\n"
"    color: rgba(51, 51, 51, 1);\n"
"}\n"
""));

        gridLayout_13->addWidget(label_111, 2, 0, 1, 1);

        leftMenu_2 = new QWidget(judiciaire);
        leftMenu_2->setObjectName(QString::fromUtf8("leftMenu_2"));
        leftMenu_2->setMaximumSize(QSize(16777215, 49999));
        leftMenu_2->setFont(font6);
        leftMenu_2->setStyleSheet(QString::fromUtf8("#leftMenu_2 {\n"
"    background-color: rgba(245, 245, 245, 0.9); /* Gris clair l\303\251g\303\250rement transparent pour le fond */\n"
"    color: rgba(40, 40, 40, 1); /* Couleur du texte */\n"
"    border: 2px solid rgba(200, 200, 200, 1); /* Bordure */\n"
"    border-radius: 10px; /* Bordure arrondie */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
"}\n"
"\n"
"#leftMenu_2:hover {\n"
"    background-color: rgba(230, 230, 230, 1); /* Gris clair pour le fond au survol */\n"
"    color: rgba(40, 40, 40, 1); /* Couleur du texte */\n"
"    border-color: rgba(180, 180, 180, 1); /* Bordure l\303\251g\303\250rement plus fonc\303\251e au survol */\n"
"}\n"
"\n"
"QLineEdit {\n"
"    background-color: rgba(245, 245, 245, 0.9); /* Gris clair l\303\251g\303\250rement transparent pour le fond */\n"
"    color: rgba(40, 40, 40, 1); /* Couleur du texte */\n"
"    border: 1px solid rgba(200, 200, 200, 1); /* Bordure */\n"
"    border-radius: 5px; /* Bordure arrondie */\n"
"    padding: 5px; /* Espacement int\303"
                        "\251rieur */\n"
"}\n"
"\n"
"QLabel {\n"
"    color: rgba(40, 40, 40, 1); /* Couleur du texte */\n"
"}\n"
""));
        horizontalLayout_51 = new QHBoxLayout(leftMenu_2);
        horizontalLayout_51->setObjectName(QString::fromUtf8("horizontalLayout_51"));
        splitter_7 = new QSplitter(leftMenu_2);
        splitter_7->setObjectName(QString::fromUtf8("splitter_7"));
        splitter_7->setMaximumSize(QSize(100, 54));
        splitter_7->setOrientation(Qt::Vertical);
        label_103 = new QLabel(splitter_7);
        label_103->setObjectName(QString::fromUtf8("label_103"));
        label_103->setMaximumSize(QSize(100, 20));
        splitter_7->addWidget(label_103);
        lineEdit_71 = new QLineEdit(splitter_7);
        lineEdit_71->setObjectName(QString::fromUtf8("lineEdit_71"));
        lineEdit_71->setMaximumSize(QSize(16777215, 30));
        splitter_7->addWidget(lineEdit_71);

        horizontalLayout_51->addWidget(splitter_7, 0, Qt::AlignTop);

        splitter_8 = new QSplitter(leftMenu_2);
        splitter_8->setObjectName(QString::fromUtf8("splitter_8"));
        splitter_8->setOrientation(Qt::Vertical);
        label_104 = new QLabel(splitter_8);
        label_104->setObjectName(QString::fromUtf8("label_104"));
        label_104->setMaximumSize(QSize(16777215, 20));
        splitter_8->addWidget(label_104);
        lineEdit_72 = new QLineEdit(splitter_8);
        lineEdit_72->setObjectName(QString::fromUtf8("lineEdit_72"));
        lineEdit_72->setMaximumSize(QSize(16777215, 30));
        splitter_8->addWidget(lineEdit_72);

        horizontalLayout_51->addWidget(splitter_8, 0, Qt::AlignTop);

        splitter_9 = new QSplitter(leftMenu_2);
        splitter_9->setObjectName(QString::fromUtf8("splitter_9"));
        splitter_9->setOrientation(Qt::Vertical);
        label_105 = new QLabel(splitter_9);
        label_105->setObjectName(QString::fromUtf8("label_105"));
        label_105->setMaximumSize(QSize(16777215, 20));
        splitter_9->addWidget(label_105);
        lineEdit_73 = new QLineEdit(splitter_9);
        lineEdit_73->setObjectName(QString::fromUtf8("lineEdit_73"));
        lineEdit_73->setMaximumSize(QSize(16777215, 30));
        splitter_9->addWidget(lineEdit_73);

        horizontalLayout_51->addWidget(splitter_9, 0, Qt::AlignTop);


        gridLayout_13->addWidget(leftMenu_2, 3, 0, 1, 1);

        widget_21 = new QWidget(judiciaire);
        widget_21->setObjectName(QString::fromUtf8("widget_21"));
        verticalLayout_37 = new QVBoxLayout(widget_21);
        verticalLayout_37->setObjectName(QString::fromUtf8("verticalLayout_37"));
        horizontalLayout_55 = new QHBoxLayout();
        horizontalLayout_55->setObjectName(QString::fromUtf8("horizontalLayout_55"));
        horizontalLayout_56 = new QHBoxLayout();
        horizontalLayout_56->setObjectName(QString::fromUtf8("horizontalLayout_56"));
        checkBox_30 = new QCheckBox(widget_21);
        checkBox_30->setObjectName(QString::fromUtf8("checkBox_30"));

        horizontalLayout_56->addWidget(checkBox_30);


        horizontalLayout_55->addLayout(horizontalLayout_56);

        horizontalLayout_57 = new QHBoxLayout();
        horizontalLayout_57->setObjectName(QString::fromUtf8("horizontalLayout_57"));
        label_109 = new QLabel(widget_21);
        label_109->setObjectName(QString::fromUtf8("label_109"));

        horizontalLayout_57->addWidget(label_109);

        textEdit_4 = new QTextEdit(widget_21);
        textEdit_4->setObjectName(QString::fromUtf8("textEdit_4"));
        textEdit_4->setMaximumSize(QSize(16777215, 60));

        horizontalLayout_57->addWidget(textEdit_4);


        horizontalLayout_55->addLayout(horizontalLayout_57);


        verticalLayout_37->addLayout(horizontalLayout_55);

        checkBox_31 = new QCheckBox(widget_21);
        checkBox_31->setObjectName(QString::fromUtf8("checkBox_31"));

        verticalLayout_37->addWidget(checkBox_31);

        horizontalLayout_58 = new QHBoxLayout();
        horizontalLayout_58->setObjectName(QString::fromUtf8("horizontalLayout_58"));
        horizontalLayout_59 = new QHBoxLayout();
        horizontalLayout_59->setObjectName(QString::fromUtf8("horizontalLayout_59"));
        checkBox_32 = new QCheckBox(widget_21);
        checkBox_32->setObjectName(QString::fromUtf8("checkBox_32"));

        horizontalLayout_59->addWidget(checkBox_32);


        horizontalLayout_58->addLayout(horizontalLayout_59);

        horizontalLayout_60 = new QHBoxLayout();
        horizontalLayout_60->setObjectName(QString::fromUtf8("horizontalLayout_60"));
        label_110 = new QLabel(widget_21);
        label_110->setObjectName(QString::fromUtf8("label_110"));

        horizontalLayout_60->addWidget(label_110);

        textEdit_5 = new QTextEdit(widget_21);
        textEdit_5->setObjectName(QString::fromUtf8("textEdit_5"));
        textEdit_5->setMaximumSize(QSize(16777215, 60));

        horizontalLayout_60->addWidget(textEdit_5);


        horizontalLayout_58->addLayout(horizontalLayout_60);


        verticalLayout_37->addLayout(horizontalLayout_58);


        gridLayout_13->addWidget(widget_21, 4, 0, 1, 1);

        barInfo->addTab(judiciaire, QString());
        activite = new QWidget();
        activite->setObjectName(QString::fromUtf8("activite"));
        gridLayout_2 = new QGridLayout(activite);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setVerticalSpacing(0);
        scrollArea_6 = new QScrollArea(activite);
        scrollArea_6->setObjectName(QString::fromUtf8("scrollArea_6"));
        scrollArea_6->setWidgetResizable(true);
        scrollAreaWidgetContents_10 = new QWidget();
        scrollAreaWidgetContents_10->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_10"));
        scrollAreaWidgetContents_10->setGeometry(QRect(0, 0, 735, 1452));
        verticalLayout_29 = new QVBoxLayout(scrollAreaWidgetContents_10);
        verticalLayout_29->setObjectName(QString::fromUtf8("verticalLayout_29"));
        widget_24 = new QWidget(scrollAreaWidgetContents_10);
        widget_24->setObjectName(QString::fromUtf8("widget_24"));
        widget_24->setMaximumSize(QSize(16777215, 50));
        horizontalLayout_32 = new QHBoxLayout(widget_24);
        horizontalLayout_32->setObjectName(QString::fromUtf8("horizontalLayout_32"));
        label_120 = new QLabel(widget_24);
        label_120->setObjectName(QString::fromUtf8("label_120"));

        horizontalLayout_32->addWidget(label_120);

        lineEdit_87 = new QLineEdit(widget_24);
        lineEdit_87->setObjectName(QString::fromUtf8("lineEdit_87"));
        lineEdit_87->setMaximumSize(QSize(16777215, 30));

        horizontalLayout_32->addWidget(lineEdit_87);

        lineEdit_88 = new QLineEdit(widget_24);
        lineEdit_88->setObjectName(QString::fromUtf8("lineEdit_88"));
        lineEdit_88->setMaximumSize(QSize(16777215, 30));

        horizontalLayout_32->addWidget(lineEdit_88);

        label_129 = new QLabel(widget_24);
        label_129->setObjectName(QString::fromUtf8("label_129"));

        horizontalLayout_32->addWidget(label_129);

        comboBox_10 = new QComboBox(widget_24);
        comboBox_10->setObjectName(QString::fromUtf8("comboBox_10"));
        comboBox_10->setMinimumSize(QSize(200, 30));
        comboBox_10->setMaximumSize(QSize(200, 16777215));

        horizontalLayout_32->addWidget(comboBox_10);


        verticalLayout_29->addWidget(widget_24);

        widget_26 = new QWidget(scrollAreaWidgetContents_10);
        widget_26->setObjectName(QString::fromUtf8("widget_26"));
        widget_26->setMinimumSize(QSize(0, 50));
        widget_26->setMaximumSize(QSize(16777215, 50));
        horizontalLayout_33 = new QHBoxLayout(widget_26);
        horizontalLayout_33->setObjectName(QString::fromUtf8("horizontalLayout_33"));
        pushButton_28 = new QPushButton(widget_26);
        pushButton_28->setObjectName(QString::fromUtf8("pushButton_28"));
        pushButton_28->setMinimumSize(QSize(0, 40));
        pushButton_28->setMaximumSize(QSize(100, 16777215));

        horizontalLayout_33->addWidget(pushButton_28);

        pushButton_29 = new QPushButton(widget_26);
        pushButton_29->setObjectName(QString::fromUtf8("pushButton_29"));
        pushButton_29->setMinimumSize(QSize(0, 40));
        pushButton_29->setMaximumSize(QSize(100, 16777215));

        horizontalLayout_33->addWidget(pushButton_29);

        pushButton_30 = new QPushButton(widget_26);
        pushButton_30->setObjectName(QString::fromUtf8("pushButton_30"));
        pushButton_30->setMinimumSize(QSize(0, 40));
        pushButton_30->setMaximumSize(QSize(100, 16777215));

        horizontalLayout_33->addWidget(pushButton_30);


        verticalLayout_29->addWidget(widget_26);

        scrollArea_7 = new QScrollArea(scrollAreaWidgetContents_10);
        scrollArea_7->setObjectName(QString::fromUtf8("scrollArea_7"));
        scrollArea_7->setMinimumSize(QSize(0, 300));
        scrollArea_7->setWidgetResizable(true);
        scrollAreaWidgetContents_11 = new QWidget();
        scrollAreaWidgetContents_11->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_11"));
        scrollAreaWidgetContents_11->setGeometry(QRect(0, 0, 701, 580));
        gridLayout_32 = new QGridLayout(scrollAreaWidgetContents_11);
        gridLayout_32->setObjectName(QString::fromUtf8("gridLayout_32"));
        scrollArea_8 = new QScrollArea(scrollAreaWidgetContents_11);
        scrollArea_8->setObjectName(QString::fromUtf8("scrollArea_8"));
        scrollArea_8->setMinimumSize(QSize(0, 300));
        scrollArea_8->setWidgetResizable(true);
        scrollAreaWidgetContents_12 = new QWidget();
        scrollAreaWidgetContents_12->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_12"));
        scrollAreaWidgetContents_12->setGeometry(QRect(0, 0, 667, 337));
        gridLayout_30 = new QGridLayout(scrollAreaWidgetContents_12);
        gridLayout_30->setObjectName(QString::fromUtf8("gridLayout_30"));
        groupBox_21 = new QGroupBox(scrollAreaWidgetContents_12);
        groupBox_21->setObjectName(QString::fromUtf8("groupBox_21"));
        verticalLayout_33 = new QVBoxLayout(groupBox_21);
        verticalLayout_33->setObjectName(QString::fromUtf8("verticalLayout_33"));
        label_130 = new QLabel(groupBox_21);
        label_130->setObjectName(QString::fromUtf8("label_130"));
        label_130->setMaximumSize(QSize(16777215, 40));
        QFont font7;
        font7.setPointSize(16);
        font7.setBold(true);
        label_130->setFont(font7);

        verticalLayout_33->addWidget(label_130);

        widget_28 = new QWidget(groupBox_21);
        widget_28->setObjectName(QString::fromUtf8("widget_28"));
        gridLayout_29 = new QGridLayout(widget_28);
        gridLayout_29->setSpacing(0);
        gridLayout_29->setObjectName(QString::fromUtf8("gridLayout_29"));
        gridLayout_29->setContentsMargins(0, 0, 0, 0);
        label_133 = new QLabel(widget_28);
        label_133->setObjectName(QString::fromUtf8("label_133"));
        label_133->setMaximumSize(QSize(150, 16777215));

        gridLayout_29->addWidget(label_133, 2, 0, 1, 1);

        checkBox_37 = new QCheckBox(widget_28);
        checkBox_37->setObjectName(QString::fromUtf8("checkBox_37"));
        checkBox_37->setMaximumSize(QSize(200, 16777215));

        gridLayout_29->addWidget(checkBox_37, 1, 0, 1, 1);

        lineEdit_89 = new QLineEdit(widget_28);
        lineEdit_89->setObjectName(QString::fromUtf8("lineEdit_89"));
        lineEdit_89->setMinimumSize(QSize(0, 30));
        lineEdit_89->setMaximumSize(QSize(400, 30));

        gridLayout_29->addWidget(lineEdit_89, 0, 2, 1, 1);

        lineEdit_96 = new QLineEdit(widget_28);
        lineEdit_96->setObjectName(QString::fromUtf8("lineEdit_96"));

        gridLayout_29->addWidget(lineEdit_96, 4, 1, 1, 1);

        lineEdit_100 = new QLineEdit(widget_28);
        lineEdit_100->setObjectName(QString::fromUtf8("lineEdit_100"));

        gridLayout_29->addWidget(lineEdit_100, 7, 2, 1, 1);

        lineEdit_103 = new QLineEdit(widget_28);
        lineEdit_103->setObjectName(QString::fromUtf8("lineEdit_103"));

        gridLayout_29->addWidget(lineEdit_103, 6, 2, 1, 1);

        lineEdit_104 = new QLineEdit(widget_28);
        lineEdit_104->setObjectName(QString::fromUtf8("lineEdit_104"));

        gridLayout_29->addWidget(lineEdit_104, 5, 0, 1, 1);

        lineEdit_92 = new QLineEdit(widget_28);
        lineEdit_92->setObjectName(QString::fromUtf8("lineEdit_92"));

        gridLayout_29->addWidget(lineEdit_92, 8, 0, 1, 1);

        lineEdit_95 = new QLineEdit(widget_28);
        lineEdit_95->setObjectName(QString::fromUtf8("lineEdit_95"));

        gridLayout_29->addWidget(lineEdit_95, 4, 0, 1, 1);

        label_132 = new QLabel(widget_28);
        label_132->setObjectName(QString::fromUtf8("label_132"));
        label_132->setMaximumSize(QSize(100, 16777215));

        gridLayout_29->addWidget(label_132, 1, 1, 1, 1);

        lineEdit_90 = new QLineEdit(widget_28);
        lineEdit_90->setObjectName(QString::fromUtf8("lineEdit_90"));
        lineEdit_90->setMinimumSize(QSize(0, 30));
        lineEdit_90->setMaximumSize(QSize(400, 30));

        gridLayout_29->addWidget(lineEdit_90, 1, 2, 1, 1);

        lineEdit_105 = new QLineEdit(widget_28);
        lineEdit_105->setObjectName(QString::fromUtf8("lineEdit_105"));

        gridLayout_29->addWidget(lineEdit_105, 5, 1, 1, 1);

        checkBox_36 = new QCheckBox(widget_28);
        checkBox_36->setObjectName(QString::fromUtf8("checkBox_36"));
        checkBox_36->setMaximumSize(QSize(200, 16777215));

        gridLayout_29->addWidget(checkBox_36, 0, 0, 1, 1);

        label_131 = new QLabel(widget_28);
        label_131->setObjectName(QString::fromUtf8("label_131"));
        label_131->setMaximumSize(QSize(100, 16777215));

        gridLayout_29->addWidget(label_131, 0, 1, 1, 1);

        lineEdit_99 = new QLineEdit(widget_28);
        lineEdit_99->setObjectName(QString::fromUtf8("lineEdit_99"));

        gridLayout_29->addWidget(lineEdit_99, 7, 1, 1, 1);

        lineEdit_102 = new QLineEdit(widget_28);
        lineEdit_102->setObjectName(QString::fromUtf8("lineEdit_102"));

        gridLayout_29->addWidget(lineEdit_102, 6, 1, 1, 1);

        lineEdit_93 = new QLineEdit(widget_28);
        lineEdit_93->setObjectName(QString::fromUtf8("lineEdit_93"));

        gridLayout_29->addWidget(lineEdit_93, 8, 1, 1, 1);

        lineEdit_101 = new QLineEdit(widget_28);
        lineEdit_101->setObjectName(QString::fromUtf8("lineEdit_101"));

        gridLayout_29->addWidget(lineEdit_101, 6, 0, 1, 1);

        lineEdit_98 = new QLineEdit(widget_28);
        lineEdit_98->setObjectName(QString::fromUtf8("lineEdit_98"));

        gridLayout_29->addWidget(lineEdit_98, 7, 0, 1, 1);

        lineEdit_94 = new QLineEdit(widget_28);
        lineEdit_94->setObjectName(QString::fromUtf8("lineEdit_94"));

        gridLayout_29->addWidget(lineEdit_94, 8, 2, 1, 1);

        lineEdit_106 = new QLineEdit(widget_28);
        lineEdit_106->setObjectName(QString::fromUtf8("lineEdit_106"));

        gridLayout_29->addWidget(lineEdit_106, 5, 2, 1, 1);

        lineEdit_97 = new QLineEdit(widget_28);
        lineEdit_97->setObjectName(QString::fromUtf8("lineEdit_97"));

        gridLayout_29->addWidget(lineEdit_97, 4, 2, 1, 1);

        label_134 = new QLabel(widget_28);
        label_134->setObjectName(QString::fromUtf8("label_134"));
        label_134->setMinimumSize(QSize(0, 30));
        label_134->setMaximumSize(QSize(16777215, 30));
        QFont font8;
        font8.setPointSize(13);
        label_134->setFont(font8);

        gridLayout_29->addWidget(label_134, 3, 0, 1, 1);

        lineEdit_91 = new QLineEdit(widget_28);
        lineEdit_91->setObjectName(QString::fromUtf8("lineEdit_91"));
        lineEdit_91->setMinimumSize(QSize(0, 30));
        lineEdit_91->setMaximumSize(QSize(400, 30));

        gridLayout_29->addWidget(lineEdit_91, 2, 1, 1, 1);

        label_135 = new QLabel(widget_28);
        label_135->setObjectName(QString::fromUtf8("label_135"));
        label_135->setMinimumSize(QSize(0, 30));
        label_135->setMaximumSize(QSize(16777215, 30));
        label_135->setFont(font8);

        gridLayout_29->addWidget(label_135, 3, 1, 1, 1);

        label_136 = new QLabel(widget_28);
        label_136->setObjectName(QString::fromUtf8("label_136"));
        label_136->setFont(font8);

        gridLayout_29->addWidget(label_136, 3, 2, 1, 1);


        verticalLayout_33->addWidget(widget_28);


        gridLayout_30->addWidget(groupBox_21, 0, 0, 1, 1);

        scrollArea_8->setWidget(scrollAreaWidgetContents_12);

        gridLayout_32->addWidget(scrollArea_8, 1, 0, 1, 1);

        widget_29 = new QWidget(scrollAreaWidgetContents_11);
        widget_29->setObjectName(QString::fromUtf8("widget_29"));
        widget_29->setMinimumSize(QSize(0, 200));
        gridLayout_33 = new QGridLayout(widget_29);
        gridLayout_33->setObjectName(QString::fromUtf8("gridLayout_33"));
        label_140 = new QLabel(widget_29);
        label_140->setObjectName(QString::fromUtf8("label_140"));

        gridLayout_33->addWidget(label_140, 2, 1, 1, 1);

        dateEdit_11 = new QDateEdit(widget_29);
        dateEdit_11->setObjectName(QString::fromUtf8("dateEdit_11"));

        gridLayout_33->addWidget(dateEdit_11, 1, 2, 1, 1);

        label_137 = new QLabel(widget_29);
        label_137->setObjectName(QString::fromUtf8("label_137"));

        gridLayout_33->addWidget(label_137, 0, 1, 1, 1);

        checkBox_38 = new QCheckBox(widget_29);
        checkBox_38->setObjectName(QString::fromUtf8("checkBox_38"));

        gridLayout_33->addWidget(checkBox_38, 0, 0, 1, 1);

        label_138 = new QLabel(widget_29);
        label_138->setObjectName(QString::fromUtf8("label_138"));

        gridLayout_33->addWidget(label_138, 1, 0, 1, 1);

        lineEdit_108 = new QLineEdit(widget_29);
        lineEdit_108->setObjectName(QString::fromUtf8("lineEdit_108"));
        lineEdit_108->setMinimumSize(QSize(0, 30));
        lineEdit_108->setMaximumSize(QSize(16777215, 30));

        gridLayout_33->addWidget(lineEdit_108, 2, 2, 1, 1);

        lineEdit_107 = new QLineEdit(widget_29);
        lineEdit_107->setObjectName(QString::fromUtf8("lineEdit_107"));
        lineEdit_107->setMinimumSize(QSize(0, 30));
        lineEdit_107->setMaximumSize(QSize(16777215, 30));

        gridLayout_33->addWidget(lineEdit_107, 2, 0, 1, 1);

        label_139 = new QLabel(widget_29);
        label_139->setObjectName(QString::fromUtf8("label_139"));

        gridLayout_33->addWidget(label_139, 1, 1, 1, 1);

        lineEdit_162 = new QLineEdit(widget_29);
        lineEdit_162->setObjectName(QString::fromUtf8("lineEdit_162"));
        lineEdit_162->setMinimumSize(QSize(0, 30));

        gridLayout_33->addWidget(lineEdit_162, 3, 2, 1, 1);

        label_141 = new QLabel(widget_29);
        label_141->setObjectName(QString::fromUtf8("label_141"));

        gridLayout_33->addWidget(label_141, 3, 1, 1, 1);


        gridLayout_32->addWidget(widget_29, 2, 0, 1, 1);

        widget_27 = new QWidget(scrollAreaWidgetContents_11);
        widget_27->setObjectName(QString::fromUtf8("widget_27"));
        widget_27->setMinimumSize(QSize(0, 50));
        widget_27->setMaximumSize(QSize(16777215, 40));
        horizontalLayout_34 = new QHBoxLayout(widget_27);
        horizontalLayout_34->setObjectName(QString::fromUtf8("horizontalLayout_34"));
        pushButton_31 = new QPushButton(widget_27);
        pushButton_31->setObjectName(QString::fromUtf8("pushButton_31"));
        pushButton_31->setMinimumSize(QSize(0, 40));
        pushButton_31->setMaximumSize(QSize(16777215, 40));

        horizontalLayout_34->addWidget(pushButton_31);

        pushButton_32 = new QPushButton(widget_27);
        pushButton_32->setObjectName(QString::fromUtf8("pushButton_32"));
        pushButton_32->setMinimumSize(QSize(0, 40));
        pushButton_32->setMaximumSize(QSize(16777215, 40));

        horizontalLayout_34->addWidget(pushButton_32);

        pushButton_33 = new QPushButton(widget_27);
        pushButton_33->setObjectName(QString::fromUtf8("pushButton_33"));
        pushButton_33->setMinimumSize(QSize(0, 40));
        pushButton_33->setMaximumSize(QSize(16777215, 40));

        horizontalLayout_34->addWidget(pushButton_33);

        pushButton_34 = new QPushButton(widget_27);
        pushButton_34->setObjectName(QString::fromUtf8("pushButton_34"));
        pushButton_34->setMinimumSize(QSize(0, 40));
        pushButton_34->setMaximumSize(QSize(16777215, 40));

        horizontalLayout_34->addWidget(pushButton_34);


        gridLayout_32->addWidget(widget_27, 0, 0, 1, 1);

        scrollArea_7->setWidget(scrollAreaWidgetContents_11);

        verticalLayout_29->addWidget(scrollArea_7);

        groupBox_22 = new QGroupBox(scrollAreaWidgetContents_10);
        groupBox_22->setObjectName(QString::fromUtf8("groupBox_22"));
        groupBox_22->setMinimumSize(QSize(0, 300));
        groupBox_22->setFont(font7);
        groupBox_22->setStyleSheet(QString::fromUtf8("color: black;\n"
"QCheckBox{	\n"
"	font: 11pt \"Ubuntu\";\n"
"}"));
        gridLayout_47 = new QGridLayout(groupBox_22);
        gridLayout_47->setObjectName(QString::fromUtf8("gridLayout_47"));
        label_143 = new QLabel(groupBox_22);
        label_143->setObjectName(QString::fromUtf8("label_143"));
        label_143->setMinimumSize(QSize(0, 40));
        label_143->setMaximumSize(QSize(16777215, 40));

        gridLayout_47->addWidget(label_143, 1, 3, 1, 1);

        checkBox_41 = new QCheckBox(groupBox_22);
        checkBox_41->setObjectName(QString::fromUtf8("checkBox_41"));

        gridLayout_47->addWidget(checkBox_41, 0, 3, 1, 1);

        label_142 = new QLabel(groupBox_22);
        label_142->setObjectName(QString::fromUtf8("label_142"));
        label_142->setMaximumSize(QSize(16777215, 30));

        gridLayout_47->addWidget(label_142, 1, 0, 1, 1);

        checkBox_46 = new QCheckBox(groupBox_22);
        checkBox_46->setObjectName(QString::fromUtf8("checkBox_46"));

        gridLayout_47->addWidget(checkBox_46, 3, 2, 1, 1);

        lineEdit_164 = new QLineEdit(groupBox_22);
        lineEdit_164->setObjectName(QString::fromUtf8("lineEdit_164"));
        lineEdit_164->setMinimumSize(QSize(0, 30));
        lineEdit_164->setMaximumSize(QSize(16777215, 30));

        gridLayout_47->addWidget(lineEdit_164, 5, 3, 1, 2);

        label_146 = new QLabel(groupBox_22);
        label_146->setObjectName(QString::fromUtf8("label_146"));

        gridLayout_47->addWidget(label_146, 6, 2, 1, 1);

        label_144 = new QLabel(groupBox_22);
        label_144->setObjectName(QString::fromUtf8("label_144"));

        gridLayout_47->addWidget(label_144, 4, 2, 1, 1);

        checkBox_42 = new QCheckBox(groupBox_22);
        checkBox_42->setObjectName(QString::fromUtf8("checkBox_42"));

        gridLayout_47->addWidget(checkBox_42, 0, 0, 1, 1);

        checkBox_43 = new QCheckBox(groupBox_22);
        checkBox_43->setObjectName(QString::fromUtf8("checkBox_43"));

        gridLayout_47->addWidget(checkBox_43, 2, 1, 1, 1);

        checkBox_47 = new QCheckBox(groupBox_22);
        checkBox_47->setObjectName(QString::fromUtf8("checkBox_47"));

        gridLayout_47->addWidget(checkBox_47, 4, 0, 1, 1);

        checkBox_44 = new QCheckBox(groupBox_22);
        checkBox_44->setObjectName(QString::fromUtf8("checkBox_44"));

        gridLayout_47->addWidget(checkBox_44, 2, 2, 1, 1);

        checkBox_40 = new QCheckBox(groupBox_22);
        checkBox_40->setObjectName(QString::fromUtf8("checkBox_40"));

        gridLayout_47->addWidget(checkBox_40, 0, 2, 1, 1);

        checkBox_39 = new QCheckBox(groupBox_22);
        checkBox_39->setObjectName(QString::fromUtf8("checkBox_39"));

        gridLayout_47->addWidget(checkBox_39, 0, 1, 1, 1);

        label_145 = new QLabel(groupBox_22);
        label_145->setObjectName(QString::fromUtf8("label_145"));

        gridLayout_47->addWidget(label_145, 5, 2, 1, 1);

        checkBox_48 = new QCheckBox(groupBox_22);
        checkBox_48->setObjectName(QString::fromUtf8("checkBox_48"));

        gridLayout_47->addWidget(checkBox_48, 5, 0, 1, 1);

        lineEdit_163 = new QLineEdit(groupBox_22);
        lineEdit_163->setObjectName(QString::fromUtf8("lineEdit_163"));
        lineEdit_163->setMinimumSize(QSize(0, 30));
        lineEdit_163->setMaximumSize(QSize(16777215, 30));

        gridLayout_47->addWidget(lineEdit_163, 6, 3, 1, 2);

        checkBox_45 = new QCheckBox(groupBox_22);
        checkBox_45->setObjectName(QString::fromUtf8("checkBox_45"));

        gridLayout_47->addWidget(checkBox_45, 3, 1, 1, 1);

        textEdit_2 = new QTextEdit(groupBox_22);
        textEdit_2->setObjectName(QString::fromUtf8("textEdit_2"));
        textEdit_2->setMinimumSize(QSize(100, 100));
        textEdit_2->setMaximumSize(QSize(16777215, 40));

        gridLayout_47->addWidget(textEdit_2, 1, 4, 1, 1);


        verticalLayout_29->addWidget(groupBox_22);

        groupBox_23 = new QGroupBox(scrollAreaWidgetContents_10);
        groupBox_23->setObjectName(QString::fromUtf8("groupBox_23"));
        groupBox_23->setMinimumSize(QSize(0, 400));
        groupBox_23->setFont(font7);
        groupBox_23->setStyleSheet(QString::fromUtf8("color: black;\n"
"QCheckBox{	\n"
"	font: 11pt \"Ubuntu\";\n"
"}"));
        gridLayout_49 = new QGridLayout(groupBox_23);
        gridLayout_49->setObjectName(QString::fromUtf8("gridLayout_49"));
        label_154 = new QLabel(groupBox_23);
        label_154->setObjectName(QString::fromUtf8("label_154"));

        gridLayout_49->addWidget(label_154, 3, 4, 1, 1);

        checkBox_54 = new QCheckBox(groupBox_23);
        checkBox_54->setObjectName(QString::fromUtf8("checkBox_54"));
        checkBox_54->setMinimumSize(QSize(100, 0));
        checkBox_54->setMaximumSize(QSize(100, 16777215));

        gridLayout_49->addWidget(checkBox_54, 2, 1, 1, 1);

        checkBox_59 = new QCheckBox(groupBox_23);
        checkBox_59->setObjectName(QString::fromUtf8("checkBox_59"));

        gridLayout_49->addWidget(checkBox_59, 8, 0, 1, 1);

        lineEdit_171 = new QLineEdit(groupBox_23);
        lineEdit_171->setObjectName(QString::fromUtf8("lineEdit_171"));
        lineEdit_171->setMinimumSize(QSize(0, 30));
        lineEdit_171->setMaximumSize(QSize(16777215, 30));

        gridLayout_49->addWidget(lineEdit_171, 4, 6, 1, 1);

        label_153 = new QLabel(groupBox_23);
        label_153->setObjectName(QString::fromUtf8("label_153"));

        gridLayout_49->addWidget(label_153, 1, 4, 1, 1);

        checkBox_55 = new QCheckBox(groupBox_23);
        checkBox_55->setObjectName(QString::fromUtf8("checkBox_55"));
        checkBox_55->setMaximumSize(QSize(100, 16777215));

        gridLayout_49->addWidget(checkBox_55, 1, 2, 1, 1);

        lineEdit_168 = new QLineEdit(groupBox_23);
        lineEdit_168->setObjectName(QString::fromUtf8("lineEdit_168"));
        lineEdit_168->setMinimumSize(QSize(0, 30));
        lineEdit_168->setMaximumSize(QSize(16777215, 30));

        gridLayout_49->addWidget(lineEdit_168, 1, 6, 1, 1);

        checkBox_53 = new QCheckBox(groupBox_23);
        checkBox_53->setObjectName(QString::fromUtf8("checkBox_53"));

        gridLayout_49->addWidget(checkBox_53, 3, 1, 1, 1);

        lineEdit_170 = new QLineEdit(groupBox_23);
        lineEdit_170->setObjectName(QString::fromUtf8("lineEdit_170"));
        lineEdit_170->setMinimumSize(QSize(0, 30));
        lineEdit_170->setMaximumSize(QSize(16777215, 30));

        gridLayout_49->addWidget(lineEdit_170, 5, 6, 1, 1);

        checkBox_57 = new QCheckBox(groupBox_23);
        checkBox_57->setObjectName(QString::fromUtf8("checkBox_57"));

        gridLayout_49->addWidget(checkBox_57, 4, 0, 1, 1);

        horizontalSpacer_5 = new QSpacerItem(30, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_49->addItem(horizontalSpacer_5, 1, 3, 1, 1);

        checkBox_60 = new QCheckBox(groupBox_23);
        checkBox_60->setObjectName(QString::fromUtf8("checkBox_60"));

        gridLayout_49->addWidget(checkBox_60, 7, 0, 1, 1);

        checkBox_52 = new QCheckBox(groupBox_23);
        checkBox_52->setObjectName(QString::fromUtf8("checkBox_52"));
        checkBox_52->setMinimumSize(QSize(100, 0));
        checkBox_52->setMaximumSize(QSize(100, 16777215));

        gridLayout_49->addWidget(checkBox_52, 1, 1, 1, 1);

        label_157 = new QLabel(groupBox_23);
        label_157->setObjectName(QString::fromUtf8("label_157"));

        gridLayout_49->addWidget(label_157, 5, 4, 1, 1);

        checkBox_58 = new QCheckBox(groupBox_23);
        checkBox_58->setObjectName(QString::fromUtf8("checkBox_58"));

        gridLayout_49->addWidget(checkBox_58, 5, 0, 1, 1);

        checkBox_56 = new QCheckBox(groupBox_23);
        checkBox_56->setObjectName(QString::fromUtf8("checkBox_56"));
        checkBox_56->setMaximumSize(QSize(100, 16777215));

        gridLayout_49->addWidget(checkBox_56, 2, 2, 1, 1);

        label_155 = new QLabel(groupBox_23);
        label_155->setObjectName(QString::fromUtf8("label_155"));

        gridLayout_49->addWidget(label_155, 4, 4, 1, 1);

        label_152 = new QLabel(groupBox_23);
        label_152->setObjectName(QString::fromUtf8("label_152"));
        label_152->setMaximumSize(QSize(16777215, 23));
        QFont font9;
        font9.setPointSize(14);
        font9.setBold(true);
        font9.setUnderline(true);
        font9.setStrikeOut(false);
        label_152->setFont(font9);

        gridLayout_49->addWidget(label_152, 0, 0, 1, 1, Qt::AlignHCenter);

        checkBox_61 = new QCheckBox(groupBox_23);
        checkBox_61->setObjectName(QString::fromUtf8("checkBox_61"));

        gridLayout_49->addWidget(checkBox_61, 6, 0, 1, 1);

        label_156 = new QLabel(groupBox_23);
        label_156->setObjectName(QString::fromUtf8("label_156"));

        gridLayout_49->addWidget(label_156, 6, 4, 1, 1);

        lineEdit_169 = new QLineEdit(groupBox_23);
        lineEdit_169->setObjectName(QString::fromUtf8("lineEdit_169"));
        lineEdit_169->setMinimumSize(QSize(0, 30));
        lineEdit_169->setMaximumSize(QSize(16777215, 30));

        gridLayout_49->addWidget(lineEdit_169, 6, 6, 1, 1);


        verticalLayout_29->addWidget(groupBox_23);

        groupBox_25 = new QGroupBox(scrollAreaWidgetContents_10);
        groupBox_25->setObjectName(QString::fromUtf8("groupBox_25"));
        groupBox_25->setMinimumSize(QSize(0, 200));
        groupBox_25->setFont(font7);
        groupBox_25->setStyleSheet(QString::fromUtf8("color: black;\n"
"QCheckBox{	\n"
"	font: 11pt \"Ubuntu\";\n"
"}"));
        gridLayout_48 = new QGridLayout(groupBox_25);
        gridLayout_48->setObjectName(QString::fromUtf8("gridLayout_48"));
        label_148 = new QLabel(groupBox_25);
        label_148->setObjectName(QString::fromUtf8("label_148"));

        gridLayout_48->addWidget(label_148, 1, 1, 1, 1);

        lineEdit_166 = new QLineEdit(groupBox_25);
        lineEdit_166->setObjectName(QString::fromUtf8("lineEdit_166"));
        lineEdit_166->setMinimumSize(QSize(0, 30));
        lineEdit_166->setMaximumSize(QSize(500, 30));

        gridLayout_48->addWidget(lineEdit_166, 3, 2, 1, 1);

        label_149 = new QLabel(groupBox_25);
        label_149->setObjectName(QString::fromUtf8("label_149"));

        gridLayout_48->addWidget(label_149, 2, 1, 1, 1);

        checkBox_51 = new QCheckBox(groupBox_25);
        checkBox_51->setObjectName(QString::fromUtf8("checkBox_51"));
        checkBox_51->setMaximumSize(QSize(200, 16777215));

        gridLayout_48->addWidget(checkBox_51, 0, 0, 1, 1);

        lineEdit_167 = new QLineEdit(groupBox_25);
        lineEdit_167->setObjectName(QString::fromUtf8("lineEdit_167"));
        lineEdit_167->setMinimumSize(QSize(0, 30));
        lineEdit_167->setMaximumSize(QSize(500, 30));

        gridLayout_48->addWidget(lineEdit_167, 4, 2, 1, 1);

        label_151 = new QLabel(groupBox_25);
        label_151->setObjectName(QString::fromUtf8("label_151"));

        gridLayout_48->addWidget(label_151, 4, 1, 1, 1);

        dateEdit_12 = new QDateEdit(groupBox_25);
        dateEdit_12->setObjectName(QString::fromUtf8("dateEdit_12"));
        dateEdit_12->setMinimumSize(QSize(0, 30));
        dateEdit_12->setMaximumSize(QSize(500, 30));

        gridLayout_48->addWidget(dateEdit_12, 2, 2, 1, 1);

        label_150 = new QLabel(groupBox_25);
        label_150->setObjectName(QString::fromUtf8("label_150"));

        gridLayout_48->addWidget(label_150, 3, 1, 1, 1);

        label_147 = new QLabel(groupBox_25);
        label_147->setObjectName(QString::fromUtf8("label_147"));
        label_147->setMaximumSize(QSize(100, 16777215));

        gridLayout_48->addWidget(label_147, 0, 1, 1, 1);

        lineEdit_165 = new QLineEdit(groupBox_25);
        lineEdit_165->setObjectName(QString::fromUtf8("lineEdit_165"));
        lineEdit_165->setMinimumSize(QSize(0, 30));
        lineEdit_165->setMaximumSize(QSize(500, 30));

        gridLayout_48->addWidget(lineEdit_165, 0, 2, 1, 1);


        verticalLayout_29->addWidget(groupBox_25);

        groupBox_24 = new QGroupBox(scrollAreaWidgetContents_10);
        groupBox_24->setObjectName(QString::fromUtf8("groupBox_24"));
        groupBox_24->setMinimumSize(QSize(0, 100));
        groupBox_24->setFont(font7);
        groupBox_24->setStyleSheet(QString::fromUtf8("color: black;\n"
"QCheckBox{	\n"
"	font: 11pt \"Ubuntu\";\n"
"}"));
        verticalLayout_32 = new QVBoxLayout(groupBox_24);
        verticalLayout_32->setObjectName(QString::fromUtf8("verticalLayout_32"));
        checkBox_50 = new QCheckBox(groupBox_24);
        checkBox_50->setObjectName(QString::fromUtf8("checkBox_50"));
        checkBox_50->setMinimumSize(QSize(0, 30));
        checkBox_50->setMaximumSize(QSize(16777215, 30));

        verticalLayout_32->addWidget(checkBox_50);

        checkBox_49 = new QCheckBox(groupBox_24);
        checkBox_49->setObjectName(QString::fromUtf8("checkBox_49"));
        checkBox_49->setMinimumSize(QSize(0, 30));
        checkBox_49->setMaximumSize(QSize(16777215, 30));

        verticalLayout_32->addWidget(checkBox_49);


        verticalLayout_29->addWidget(groupBox_24);

        scrollArea_6->setWidget(scrollAreaWidgetContents_10);

        gridLayout_2->addWidget(scrollArea_6, 0, 0, 1, 1);

        barInfo->addTab(activite, QString());
        assurance = new QWidget();
        assurance->setObjectName(QString::fromUtf8("assurance"));
        gridLayout_4 = new QGridLayout(assurance);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        horizontalLayout_44 = new QHBoxLayout();
        horizontalLayout_44->setSpacing(6);
        horizontalLayout_44->setObjectName(QString::fromUtf8("horizontalLayout_44"));
        horizontalLayout_45 = new QHBoxLayout();
        horizontalLayout_45->setObjectName(QString::fromUtf8("horizontalLayout_45"));
        label_97 = new QLabel(assurance);
        label_97->setObjectName(QString::fromUtf8("label_97"));
        label_97->setStyleSheet(QString::fromUtf8("QLabel{\n"
"    background-color: rgba(100, 149, 237, 0.7); /* Couleur de fond avec transparence */\n"
"    color: white; /* Couleur du texte */\n"
"    font-size: 16px; /* Taille de la police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border-radius: 5px; /* Bordure arrondie */\n"
"    padding: 5px 10px; /* Espacement int\303\251rieur */\n"
"}\n"
""));

        horizontalLayout_45->addWidget(label_97);

        lineEdit_66 = new QLineEdit(assurance);
        lineEdit_66->setObjectName(QString::fromUtf8("lineEdit_66"));

        horizontalLayout_45->addWidget(lineEdit_66);


        horizontalLayout_44->addLayout(horizontalLayout_45);

        horizontalLayout_46 = new QHBoxLayout();
        horizontalLayout_46->setObjectName(QString::fromUtf8("horizontalLayout_46"));
        label_98 = new QLabel(assurance);
        label_98->setObjectName(QString::fromUtf8("label_98"));
        label_98->setStyleSheet(QString::fromUtf8("QLabel{\n"
"    background-color: rgba(100, 149, 237, 0.7); /* Couleur de fond avec transparence */\n"
"    color: white; /* Couleur du texte */\n"
"    font-size: 16px; /* Taille de la police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border-radius: 5px; /* Bordure arrondie */\n"
"    padding: 5px 10px; /* Espacement int\303\251rieur */\n"
"}\n"
""));

        horizontalLayout_46->addWidget(label_98);

        lineEdit_67 = new QLineEdit(assurance);
        lineEdit_67->setObjectName(QString::fromUtf8("lineEdit_67"));

        horizontalLayout_46->addWidget(lineEdit_67);


        horizontalLayout_44->addLayout(horizontalLayout_46);


        gridLayout_4->addLayout(horizontalLayout_44, 0, 0, 1, 1);

        frame_46 = new QFrame(assurance);
        frame_46->setObjectName(QString::fromUtf8("frame_46"));
        frame_46->setStyleSheet(QString::fromUtf8("QFrame{\n"
"	 padding: 10px 15px; /* Espacement int\303\251rieur */\n"
"    border-radius: 8px; /* Bordure arrondie */\n"
"    border: 2px solid rgba(52, 152, 219, 1); /* Bordure solide (bleu) */\n"
"}\n"
"QLabel {\n"
"    font-size: 16px; /* Taille de la police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: rgba(44, 62, 80, 1); /* Couleur du texte (noir) */\n"
"    background-color: rgba(236, 240, 241, 1); /* Couleur de fond (gris clair) */\n"
"  	 padding: 10px 15px; /* Espacement int\303\251rieur */\n"
"    border-radius: 8px; /* Bordure arrondie */\n"
"    border: 2px solid rgba(52, 152, 219, 1); /* Bordure solide (bleu) */\n"
"}\n"
"\n"
"QCheckBox{\n"
"    color: rgba(44, 62, 80, 1); /* Couleur du texte */\n"
"    background-color: rgba(236, 240, 241, 1); /*Couleur de fond */\n"
"    padding: 5px; /* Espacement int\303\251rieur */\n"
"    border-radius: 5px; /* Bordure arrondie */\n"
"    border: 2px solid rgba(52, 152, 219, 1); /* Bordure solide */\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
""
                        "    width: 20px; /* Largeur de l'indicateur */\n"
"    height: 20px; /* Hauteur de l'indicateur */\n"
"    border: 2px solid rgba(52, 152, 219, 1); /* Bordure de l'indicateur */\n"
"    border-radius: 5px; /* Bordure arrondie de l'indicateur */\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: rgba(52, 152, 219, 1); /* Couleur de fond de l'indicateur lorsqu'il est coch\303\251 */\n"
"}\n"
"\n"
"QCheckBox:hover {\n"
"    background-color: rgba(52, 152, 219, 0.1); /* Changement de couleur de fond au survol */\n"
"}\n"
"\n"
"\n"
""));
        horizontalLayout_43 = new QHBoxLayout(frame_46);
        horizontalLayout_43->setObjectName(QString::fromUtf8("horizontalLayout_43"));
        label_96 = new QLabel(frame_46);
        label_96->setObjectName(QString::fromUtf8("label_96"));

        horizontalLayout_43->addWidget(label_96);

        checkBox_26 = new QCheckBox(frame_46);
        checkBox_26->setObjectName(QString::fromUtf8("checkBox_26"));

        horizontalLayout_43->addWidget(checkBox_26);

        checkBox_27 = new QCheckBox(frame_46);
        checkBox_27->setObjectName(QString::fromUtf8("checkBox_27"));

        horizontalLayout_43->addWidget(checkBox_27);


        gridLayout_4->addWidget(frame_46, 1, 0, 1, 1);

        leftMenu3 = new QWidget(assurance);
        leftMenu3->setObjectName(QString::fromUtf8("leftMenu3"));
        leftMenu3->setMaximumSize(QSize(16777215, 2000));
        leftMenu3->setFont(font6);
        leftMenu3->setStyleSheet(QString::fromUtf8("#leftMenu3 {\n"
"    background-color: rgba(245, 245, 245, 0.9); /* Gris clair l\303\251g\303\250rement transparent pour le fond */\n"
"    color: rgba(40, 40, 40, 1); /* Couleur du texte */\n"
"    border: 2px solid rgba(200, 200, 200, 1); /* Bordure */\n"
"    border-radius: 10px; /* Bordure arrondie */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
"}\n"
"\n"
"#leftMenu3:hover {\n"
"    background-color: rgba(230, 230, 230, 1); /* Gris clair pour le fond au survol */\n"
"    color: rgba(40, 40, 40, 1); /* Couleur du texte */\n"
"    border-color: rgba(180, 180, 180, 1); /* Bordure l\303\251g\303\250rement plus fonc\303\251e au survol */\n"
"}\n"
"\n"
"QLineEdit {\n"
"    background-color: rgba(245, 245, 245, 0.9); /* Gris clair l\303\251g\303\250rement transparent pour le fond */\n"
"    color: rgba(40, 40, 40, 1); /* Couleur du texte */\n"
"    border: 1px solid rgba(200, 200, 200, 1); /* Bordure */\n"
"    border-radius: 5px; /* Bordure arrondie */\n"
"    padding: 5px; /* Espacement int\303\251"
                        "rieur */\n"
"}\n"
"\n"
"QCheckBox {\n"
"    color: rgba(44, 62, 80, 1); /* Couleur du texte */\n"
"    background-color: rgba(236, 240, 241, 1); /* Couleur de fond */\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 20px; /* Largeur de l'indicateur */\n"
"    height: 20px; /* Hauteur de l'indicateur */\n"
"    border: 2px solid rgba(52, 152, 219, 1); /* Bordure de l'indicateur */\n"
"    border-radius: 5px; /* Bordure arrondie de l'indicateur */\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: rgba(52, 152, 219, 1); /* Couleur de fond de l'indicateur lorsqu'il est coch\303\251 */\n"
"}\n"
"\n"
"QCheckBox:hover {\n"
"    background-color: rgba(52, 152, 219, 0.1); /* Changement de couleur de fond au survol */\n"
"}\n"
"\n"
""));
        horizontalLayout_47 = new QHBoxLayout(leftMenu3);
        horizontalLayout_47->setObjectName(QString::fromUtf8("horizontalLayout_47"));
        verticalLayout_34 = new QVBoxLayout();
        verticalLayout_34->setObjectName(QString::fromUtf8("verticalLayout_34"));
        label_99 = new QLabel(leftMenu3);
        label_99->setObjectName(QString::fromUtf8("label_99"));
        label_99->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    color: rgba(44, 62, 80, 1); /* Couleur du texte */\n"
"    background-color: rgba(236, 240, 241, 1); /* Couleur de fond */\n"
"    padding: 5px; /* Espacement int\303\251rieur */\n"
"    border-radius: 5px; /* Bordure arrondie */\n"
"    border: 2px solid rgba(52, 152, 219, 1); /* Bordure solide */\n"
"}\n"
""));

        verticalLayout_34->addWidget(label_99);

        checkBox_28 = new QCheckBox(leftMenu3);
        checkBox_28->setObjectName(QString::fromUtf8("checkBox_28"));

        verticalLayout_34->addWidget(checkBox_28, 0, Qt::AlignTop);

        checkBox_29 = new QCheckBox(leftMenu3);
        checkBox_29->setObjectName(QString::fromUtf8("checkBox_29"));

        verticalLayout_34->addWidget(checkBox_29, 0, Qt::AlignTop);


        horizontalLayout_47->addLayout(verticalLayout_34);

        verticalLayout_35 = new QVBoxLayout();
        verticalLayout_35->setObjectName(QString::fromUtf8("verticalLayout_35"));
        horizontalLayout_48 = new QHBoxLayout();
        horizontalLayout_48->setObjectName(QString::fromUtf8("horizontalLayout_48"));
        label_100 = new QLabel(leftMenu3);
        label_100->setObjectName(QString::fromUtf8("label_100"));
        label_100->setMaximumSize(QSize(100, 20));

        horizontalLayout_48->addWidget(label_100);

        lineEdit_68 = new QLineEdit(leftMenu3);
        lineEdit_68->setObjectName(QString::fromUtf8("lineEdit_68"));
        lineEdit_68->setMaximumSize(QSize(16777215, 30));

        horizontalLayout_48->addWidget(lineEdit_68);


        verticalLayout_35->addLayout(horizontalLayout_48);

        horizontalLayout_49 = new QHBoxLayout();
        horizontalLayout_49->setObjectName(QString::fromUtf8("horizontalLayout_49"));
        label_101 = new QLabel(leftMenu3);
        label_101->setObjectName(QString::fromUtf8("label_101"));
        label_101->setMaximumSize(QSize(16777215, 20));

        horizontalLayout_49->addWidget(label_101);

        lineEdit_69 = new QLineEdit(leftMenu3);
        lineEdit_69->setObjectName(QString::fromUtf8("lineEdit_69"));
        lineEdit_69->setMaximumSize(QSize(16777215, 30));

        horizontalLayout_49->addWidget(lineEdit_69);


        verticalLayout_35->addLayout(horizontalLayout_49);

        horizontalLayout_50 = new QHBoxLayout();
        horizontalLayout_50->setObjectName(QString::fromUtf8("horizontalLayout_50"));
        label_102 = new QLabel(leftMenu3);
        label_102->setObjectName(QString::fromUtf8("label_102"));
        label_102->setMaximumSize(QSize(16777215, 20));

        horizontalLayout_50->addWidget(label_102);

        lineEdit_70 = new QLineEdit(leftMenu3);
        lineEdit_70->setObjectName(QString::fromUtf8("lineEdit_70"));
        lineEdit_70->setMaximumSize(QSize(16777215, 30));

        horizontalLayout_50->addWidget(lineEdit_70);


        verticalLayout_35->addLayout(horizontalLayout_50);


        horizontalLayout_47->addLayout(verticalLayout_35);


        gridLayout_4->addWidget(leftMenu3, 2, 0, 1, 1);

        barInfo->addTab(assurance, QString());
        observation = new QWidget();
        observation->setObjectName(QString::fromUtf8("observation"));
        gridLayout_14 = new QGridLayout(observation);
        gridLayout_14->setObjectName(QString::fromUtf8("gridLayout_14"));
        widget_10 = new QWidget(observation);
        widget_10->setObjectName(QString::fromUtf8("widget_10"));
        widget_10->setMinimumSize(QSize(0, 100));
        widget_10->setMaximumSize(QSize(16777215, 70));
        widget_10->setStyleSheet(QString::fromUtf8("QLabel{\n"
"	border: 2px solid blue;\n"
"	background-color:rgb(214, 241, 6);\n"
"	border-radius: 3px;\n"
"	padding-left: 10px;\n"
"	padding-right: 10px;\n"
"}\n"
"\n"
"QLineEdit{\n"
"	border: 1px solid black;\n"
"	border-radius: 3px;\n"
"	padding-left: 10px\n"
"}\n"
""));
        formLayout = new QFormLayout(widget_10);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        label = new QLabel(widget_10);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMinimumSize(QSize(100, 30));

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        lineEdit = new QLineEdit(widget_10);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setMinimumSize(QSize(0, 30));
        lineEdit->setMaximumSize(QSize(500, 16777215));

        formLayout->setWidget(0, QFormLayout::FieldRole, lineEdit);

        label_2 = new QLabel(widget_10);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMinimumSize(QSize(100, 30));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_2);

        lineEdit_2 = new QLineEdit(widget_10);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setMinimumSize(QSize(0, 30));
        lineEdit_2->setMaximumSize(QSize(500, 16777215));

        formLayout->setWidget(1, QFormLayout::FieldRole, lineEdit_2);


        gridLayout_14->addWidget(widget_10, 0, 0, 1, 1);

        widget_11 = new QWidget(observation);
        widget_11->setObjectName(QString::fromUtf8("widget_11"));
        widget_11->setStyleSheet(QString::fromUtf8("QLabel{\n"
"	border: 2px solid blue;\n"
"	background-color:rgb(214, 241, 6);\n"
"	border-radius: 3px;\n"
"	padding-left: 10px;\n"
"	padding-right: 10px;\n"
"}\n"
"\n"
"QLineEdit{\n"
"	border: 1px solid black;\n"
"	border-radius: 3px;\n"
"	padding-left: 10px\n"
"}\n"
""));
        gridLayout_22 = new QGridLayout(widget_11);
        gridLayout_22->setObjectName(QString::fromUtf8("gridLayout_22"));
        widget_12 = new QWidget(widget_11);
        widget_12->setObjectName(QString::fromUtf8("widget_12"));
        gridLayout_23 = new QGridLayout(widget_12);
        gridLayout_23->setObjectName(QString::fromUtf8("gridLayout_23"));
        gridLayout_23->setHorizontalSpacing(5);
        gridLayout_23->setVerticalSpacing(3);
        gridLayout_23->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(widget_12);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setMinimumSize(QSize(0, 30));
        label_3->setMaximumSize(QSize(16777215, 30));

        gridLayout_23->addWidget(label_3, 0, 0, 1, 1);

        label_4 = new QLabel(widget_12);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout_23->addWidget(label_4, 0, 1, 1, 1);

        comboBox = new QComboBox(widget_12);
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setMinimumSize(QSize(100, 30));
        comboBox->setMaximumSize(QSize(500, 30));

        gridLayout_23->addWidget(comboBox, 1, 0, 1, 1);

        frame_6 = new QFrame(widget_12);
        frame_6->setObjectName(QString::fromUtf8("frame_6"));
        frame_6->setFrameShape(QFrame::StyledPanel);
        frame_6->setFrameShadow(QFrame::Raised);
        gridLayout_24 = new QGridLayout(frame_6);
        gridLayout_24->setObjectName(QString::fromUtf8("gridLayout_24"));

        gridLayout_23->addWidget(frame_6, 3, 0, 1, 2);

        line = new QFrame(widget_12);
        line->setObjectName(QString::fromUtf8("line"));
        line->setWindowModality(Qt::WindowModal);
        line->setFrameShadow(QFrame::Raised);
        line->setLineWidth(0);
        line->setMidLineWidth(6);
        line->setFrameShape(QFrame::HLine);

        gridLayout_23->addWidget(line, 2, 0, 1, 2);

        dateEdit = new QDateEdit(widget_12);
        dateEdit->setObjectName(QString::fromUtf8("dateEdit"));
        dateEdit->setMinimumSize(QSize(200, 30));
        dateEdit->setMaximumSize(QSize(300, 30));

        gridLayout_23->addWidget(dateEdit, 1, 1, 1, 1);


        gridLayout_22->addWidget(widget_12, 0, 0, 3, 1);

        frame_5 = new QFrame(widget_11);
        frame_5->setObjectName(QString::fromUtf8("frame_5"));
        frame_5->setMinimumSize(QSize(125, 45));
        frame_5->setMaximumSize(QSize(100, 45));
        frame_5->setStyleSheet(QString::fromUtf8("QFrame{\n"
"	border:none;\n"
"	background-color:transparent;\n"
"}"));
        frame_5->setFrameShape(QFrame::StyledPanel);
        frame_5->setFrameShadow(QFrame::Raised);
        horizontalLayout_10 = new QHBoxLayout(frame_5);
        horizontalLayout_10->setSpacing(0);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        horizontalLayout_10->setContentsMargins(0, 0, 0, 0);
        pushButton_4 = new QPushButton(frame_5);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setMinimumSize(QSize(30, 40));
        pushButton_4->setMaximumSize(QSize(40, 40));

        horizontalLayout_10->addWidget(pushButton_4);

        pushButton_5 = new QPushButton(frame_5);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setMinimumSize(QSize(30, 40));
        pushButton_5->setMaximumSize(QSize(40, 40));

        horizontalLayout_10->addWidget(pushButton_5);

        pushButton_9 = new QPushButton(frame_5);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));
        pushButton_9->setMinimumSize(QSize(30, 40));
        pushButton_9->setMaximumSize(QSize(40, 40));

        horizontalLayout_10->addWidget(pushButton_9);


        gridLayout_22->addWidget(frame_5, 0, 1, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_22->addItem(verticalSpacer, 1, 1, 1, 1);


        gridLayout_14->addWidget(widget_11, 1, 0, 1, 1);

        barInfo->addTab(observation, QString());

        gridLayout_31->addWidget(barInfo, 0, 0, 1, 1);


        retranslateUi(Element);

        barInfo->setCurrentIndex(13);


        QMetaObject::connectSlotsByName(Element);
    } // setupUi

    void retranslateUi(QWidget *Element)
    {
        Element->setWindowTitle(QCoreApplication::translate("Element", "Form", nullptr));
        groupBox->setTitle(QCoreApplication::translate("Element", "Sary", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("Element", "QR", nullptr));
        groupBox_8->setTitle(QCoreApplication::translate("Element", "D\303\251c\303\251s :", nullptr));
        checkBox_6->setText(QCoreApplication::translate("Element", "D\303\251c\303\251d\303\251(O/N)", nullptr));
        label_20->setText(QCoreApplication::translate("Element", "Date :", nullptr));
        groupBox_4->setTitle(QCoreApplication::translate("Element", ".", nullptr));
        label_8->setText(QCoreApplication::translate("Element", "Situation militaire :", nullptr));
        label_9->setText(QCoreApplication::translate("Element", "Corps :", nullptr));
        label_10->setText(QCoreApplication::translate("Element", "P\303\251riode :", nullptr));
        label_11->setText(QCoreApplication::translate("Element", "Motif :", nullptr));
        groupBox_7->setTitle(QCoreApplication::translate("Element", "Sexe :", nullptr));
        checkBox_7->setText(QCoreApplication::translate("Element", "Masculin", nullptr));
        checkBox_8->setText(QCoreApplication::translate("Element", "F\303\251minin", nullptr));
        groupBox_5->setTitle(QCoreApplication::translate("Element", ".", nullptr));
        label_12->setText(QCoreApplication::translate("Element", "Nationalit\303\251 :", nullptr));
        checkBox->setText(QCoreApplication::translate("Element", "Malagasy", nullptr));
        checkBox_2->setText(QCoreApplication::translate("Element", "\303\211tranger", nullptr));
        label_13->setText(QCoreApplication::translate("Element", "Mode d'acquisition :", nullptr));
        checkBox_3->setText(QCoreApplication::translate("Element", "Naissance ", nullptr));
        checkBox_4->setText(QCoreApplication::translate("Element", "D\303\251claration", nullptr));
        checkBox_5->setText(QCoreApplication::translate("Element", "Mariage", nullptr));
        label_14->setText(QCoreApplication::translate("Element", "Date d'acquisition :", nullptr));
        groupBox_6->setTitle(QCoreApplication::translate("Element", "Naissance :", nullptr));
        label_15->setText(QCoreApplication::translate("Element", "Date", nullptr));
        label_16->setText(QCoreApplication::translate("Element", "ou Ann\303\251e :", nullptr));
        label_17->setText(QCoreApplication::translate("Element", "Lieu :", nullptr));
        groupBox_9->setTitle(QCoreApplication::translate("Element", "Conjoint :", nullptr));
        label_21->setText(QCoreApplication::translate("Element", "Nom et pr\303\251noms :", nullptr));
        label_22->setText(QCoreApplication::translate("Element", "NAiSSANCE :", nullptr));
        label_23->setText(QCoreApplication::translate("Element", "Date :", nullptr));
        label_24->setText(QCoreApplication::translate("Element", "Lieu :", nullptr));
        label_25->setText(QCoreApplication::translate("Element", "MARIAGE :", nullptr));
        label_26->setText(QCoreApplication::translate("Element", "Date :", nullptr));
        label_27->setText(QCoreApplication::translate("Element", "Lieu :", nullptr));
        label_28->setText(QCoreApplication::translate("Element", "Profession :", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("Element", "GroupBox", nullptr));
        label_5->setText(QCoreApplication::translate("Element", "Numero :", nullptr));
        label_6->setText(QCoreApplication::translate("Element", "Nouveau numero :", nullptr));
        label_7->setText(QCoreApplication::translate("Element", "Nom :", nullptr));
        label_18->setText(QCoreApplication::translate("Element", "Pr\303\251noms :", nullptr));
        label_19->setText(QCoreApplication::translate("Element", "Nom de jeune fille :", nullptr));
        groupBox_10->setTitle(QCoreApplication::translate("Element", "Situation Matrimoniale :", nullptr));
        checkBox_9->setText(QCoreApplication::translate("Element", "C\303\251libataire", nullptr));
        checkBox_10->setText(QCoreApplication::translate("Element", "Mari\303\251(e)", nullptr));
        checkBox_11->setText(QCoreApplication::translate("Element", "Concubin(e)", nullptr));
        checkBox_12->setText(QCoreApplication::translate("Element", "Veuf(ve)", nullptr));
        checkBox_13->setText(QCoreApplication::translate("Element", "Divorc\303\251e", nullptr));
        groupBox_11->setTitle(QCoreApplication::translate("Element", ".", nullptr));
        pushButton_10->setText(QCoreApplication::translate("Element", "G\303\251n\303\251rer le texte", nullptr));
        toolButton->setText(QCoreApplication::translate("Element", "...", nullptr));
        toolButton_2->setText(QCoreApplication::translate("Element", "...", nullptr));
        toolButton_3->setText(QCoreApplication::translate("Element", "...", nullptr));
        toolButton_4->setText(QCoreApplication::translate("Element", "...", nullptr));
        toolButton_5->setText(QCoreApplication::translate("Element", "...", nullptr));
        barInfo->setTabText(barInfo->indexOf(Identite), QCoreApplication::translate("Element", "Tab 1", nullptr));
        prenomCotisation->setText(QCoreApplication::translate("Element", "Pr\303\251noms", nullptr));
        groupBox_19->setTitle(QCoreApplication::translate("Element", "AUTRE", nullptr));
        label_90->setText(QCoreApplication::translate("Element", "Ann\303\251e", nullptr));
        groupBox_20->setTitle(QCoreApplication::translate("Element", "AUTRES", nullptr));
        label_89->setText(QCoreApplication::translate("Element", "Date", nullptr));
        checkBox_24->setText(QCoreApplication::translate("Element", "3\302\260", nullptr));
        label_84->setText(QCoreApplication::translate("Element", "Libell\303\251", nullptr));
        checkBox_25->setText(QCoreApplication::translate("Element", "2\302\260", nullptr));
        label_88->setText(QCoreApplication::translate("Element", "Date", nullptr));
        checkBox_23->setText(QCoreApplication::translate("Element", "1\302\260", nullptr));
        label_86->setText(QCoreApplication::translate("Element", "Libell\303\251", nullptr));
        label_85->setText(QCoreApplication::translate("Element", "Libell\303\251", nullptr));
        label_87->setText(QCoreApplication::translate("Element", "Date", nullptr));
        label_95->setText(QCoreApplication::translate("Element", "N\302\260:", nullptr));
        label_93->setText(QCoreApplication::translate("Element", "N\302\260:", nullptr));
        label_94->setText(QCoreApplication::translate("Element", "N\302\260:", nullptr));
        label_116->setText(QCoreApplication::translate("Element", "Date", nullptr));
        checkBox_33->setText(QCoreApplication::translate("Element", "Bulletin", nullptr));
        checkBox_35->setText(QCoreApplication::translate("Element", "Caduc\303\251e", nullptr));
        label_115->setText(QCoreApplication::translate("Element", "N\302\260:", nullptr));
        label_117->setText(QCoreApplication::translate("Element", "Date", nullptr));
        label_91->setText(QCoreApplication::translate("Element", "Date", nullptr));
        label_92->setText(QCoreApplication::translate("Element", "Date", nullptr));
        checkBox_34->setText(QCoreApplication::translate("Element", "Nouvelle carte", nullptr));
        label_118->setText(QCoreApplication::translate("Element", "Date", nullptr));
        label_119->setText(QCoreApplication::translate("Element", "Date", nullptr));
        pushButton_24->setText(QCoreApplication::translate("Element", "Nouvelle Ann\303\251e", nullptr));
        pushButton_27->setText(QCoreApplication::translate("Element", "Ann\303\251e pr\303\251cedente", nullptr));
        pushButton_26->setText(QCoreApplication::translate("Element", "Ann\303\251e suivante", nullptr));
        pushButton_25->setText(QCoreApplication::translate("Element", "Derni\303\250re ann\303\251e", nullptr));
        nomCotisation->setText(QCoreApplication::translate("Element", "Nom", nullptr));
        pushButton_20->setText(QString());
        pushButton_18->setText(QString());
        pushButton_19->setText(QString());
        groupBox_18->setTitle(QCoreApplication::translate("Element", "COTISATION", nullptr));
        label_83->setText(QCoreApplication::translate("Element", "Observation", nullptr));
        label_78->setText(QCoreApplication::translate("Element", "Ann\303\251e", nullptr));
        nouvelleCotisation->setText(QCoreApplication::translate("Element", "Nouvelle ", nullptr));
        dernierCotisation->setText(QCoreApplication::translate("Element", "Dernier", nullptr));
        precedentCotisation->setText(QCoreApplication::translate("Element", "Precedent", nullptr));
        suivantCotisation->setText(QCoreApplication::translate("Element", "Nouvelle", nullptr));
        label_82->setText(QCoreApplication::translate("Element", "Recu n\302\260", nullptr));
        label_81->setText(QCoreApplication::translate("Element", "Montant", nullptr));
        label_80->setText(QCoreApplication::translate("Element", "Date de Paiment", nullptr));
        label_79->setText(QCoreApplication::translate("Element", "Total", nullptr));
        barInfo->setTabText(barInfo->indexOf(cotisation), QCoreApplication::translate("Element", "Tab 2", nullptr));
        barInfo->setTabText(barInfo->indexOf(dossier), QCoreApplication::translate("Element", "Page", nullptr));
        label_124->setText(QCoreApplication::translate("Element", "Nom", nullptr));
        label_125->setText(QCoreApplication::translate("Element", "Prenom", nullptr));
        label_126->setText(QCoreApplication::translate("Element", "ENFANTS DU DOCTEUR", nullptr));
        ordre->setText(QCoreApplication::translate("Element", "N \302\260 Ordre", nullptr));
        activite_2->setText(QCoreApplication::translate("Element", " Activit\303\251s ", nullptr));
        Date->setText(QCoreApplication::translate("Element", "Date de naissance", nullptr));
        Nom->setText(QCoreApplication::translate("Element", "Nom", nullptr));
        Prenom->setText(QCoreApplication::translate("Element", "Prenom", nullptr));
        barInfo->setTabText(barInfo->indexOf(enfant), QCoreApplication::translate("Element", "Page", nullptr));
        label_41->setText(QCoreApplication::translate("Element", "Nom", nullptr));
        lineEdit_20->setPlaceholderText(QCoreApplication::translate("Element", "Nom", nullptr));
        label_42->setText(QCoreApplication::translate("Element", "Prenom", nullptr));
        lineEdit_21->setPlaceholderText(QCoreApplication::translate("Element", "prenom", nullptr));
        groupBox_12->setTitle(QCoreApplication::translate("Element", "THESE", nullptr));
        label_31->setText(QCoreApplication::translate("Element", "Date", nullptr));
        label_32->setText(QCoreApplication::translate("Element", "Lieu", nullptr));
        label_33->setText(QCoreApplication::translate("Element", "Titre", nullptr));
        label_34->setText(QCoreApplication::translate("Element", "N these", nullptr));
        groupBox_13->setTitle(QCoreApplication::translate("Element", "DIPLOME", nullptr));
        label_35->setText(QCoreApplication::translate("Element", "Date du diplome", nullptr));
        label_36->setText(QCoreApplication::translate("Element", "Date attestation du diplome", nullptr));
        label_37->setText(QCoreApplication::translate("Element", "Lieu", nullptr));
        label_38->setText(QCoreApplication::translate("Element", "Type", nullptr));
        pushButton_11->setText(QCoreApplication::translate("Element", "ok", nullptr));
        groupBox_14->setTitle(QCoreApplication::translate("Element", "FACULTE", nullptr));
        label_39->setText(QCoreApplication::translate("Element", "Type", nullptr));
        label_40->setText(QCoreApplication::translate("Element", "Periode", nullptr));
        pushButton_12->setText(QCoreApplication::translate("Element", "<-", nullptr));
        pushButton_13->setText(QCoreApplication::translate("Element", "->", nullptr));
        pushButton_14->setText(QCoreApplication::translate("Element", "PushButton", nullptr));
        barInfo->setTabText(barInfo->indexOf(etudes), QCoreApplication::translate("Element", "Page", nullptr));
        nom->setText(QCoreApplication::translate("Element", "Nom : ", nullptr));
        prenom->setText(QCoreApplication::translate("Element", "Pr\303\251noms : ", nullptr));
        pushButton->setText(QString());
        pushButton_3->setText(QString());
        pushButton_2->setText(QString());
        adressePrecedent->setText(QCoreApplication::translate("Element", "Adresse Pr\303\251cedent", nullptr));
        adresseSuivant->setText(QCoreApplication::translate("Element", "Adresse Suivant", nullptr));
        dernierAdresse->setText(QCoreApplication::translate("Element", "Dernier Adresse", nullptr));
        pushButton_6->setText(QString());
        adressePersonnelle->setText(QCoreApplication::translate("Element", "ADRESSE PERSONNELLE (DOMICILE)", nullptr));
        faxPersonnelle->setText(QCoreApplication::translate("Element", "Fax:", nullptr));
        PortablePersonnelle->setText(QCoreApplication::translate("Element", "Portable:", nullptr));
        comboBoxPerso->setItemText(0, QCoreApplication::translate("Element", "test", nullptr));
        comboBoxPerso->setItemText(1, QCoreApplication::translate("Element", "test1", nullptr));
        comboBoxPerso->setItemText(2, QCoreApplication::translate("Element", "test2", nullptr));

        adressePersonnelle_2->setText(QCoreApplication::translate("Element", "Adresse :", nullptr));
        emailPersonnelle->setText(QCoreApplication::translate("Element", "E_mail:", nullptr));
        fivondronanaPersonnelle->setText(QCoreApplication::translate("Element", "Fivondronana :", nullptr));
        TelmaPersonnelle->setText(QCoreApplication::translate("Element", "T\303\251lma:", nullptr));
        firaisanaPersonnelle->setText(QCoreApplication::translate("Element", "Firaisana :", nullptr));
        fokotanyPersonnelle->setText(QCoreApplication::translate("Element", "Fokotany :", nullptr));
        adressePrecedent_2->setText(QCoreApplication::translate("Element", "Adresse Pr\303\251cedent", nullptr));
        adresseSuivant_2->setText(QCoreApplication::translate("Element", "Adresse Suivant", nullptr));
        dernierAdresse_2->setText(QCoreApplication::translate("Element", "Dernier Adresse", nullptr));
        pushButton_7->setText(QString());
        LieuExoPrincipal->setText(QCoreApplication::translate("Element", "LIEU D'EXERCICE PRINCIPAL", nullptr));
        TelmaExo->setText(QCoreApplication::translate("Element", "T\303\251lma:", nullptr));
        fivondronanaExo->setText(QCoreApplication::translate("Element", "Fivondronana :", nullptr));
        fokotanyExo->setText(QCoreApplication::translate("Element", "Fokotany :", nullptr));
        emailExo->setText(QCoreApplication::translate("Element", "E_mail:", nullptr));
        comboBoxExo->setItemText(0, QCoreApplication::translate("Element", "test", nullptr));
        comboBoxExo->setItemText(1, QCoreApplication::translate("Element", "test1", nullptr));
        comboBoxExo->setItemText(2, QCoreApplication::translate("Element", "test2", nullptr));

        PortableExo->setText(QCoreApplication::translate("Element", "Portable:", nullptr));
        adresseExo->setText(QCoreApplication::translate("Element", "Adresse :", nullptr));
        firaisanaExo->setText(QCoreApplication::translate("Element", "Firaisana :", nullptr));
        faxExo->setText(QCoreApplication::translate("Element", "Fax:", nullptr));
        addressCourier->setText(QCoreApplication::translate("Element", "ADRESSE COURRIERS", nullptr));
        AdresseCourier->setText(QCoreApplication::translate("Element", "Adresse", nullptr));
        FokotanyCourier->setText(QCoreApplication::translate("Element", "Fokotany", nullptr));
        FiraisanaCourier->setText(QCoreApplication::translate("Element", "Firaisana", nullptr));
        FivondronanaCourier->setText(QCoreApplication::translate("Element", "Fivondronana", nullptr));
        adressePrecedent_3->setText(QCoreApplication::translate("Element", "Adresse Pr\303\251cedent", nullptr));
        adresseSuivant_3->setText(QCoreApplication::translate("Element", "Adresse Suivant", nullptr));
        dernierAdresse_3->setText(QCoreApplication::translate("Element", "Dernier Adresse", nullptr));
        pushButton_8->setText(QString());
        adressePersonnelle_3->setText(QCoreApplication::translate("Element", "AUTRE LIEU D'EXERCICE", nullptr));
        emailPersonnelle_2->setText(QCoreApplication::translate("Element", "E_mail:", nullptr));
        firaisanaPersonnelle_2->setText(QCoreApplication::translate("Element", "Firaisana :", nullptr));
        comboBoxPerso_2->setItemText(0, QCoreApplication::translate("Element", "test", nullptr));
        comboBoxPerso_2->setItemText(1, QCoreApplication::translate("Element", "test1", nullptr));
        comboBoxPerso_2->setItemText(2, QCoreApplication::translate("Element", "test2", nullptr));

        TelmaPersonnelle_2->setText(QCoreApplication::translate("Element", "T\303\251lma:", nullptr));
        faxPersonnelle_2->setText(QCoreApplication::translate("Element", "Fax:", nullptr));
        adressePersonnelle_4->setText(QCoreApplication::translate("Element", "Adresse :", nullptr));
        fokotanyPersonnelle_2->setText(QCoreApplication::translate("Element", "Fokotany :", nullptr));
        fivondronanaPersonnelle_2->setText(QCoreApplication::translate("Element", "Fivondronana :", nullptr));
        PortablePersonnelle_2->setText(QCoreApplication::translate("Element", "Portable:", nullptr));
        barInfo->setTabText(barInfo->indexOf(adresse), QCoreApplication::translate("Element", "Page", nullptr));
        label_53->setText(QCoreApplication::translate("Element", "Nom", nullptr));
        lineEdit_30->setPlaceholderText(QCoreApplication::translate("Element", "nom", nullptr));
        label_54->setText(QCoreApplication::translate("Element", "Prenom", nullptr));
        lineEdit_31->setPlaceholderText(QCoreApplication::translate("Element", "prenom", nullptr));
        groupBox_15->setTitle(QCoreApplication::translate("Element", "TITRE UNIVERSITAIRE", nullptr));
        label_43->setText(QCoreApplication::translate("Element", "periode", nullptr));
        label_44->setText(QCoreApplication::translate("Element", "periode", nullptr));
        checkBox_14->setText(QCoreApplication::translate("Element", "Medecin conseils d Assurances", nullptr));
        label_45->setText(QCoreApplication::translate("Element", "periode", nullptr));
        label_46->setText(QCoreApplication::translate("Element", "periode", nullptr));
        checkBox_15->setText(QCoreApplication::translate("Element", "ancien interne des hopitaux", nullptr));
        checkBox_16->setText(QCoreApplication::translate("Element", "ancien externe des hopitaux", nullptr));
        label_47->setText(QCoreApplication::translate("Element", "periode", nullptr));
        checkBox_17->setText(QCoreApplication::translate("Element", "charge de cours", nullptr));
        checkBox_18->setText(QCoreApplication::translate("Element", "Expres aupres des Tribunaux", nullptr));
        checkBox_19->setText(QCoreApplication::translate("Element", "Assistant ou chef de clinique", nullptr));
        label_48->setText(QCoreApplication::translate("Element", "periode", nullptr));
        label_49->setText(QCoreApplication::translate("Element", "periode", nullptr));
        checkBox_20->setText(QCoreApplication::translate("Element", "Professeur", nullptr));
        checkBox_21->setText(QCoreApplication::translate("Element", "Maitre de conference", nullptr));
        label_50->setText(QCoreApplication::translate("Element", "periode", nullptr));
        groupBox_16->setTitle(QCoreApplication::translate("Element", "AUTRES DIPLOMES PARAMEDICAUX", nullptr));
        label_51->setText(QCoreApplication::translate("Element", "Diplome", nullptr));
        label_52->setText(QCoreApplication::translate("Element", "Date d obtenttion", nullptr));
        pushButton_15->setText(QCoreApplication::translate("Element", "<-", nullptr));
        pushButton_16->setText(QCoreApplication::translate("Element", "->", nullptr));
        pushButton_17->setText(QCoreApplication::translate("Element", "PushButton", nullptr));
        barInfo->setTabText(barInfo->indexOf(titre), QCoreApplication::translate("Element", "Page", nullptr));
        nomLabel_3->setText(QCoreApplication::translate("Element", "Nom", nullptr));
        prenomLabel_3->setText(QCoreApplication::translate("Element", "Prenom", nullptr));
        label_121->setText(QCoreApplication::translate("Element", "SPECIALIT\303\211S MEDICALES", nullptr));
        specDate_3->setText(QCoreApplication::translate("Element", "Date d'Obtention", nullptr));
        specPer_3->setText(QCoreApplication::translate("Element", "P\303\251riode", nullptr));
        specTitre_3->setText(QCoreApplication::translate("Element", "Titre", nullptr));
        fontComboBox_19->setPlaceholderText(QString());
        specSpec_3->setText(QCoreApplication::translate("Element", "Sp\303\251cialit\303\251s", nullptr));
        specLieu_3->setText(QCoreApplication::translate("Element", "Lieux", nullptr));
        label_122->setText(QCoreApplication::translate("Element", "AUTRES QUALIFICATIONS", nullptr));
        AutreSpec_3->setText(QCoreApplication::translate("Element", "Sp\303\251cialit\303\251s", nullptr));
        AutreLieu_3->setText(QCoreApplication::translate("Element", "Lieux", nullptr));
        AutreTitre_3->setText(QCoreApplication::translate("Element", "Titre", nullptr));
        fontComboBox_24->setPlaceholderText(QString());
        AutreDate_3->setText(QCoreApplication::translate("Element", "Date d'Obtention", nullptr));
        AutrePer_3->setText(QCoreApplication::translate("Element", "P\303\251riode", nullptr));
        label_123->setText(QCoreApplication::translate("Element", "COMP\303\211TENCES", nullptr));
        CompOb_3->setText(QCoreApplication::translate("Element", "Date d'Obtention", nullptr));
        CompDoss_3->setText(QCoreApplication::translate("Element", "Dossier Justificatif", nullptr));
        fontComboBox_25->setPlaceholderText(QString());
        CompDate_3->setText(QCoreApplication::translate("Element", "Date d'Obtention", nullptr));
        CompDom_3->setText(QCoreApplication::translate("Element", "Domaine de Comp\303\251tences", nullptr));
        fontComboBox_26->setPlaceholderText(QString());
        CompDateAc_3->setText(QCoreApplication::translate("Element", "Date Accord", nullptr));
        CompPv_3->setText(QCoreApplication::translate("Element", "N \302\260 PV", nullptr));
        CompAvis_3->setText(QCoreApplication::translate("Element", "Avis de l'ordre", nullptr));
        fontComboBox_27->setPlaceholderText(QString());
        CompTitr_3->setText(QCoreApplication::translate("Element", "Titre", nullptr));
        CompPer_3->setText(QCoreApplication::translate("Element", "P\303\251riode", nullptr));
        barInfo->setTabText(barInfo->indexOf(specialites), QCoreApplication::translate("Element", "Page", nullptr));
        label_29->setText(QCoreApplication::translate("Element", "Nom : ", nullptr));
        label_30->setText(QCoreApplication::translate("Element", "P\303\251nom : ", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("Element", "Nom et Pr\303\251nom du m\303\251d\303\251cin remplac\303\251", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("Element", "Adresse", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("Element", "P\303\251riode", nullptr));
        barInfo->setTabText(barInfo->indexOf(remplacement), QCoreApplication::translate("Element", "Page", nullptr));
        label_55->setText(QCoreApplication::translate("Element", "Nom:  ", nullptr));
        label_56->setText(QCoreApplication::translate("Element", "Prenom:", nullptr));
        checkBox_22->setText(QCoreApplication::translate("Element", "Inscrit au tableau de l'ordre de Madagascar (O/N)", nullptr));
        label_57->setText(QCoreApplication::translate("Element", "N\302\260 d'inscription \303\240 l'order: ", nullptr));
        label_58->setText(QCoreApplication::translate("Element", "Date d'inscripption \303\240 l'order:", nullptr));
        label_59->setText(QCoreApplication::translate("Element", "ou Ann\303\251e :", nullptr));
        label_60->setText(QCoreApplication::translate("Element", "Demande d'inscription \303\240 un autre  order de M\303\251decine \303\251tranger:", nullptr));
        label_61->setText(QCoreApplication::translate("Element", "Pays", nullptr));
        label_62->setText(QCoreApplication::translate("Element", "Num\303\251ro", nullptr));
        label_63->setText(QCoreApplication::translate("Element", "Motif de r\303\251fus", nullptr));
        label_64->setText(QCoreApplication::translate("Element", "Service Hospitalier, public ou priv\303\251", nullptr));
        label_65->setText(QCoreApplication::translate("Element", "Hopital", nullptr));
        label_66->setText(QCoreApplication::translate("Element", "Poste occup\303\251", nullptr));
        label_67->setText(QCoreApplication::translate("Element", "P\303\251riode", nullptr));
        label_68->setText(QCoreApplication::translate("Element", "Organisme qui fait appelle \303\240 votre comp\303\251tence", nullptr));
        label_69->setText(QCoreApplication::translate("Element", "Nom_organisme", nullptr));
        barInfo->setTabText(barInfo->indexOf(exercice), QCoreApplication::translate("Element", "Page", nullptr));
        label_77->setText(QCoreApplication::translate("Element", "Nom", nullptr));
        label_76->setText(QCoreApplication::translate("Element", "Prenom", nullptr));
        groupBox_17->setTitle(QCoreApplication::translate("Element", "DISTINCTIONS HONORIFIQUES", nullptr));
        label_127->setText(QCoreApplication::translate("Element", "Distinction Honorifique", nullptr));
        label_128->setText(QCoreApplication::translate("Element", "Date d'obtention", nullptr));
        pushButton_21->setText(QString());
        pushButton_23->setText(QString());
        pushButton_22->setText(QString());
        barInfo->setTabText(barInfo->indexOf(distinctionH), QCoreApplication::translate("Element", "Page", nullptr));
        label_70->setText(QCoreApplication::translate("Element", "Nom:", nullptr));
        label_71->setText(QCoreApplication::translate("Element", "Pr\303\251nom(s):", nullptr));
        label_72->setText(QCoreApplication::translate("Element", "INTERET DANS UN ORGANISME", nullptr));
        label_73->setText(QCoreApplication::translate("Element", "Nom Soci\303\251t\303\251 :", nullptr));
        label_74->setText(QCoreApplication::translate("Element", "Poste Occup\303\251 :", nullptr));
        label_75->setText(QCoreApplication::translate("Element", "Date d'adh\303\251sion :", nullptr));
        barInfo->setTabText(barInfo->indexOf(extra), QCoreApplication::translate("Element", "Page", nullptr));
        label_106->setText(QCoreApplication::translate("Element", "Nom : ", nullptr));
        label_107->setText(QCoreApplication::translate("Element", "Pr\303\251nom : ", nullptr));
        label_108->setText(QCoreApplication::translate("Element", "PEINE JUDICIAIRE DE L'ORDRE", nullptr));
        label_112->setText(QCoreApplication::translate("Element", "Date", nullptr));
        label_113->setText(QCoreApplication::translate("Element", "Motif", nullptr));
        label_114->setText(QCoreApplication::translate("Element", "Sanction", nullptr));
        label_111->setText(QCoreApplication::translate("Element", "CONDAMNATION DU DROIT COMMUN", nullptr));
        label_103->setText(QCoreApplication::translate("Element", "Date", nullptr));
        label_104->setText(QCoreApplication::translate("Element", "Condamnation", nullptr));
        label_105->setText(QCoreApplication::translate("Element", "Motif", nullptr));
        checkBox_30->setText(QCoreApplication::translate("Element", "Une instance judiciaire en cours \303\240 votre \303\251gard", nullptr));
        label_109->setText(QCoreApplication::translate("Element", "Raison :    ", nullptr));
        checkBox_31->setText(QCoreApplication::translate("Element", "Lois et r\303\250glement concernat l'exercice de la m\303\251decine \303\240 Madagascar", nullptr));
        checkBox_32->setText(QCoreApplication::translate("Element", "Renseignements particuliers sur les lois et les codes", nullptr));
        label_110->setText(QCoreApplication::translate("Element", "Rubriques :  ", nullptr));
        barInfo->setTabText(barInfo->indexOf(judiciaire), QCoreApplication::translate("Element", "Page", nullptr));
        label_120->setText(QCoreApplication::translate("Element", "Nom:", nullptr));
        label_129->setText(QCoreApplication::translate("Element", "Situation professionnelle", nullptr));
        pushButton_28->setText(QString());
        pushButton_29->setText(QString());
        pushButton_30->setText(QString());
        groupBox_21->setTitle(QCoreApplication::translate("Element", "CADRE D'ACTIVITER", nullptr));
        label_130->setText(QCoreApplication::translate("Element", "A - Exercice lIberale", nullptr));
        label_133->setText(QCoreApplication::translate("Element", "Nom du cabinet", nullptr));
        checkBox_37->setText(QCoreApplication::translate("Element", "cabinet de groupe ou association", nullptr));
        label_132->setText(QCoreApplication::translate("Element", "N\302\260 Ref", nullptr));
        checkBox_36->setText(QCoreApplication::translate("Element", "cabinet personnelle", nullptr));
        label_131->setText(QCoreApplication::translate("Element", "Date", nullptr));
        label_134->setText(QCoreApplication::translate("Element", "Nom et Pr\303\251noms des associ\303\251es", nullptr));
        label_135->setText(QCoreApplication::translate("Element", "Titre", nullptr));
        label_136->setText(QCoreApplication::translate("Element", "Nationalot\303\251 d'origine", nullptr));
        label_140->setText(QCoreApplication::translate("Element", "N\302\260 de Reference", nullptr));
        label_137->setText(QCoreApplication::translate("Element", "Autorisation de chef de service", nullptr));
        checkBox_38->setText(QCoreApplication::translate("Element", "Benevole dans le service public ou priv\303\251e", nullptr));
        label_138->setText(QCoreApplication::translate("Element", "Adresse du service", nullptr));
        label_139->setText(QCoreApplication::translate("Element", "Date d'autoristaion", nullptr));
        label_141->setText(QCoreApplication::translate("Element", "Dur\303\251e", nullptr));
        pushButton_31->setText(QCoreApplication::translate("Element", "Nouvelle Activit\303\251", nullptr));
        pushButton_32->setText(QCoreApplication::translate("Element", "Dernier Activit\303\251", nullptr));
        pushButton_33->setText(QCoreApplication::translate("Element", "Activit\303\251 precedent ", nullptr));
        pushButton_34->setText(QCoreApplication::translate("Element", "Activit\303\251 Suivantes", nullptr));
        groupBox_22->setTitle(QCoreApplication::translate("Element", "B- Salari\303\251 de la fonction publique", nullptr));
        label_143->setText(QCoreApplication::translate("Element", "Adresse", nullptr));
        checkBox_41->setText(QCoreApplication::translate("Element", "S.S.D", nullptr));
        label_142->setText(QCoreApplication::translate("Element", "Minist\303\250re", nullptr));
        checkBox_46->setText(QCoreApplication::translate("Element", "Autre ministre", nullptr));
        label_146->setText(QCoreApplication::translate("Element", "N\302\260 Ref", nullptr));
        label_144->setText(QCoreApplication::translate("Element", "Decision d'affecation", nullptr));
        checkBox_42->setText(QCoreApplication::translate("Element", "C.U.H ou C.H.R", nullptr));
        checkBox_43->setText(QCoreApplication::translate("Element", "sant\303\251", nullptr));
        checkBox_47->setText(QCoreApplication::translate("Element", "Hopital militaire", nullptr));
        checkBox_44->setText(QCoreApplication::translate("Element", "Enseignement superieur", nullptr));
        checkBox_40->setText(QCoreApplication::translate("Element", "C.S.B II", nullptr));
        checkBox_39->setText(QCoreApplication::translate("Element", "C.H.D II", nullptr));
        label_145->setText(QCoreApplication::translate("Element", "Dur\303\251e", nullptr));
        checkBox_48->setText(QCoreApplication::translate("Element", "Autre", nullptr));
        checkBox_45->setText(QCoreApplication::translate("Element", "Recherche scientifique", nullptr));
        groupBox_23->setTitle(QCoreApplication::translate("Element", "C- Salaire Priv\303\251e", nullptr));
        label_154->setText(QCoreApplication::translate("Element", "Contrat de travail", nullptr));
        checkBox_54->setText(QCoreApplication::translate("Element", "SAF", nullptr));
        checkBox_59->setText(QCoreApplication::translate("Element", "Autre organisme \303\240 pr\303\251ciser", nullptr));
        label_153->setText(QCoreApplication::translate("Element", "Adresse", nullptr));
        checkBox_55->setText(QCoreApplication::translate("Element", "ECAR", nullptr));
        checkBox_53->setText(QCoreApplication::translate("Element", "AUTRE", nullptr));
        checkBox_57->setText(QCoreApplication::translate("Element", "Marie stopes Madagascar", nullptr));
        checkBox_60->setText(QCoreApplication::translate("Element", "Delegue Medicale", nullptr));
        checkBox_52->setText(QCoreApplication::translate("Element", "SALFA", nullptr));
        label_157->setText(QCoreApplication::translate("Element", "Dur\303\251e", nullptr));
        checkBox_58->setText(QCoreApplication::translate("Element", "Institue Pasteur de Madagascar", nullptr));
        checkBox_56->setText(QCoreApplication::translate("Element", "ADRA", nullptr));
        label_155->setText(QCoreApplication::translate("Element", "Date", nullptr));
        label_152->setText(QCoreApplication::translate("Element", "Organisme priv\303\251 confessionel", nullptr));
        checkBox_61->setText(QCoreApplication::translate("Element", "Clinique Priv\303\251e", nullptr));
        label_156->setText(QCoreApplication::translate("Element", "N\302\260 Ref", nullptr));
        groupBox_25->setTitle(QCoreApplication::translate("Element", "D- Mission humanitaire", nullptr));
        label_148->setText(QCoreApplication::translate("Element", "Contrat de travail", nullptr));
        label_149->setText(QCoreApplication::translate("Element", "Date", nullptr));
        checkBox_51->setText(QCoreApplication::translate("Element", "Mission humanitaire", nullptr));
        label_151->setText(QCoreApplication::translate("Element", "N\302\260 Ref", nullptr));
        label_150->setText(QCoreApplication::translate("Element", "Dur\303\251e", nullptr));
        label_147->setText(QCoreApplication::translate("Element", "Adresse", nullptr));
        groupBox_24->setTitle(QCoreApplication::translate("Element", "E- Autre", nullptr));
        checkBox_50->setText(QCoreApplication::translate("Element", "En attente de poste", nullptr));
        checkBox_49->setText(QCoreApplication::translate("Element", "Retrait\303\251", nullptr));
        barInfo->setTabText(barInfo->indexOf(activite), QCoreApplication::translate("Element", "Page", nullptr));
        label_97->setText(QCoreApplication::translate("Element", "Nom : ", nullptr));
        label_98->setText(QCoreApplication::translate("Element", "Pr\303\251nom : ", nullptr));
        label_96->setText(QCoreApplication::translate("Element", "Assurance professionnelle ?", nullptr));
        checkBox_26->setText(QCoreApplication::translate("Element", "Oui", nullptr));
        checkBox_27->setText(QCoreApplication::translate("Element", "Non", nullptr));
        label_99->setText(QCoreApplication::translate("Element", "Compagnie d'assurance", nullptr));
        checkBox_28->setText(QCoreApplication::translate("Element", "NY HAVANA", nullptr));
        checkBox_29->setText(QCoreApplication::translate("Element", "ARO", nullptr));
        label_100->setText(QCoreApplication::translate("Element", "N\302\260 Police : ", nullptr));
        label_101->setText(QCoreApplication::translate("Element", "Date : ", nullptr));
        label_102->setText(QCoreApplication::translate("Element", "Ann\303\251e : ", nullptr));
        barInfo->setTabText(barInfo->indexOf(assurance), QCoreApplication::translate("Element", "Page", nullptr));
        label->setText(QCoreApplication::translate("Element", "Nom", nullptr));
        label_2->setText(QCoreApplication::translate("Element", "Pr\303\251noms", nullptr));
        label_3->setText(QCoreApplication::translate("Element", "Observation", nullptr));
        label_4->setText(QCoreApplication::translate("Element", "Date", nullptr));
        pushButton_4->setText(QString());
        pushButton_5->setText(QString());
        pushButton_9->setText(QString());
        barInfo->setTabText(barInfo->indexOf(observation), QCoreApplication::translate("Element", "Page", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Element: public Ui_Element {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ELEMENT_H
